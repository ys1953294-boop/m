
import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { Menu, X, ShoppingBag, Heart, Zap, Search, User as UserIcon, PlusCircle, MessageCircle, LogIn, LogOut, Shield, Bell, LayoutGrid, Clock, Home, BookOpen, Compass, Crown, Sparkles, Trash2, ArrowRight, ShoppingCart, CheckCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useStore } from '../contexts/StoreContext';
import { supabase } from '../lib/supabase';
import { Item } from '../types';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [unreadCount, setUnreadCount] = useState(0);
  const location = useLocation();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams(); 
  const { user, isAdmin } = useAuth();
  const { cart, removeFromCart, cartTotal, isCartOpen, setIsCartOpen } = useStore();

  // Get active section from URL (for Home page interaction)
  const activeHomeSection = searchParams.get('section');
  // Get Item Type from URL (for Item Details page theme persistence)
  const itemTypeParam = searchParams.get('type');

  // Determine context based on params or path (Legacy check + New Section check)
  const isEcoStore = (location.pathname === '/' && activeHomeSection === 'ecostore') || itemTypeParam === 'store';
  const isEcoLearn = (location.pathname === '/' && activeHomeSection === 'ecolearn') || itemTypeParam === 'learn' || location.pathname.startsWith('/learn/ai-study');
  
  // Logic to hide Sell button in EcoStore Home Section
  const showSellButton = !isEcoStore;

  // Dynamic Theme Configuration
  const getTheme = () => {
    // ECOSTORE: Modern Midnight & Violet (Zinc-900 + Purple)
    if (isEcoStore) {
        return {
            text: 'text-zinc-100',
            hoverText: 'hover:text-purple-400',
            bg: 'bg-zinc-950', // Match Hero Background
            hoverBg: 'hover:bg-zinc-800',
            lightBg: 'bg-zinc-800',
            focusRing: 'focus:ring-purple-500',
            iconColor: 'text-purple-400',
            shadow: 'shadow-none border-b border-zinc-800',
            border: 'border-zinc-700',
            ring: 'ring-purple-500',
            isDark: true
        };
    }
    // ECOLEARN: Cyan/Blue Theme
    if (isEcoLearn) {
        return {
            text: 'text-cyan-700',
            hoverText: 'hover:text-cyan-600',
            bg: 'bg-cyan-600',
            hoverBg: 'hover:bg-cyan-700',
            lightBg: 'bg-cyan-50',
            focusRing: 'focus:ring-cyan-500',
            iconColor: 'text-cyan-600',
            shadow: 'shadow-cyan-900/10',
            border: 'border-cyan-100',
            ring: 'ring-cyan-500',
            isDark: false
        };
    }
    // ECODORM (Default): Forest Green Theme
    return {
        text: 'text-forest',
        hoverText: 'hover:text-forest',
        bg: 'bg-forest',
        hoverBg: 'hover:bg-forest-dark',
        lightBg: 'bg-green-50',
        focusRing: 'focus:ring-forest',
        iconColor: 'text-forest',
        shadow: 'shadow-green-900/10',
        border: 'border-green-100',
        ring: 'ring-forest',
        isDark: false
    };
  };

  const theme = getTheme();

  const getBrowsePath = () => {
      if (isEcoStore) return '/browse?type=store';
      if (isEcoLearn) return '/browse?type=learn';
      return '/browse';
  };

  const allNavLinks = [
    { name: 'Home', path: '/', icon: Home },
    { name: 'Explore', path: getBrowsePath(), icon: Compass, isBrowse: true },
    { name: 'Rent', path: '/rent', icon: Clock },
    { name: 'Donations', path: '/donate', icon: Heart },
  ];

  // Filter links based on context
  // If EcoStore, show only Home (Explore, Rent, Donations removed as per request)
  const navLinks = isEcoStore 
    ? allNavLinks.filter(link => link.name === 'Home')
    : allNavLinks;

  const isActive = (link: any) => {
      if (link.isBrowse) return location.pathname === '/browse';
      return location.pathname === link.path && !searchParams.get('section');
  };

  // Real-time unread count
  useEffect(() => {
    if (!user) {
        setUnreadCount(0);
        return;
    }

    const fetchUnread = async () => {
        const { count } = await supabase
            .from('messages')
            .select('*', { count: 'exact', head: true })
            .eq('receiver_id', user.id)
            .eq('is_read', false);
        setUnreadCount(count || 0);
    };

    fetchUnread();

    const sub = supabase
        .channel('public:messages:unread')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, (payload) => {
            // Re-fetch on any change to message status involving us
            const newMsg = payload.new as any;
            const oldMsg = payload.old as any;
            
            if (newMsg?.receiver_id === user.id || oldMsg?.receiver_id === user.id) {
                fetchUnread();
            }
        })
        .subscribe();

    return () => { supabase.removeChannel(sub); };
  }, [user]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Pass search query via URL params
      navigate(`/browse?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  // Dynamic Logo Rendering based on Route OR Home Section State
  const getLogo = () => {
      // Check if we are on EcoStore context
      if (isEcoStore) {
          return (
            <>
                <div className="bg-purple-600 text-white p-1 rounded-lg transition-all duration-300 shadow-md">
                  <ShoppingBag size={18} />
                </div>
                <span className="text-white font-bold text-lg md:text-xl tracking-tight transition-all duration-300">
                    Eco<span className="text-purple-400">Store</span>
                </span>
            </>
          );
      } 
      // Check if we are on EcoLearn context
      else if (isEcoLearn) {
          return (
            <>
                <div className="bg-cyan-600 text-white p-1 rounded-lg transition-colors duration-300 shadow-sm group-hover:shadow">
                  <BookOpen size={18} />
                </div>
                <span className="text-gray-900 font-bold text-lg md:text-xl tracking-tight transition-all duration-300">
                    <span className="text-cyan-600">E</span>co<span className="text-cyan-600">L</span>earn
                </span>
            </>
          );
      } 
      // Default: EcoDorm
      else {
          return (
            <>
                <div className="bg-forest text-white p-1 rounded-lg transition-colors duration-300 shadow-sm group-hover:shadow">
                  <LeafIcon />
                </div>
                <span className="text-gray-900 font-bold text-lg md:text-xl tracking-tight transition-all duration-300">
                    <span className="text-forest">E</span>co<span className="text-forest">D</span>orm
                </span>
            </>
          );
      }
  };

  return (
    <>
      <nav className={`${theme.isDark ? 'bg-zinc-950 border-b border-zinc-800' : 'bg-white border-b border-gray-100'} fixed top-0 left-0 right-0 z-40 h-14 md:h-16 transition-all duration-200`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full">
          <div className="flex justify-between h-full items-center">
            {/* Logo and Desktop Nav */}
            <div className="flex items-center gap-4 md:gap-8">
              <Link to="/" className="flex-shrink-0 flex items-center gap-1.5 group select-none">
                {getLogo()}
              </Link>
              
              {/* DESKTOP NAVIGATION LINKS */}
              <div className="hidden md:flex md:items-center md:space-x-1 lg:space-x-2">
                {navLinks.map((link) => {
                  const active = isActive(link);
                  const Icon = link.icon;
                  
                  return (
                    <Link
                      key={link.name}
                      to={link.path}
                      className={`
                        group relative px-3 py-1.5 rounded-full text-sm font-bold transition-all duration-200 flex items-center gap-1.5 select-none
                        ${active 
                          ? `${theme.lightBg} ${theme.text}` 
                          : `${theme.isDark ? 'text-zinc-400 hover:text-white hover:bg-white/5' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'}`
                        }
                      `}
                    >
                      <Icon 
                        size={16} 
                        className={`transition-colors duration-200 ${
                          active 
                            ? theme.iconColor
                            : (theme.isDark ? 'text-zinc-500 group-hover:text-white' : 'text-gray-400 group-hover:text-gray-600')
                        }`} 
                        strokeWidth={active ? 2.5 : 2}
                      />
                      <span>{link.name}</span>
                    </Link>
                  );
                })}
                
                {isAdmin && (
                   <Link to="/admin" className={`px-3 py-1.5 rounded-full text-sm font-bold flex items-center gap-1.5 transition-colors select-none ${theme.isDark ? 'text-red-400 hover:bg-red-500/10' : 'text-red-600 hover:bg-red-50'}`}>
                      <Shield size={16} strokeWidth={2} />
                      Admin
                   </Link>
                )}
              </div>
            </div>
            
            {/* Desktop: Search Bar & Actions */}
            <div className="hidden md:flex items-center gap-3 flex-1 justify-end">
              
              {/* Enhanced Search Bar - Hidden on EcoStore */}
              {!isEcoStore && (
                <form onSubmit={handleSearch} className="relative w-full max-w-xs group flex items-center">
                    <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search..."
                    className={`block w-full pl-9 pr-3 h-9 border rounded-full leading-5 focus:outline-none focus:ring-2 text-sm transition-all shadow-sm ${
                        theme.isDark 
                        ? 'bg-zinc-900 border-zinc-700 text-white placeholder-zinc-500 focus:border-purple-500 focus:ring-purple-500/50' 
                        : `bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400 focus:bg-white focus:ring-${theme.focusRing} focus:border-transparent`
                    }`}
                    />
                    <button 
                    type="submit"
                    className={`absolute left-0 pl-3 h-full flex items-center justify-center transition cursor-pointer bg-transparent border-none ${
                        theme.isDark 
                        ? 'text-zinc-500 group-focus-within:text-purple-500 hover:text-purple-400' 
                        : `text-gray-400 group-focus-within:${theme.iconColor} hover:${theme.iconColor}`
                    }`}
                    aria-label="Search"
                    >
                    <Search size={16} />
                    </button>
                </form>
              )}
              
              {/* Common Actions */}
              {/* Cart Button Removed from Header as requested */}

              {user && (
                 <>
                  <Link to="/messages" className={`${theme.isDark ? 'text-zinc-400 hover:text-white' : 'text-gray-400 hover:text-gray-600'} relative transition p-1 hover:bg-black/5 rounded-full`}>
                    <MessageCircle size={20} />
                    {unreadCount > 0 && (
                        <span className={`absolute -top-1 -right-1 ${theme.isDark ? 'bg-purple-500 text-white' : `${theme.bg} text-white`} text-[10px] min-w-[16px] h-4 px-1 flex items-center justify-center rounded-full font-bold shadow-sm border ${theme.isDark ? 'border-zinc-900' : 'border-white'}`}>
                            {unreadCount > 9 ? '9+' : unreadCount}
                        </span>
                    )}
                  </Link>
                 </>
              )}

              {/* Sell Button - Hidden on EcoStore */}
              {!isEcoStore && (
                <Link to="/sell" className={`${theme.isDark ? 'bg-purple-600 hover:bg-purple-500 text-white' : `${theme.bg} text-white`} font-semibold py-2 px-4 rounded-xl flex items-center shadow-lg ${theme.shadow} transition transform hover:-translate-y-0.5 text-sm select-none`}>
                    <PlusCircle size={16} className="mr-1.5" />
                    Sell
                </Link>
              )}
              
              {user ? (
                 <div className={`flex items-center gap-3 pl-2 border-l ${theme.isDark ? 'border-zinc-700' : 'border-gray-200'}`}>
                   <Link to="/dashboard" className="flex items-center gap-2 group select-none">
                      <div className={`h-8 w-8 rounded-full ${theme.isDark ? 'bg-zinc-800 text-purple-400 border-zinc-700' : `${theme.lightBg} ${theme.text} border ${theme.border}`} flex items-center justify-center transition group-hover:ring-2 ${theme.ring} ring-offset-2 border`}>
                          <span className="text-xs font-bold">{user.name?.charAt(0).toUpperCase()}</span>
                      </div>
                   </Link>
                 </div>
              ) : (
                  <Link to="/login" className={`flex items-center gap-2 font-medium ml-2 px-3 py-1.5 rounded-lg transition text-sm select-none ${theme.isDark ? 'bg-zinc-800 text-white hover:bg-zinc-700' : 'bg-gray-50 text-gray-700 hover:bg-gray-100 hover:text-gray-900'}`}>
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center ${theme.isDark ? 'bg-zinc-700' : 'bg-gray-200'}`}>
                          <UserIcon size={12} />
                      </div>
                      Login
                  </Link>
              )}
            </div>

            {/* Mobile Header Elements */}
            <div className="flex items-center md:hidden gap-2">
               {/* Mobile Search Icon - Hidden on EcoStore */}
               {!isEcoStore && (
                   <Link to="/browse" className={`${theme.isDark ? 'bg-zinc-800 text-white' : 'bg-gray-100 text-gray-600'} p-1.5 rounded-full`}>
                        <Search size={18} />
                   </Link>
               )}
               
               {/* Mobile Cart Icon Removed */}

              {/* EcoStore: Profile Icon instead of Menu */}
              {isEcoStore ? (
                  <Link 
                    to={user ? "/dashboard" : "/login"}
                    className={`inline-flex items-center justify-center p-1.5 rounded-md focus:outline-none ${theme.isDark ? 'text-zinc-400 hover:text-white hover:bg-zinc-800' : 'text-gray-400 hover:text-gray-500 hover:bg-gray-100'}`}
                  >
                    <UserIcon size={22} />
                  </Link>
              ) : (
                  <button
                    onClick={() => setIsOpen(!isOpen)}
                    className={`inline-flex items-center justify-center p-1.5 rounded-md focus:outline-none ${theme.isDark ? 'text-zinc-400 hover:text-white hover:bg-zinc-800' : 'text-gray-400 hover:text-gray-500 hover:bg-gray-100'}`}
                  >
                    {isOpen ? <X size={22} /> : <Menu size={22} />}
                  </button>
              )}
            </div>
          </div>
        </div>
        
        {/* Mobile Menu (Hamburger) */}
        <div 
          className={`md:hidden overflow-hidden transition-all duration-300 ease-in-out ${
              isOpen ? 'max-h-[85vh] opacity-100 border-t shadow-lg' : 'max-h-0 opacity-0'
          } ${theme.isDark ? 'bg-zinc-950 border-zinc-800' : 'bg-white border-gray-100'}`}
        >
          <div className="pt-4 pb-6 space-y-2 px-4 overflow-y-auto max-h-[85vh]">
              {navLinks.map((link) => (
              <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors select-none ${
                      isActive(link) 
                      ? `${theme.lightBg} ${theme.text}` 
                      : `${theme.isDark ? 'text-zinc-400 hover:bg-zinc-800 hover:text-white' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'}`
                  }`}
              >
                  <link.icon size={18} className={isActive(link) ? theme.iconColor : (theme.isDark ? 'text-zinc-500' : 'text-gray-400')} />
                  {link.name}
              </Link>
              ))}
              
              {isAdmin && (
                  <Link
                      to="/admin"
                      onClick={() => setIsOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50 select-none"
                  >
                      <Shield size={18} />
                      Admin Dashboard
                  </Link>
              )}
              
              {!user && (
                  <Link to="/login" onClick={() => setIsOpen(false)} className={`flex items-center justify-center gap-2 w-full mt-2 py-3 rounded-xl font-bold transition text-sm select-none ${theme.isDark ? 'bg-zinc-800 text-white hover:bg-zinc-700' : 'bg-gray-100 text-gray-900 hover:bg-gray-200'}`}>
                      <LogIn size={18} />
                      Login / Sign Up
                  </Link>
              )}
          </div>
        </div>
      </nav>

      {/* CART DRAWER OVERLAY */}
      {isCartOpen && (
          <div className="fixed inset-0 z-[60] flex justify-end">
              <div className="absolute inset-0 bg-black/50 backdrop-blur-sm animate-in fade-in duration-300" onClick={() => setIsCartOpen(false)}></div>
              <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
                  <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-gray-50">
                      <h2 className="text-lg font-bold flex items-center gap-2">
                          <ShoppingCart size={20} className="text-forest"/> Your Cart
                          <span className="bg-gray-200 text-gray-600 text-xs px-2 py-0.5 rounded-full">{cart.length}</span>
                      </h2>
                      <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-gray-200 rounded-full transition"><X size={20}/></button>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                      {cart.length === 0 ? (
                          <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-3">
                              <ShoppingBag size={48} className="opacity-20" />
                              <p>Your cart is empty.</p>
                              <button onClick={() => { setIsCartOpen(false); navigate(getBrowsePath()); }} className="text-forest font-bold text-sm hover:underline">Start Shopping</button>
                          </div>
                      ) : (
                          cart.map((item) => (
                              <div key={item.id} className="flex gap-3 items-center bg-white p-2 rounded-xl border border-gray-100 shadow-sm">
                                  <div className="h-16 w-16 rounded-lg bg-gray-100 overflow-hidden flex-shrink-0">
                                      <img src={item.image} alt={item.title} className="h-full w-full object-cover" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                      <h4 className="font-bold text-gray-900 text-sm truncate">{item.title}</h4>
                                      <p className="text-xs text-gray-500 truncate">{item.seller.name}</p>
                                      <div className="flex justify-between items-center mt-1">
                                          <p className="text-forest font-bold text-sm">₹{item.price}</p>
                                          {item.quantity > 1 && <span className="text-xs font-bold text-gray-500">x{item.quantity}</span>}
                                      </div>
                                  </div>
                                  <button onClick={() => removeFromCart(item.id)} className="p-2 text-gray-400 hover:text-red-500 transition">
                                      <Trash2 size={18} />
                                  </button>
                              </div>
                          ))
                      )}
                  </div>
                  
                  {cart.length > 0 && (
                      <div className="p-4 border-t border-gray-100 bg-gray-50">
                          <div className="flex justify-between items-center mb-4">
                              <span className="text-gray-600 font-medium">Total</span>
                              <span className="text-2xl font-black text-gray-900">₹{cartTotal.toLocaleString()}</span>
                          </div>
                          <button className="w-full bg-forest text-white py-3 rounded-xl font-bold hover:bg-green-700 transition shadow-lg flex items-center justify-center gap-2">
                              Checkout <ArrowRight size={18} />
                          </button>
                      </div>
                  )}
              </div>
          </div>
      )}

      {/* Mobile Bottom Navigation Bar - Using Grid for perfect alignment */}
      {/* Hidden on EcoStore and EcoLearn as per requirements to reduce clutter */}
      {!isEcoStore && !isEcoLearn && !itemTypeParam && (
        <div className="md:hidden fixed bottom-0 left-0 w-full bg-white border-t border-gray-200 z-50 pb-safe">
            <div className={`grid ${showSellButton ? 'grid-cols-5' : 'grid-cols-4'} h-16 items-center`}>
            <BottomNavLink to="/" icon={Home} label="Home" active={isActive({path: '/'}) && !isEcoStore && !isEcoLearn} theme={theme} />
            <BottomNavLink to={getBrowsePath()} icon={Compass} label="Explore" active={isActive({isBrowse: true})} theme={theme} />
            
            {/* Center Sell Button - Only shown if NOT in EcoStore section */}
            {showSellButton && (
                <div className="flex justify-center items-center h-full relative z-20">
                    <Link 
                        to="/sell" 
                        className={`absolute -top-6 flex items-center justify-center h-14 w-14 ${theme.bg} text-white rounded-full shadow-lg ${theme.shadow} hover:scale-105 transition ring-4 ring-white select-none`}
                        aria-label="Sell"
                    >
                    <PlusCircle size={28} />
                    </Link>
                </div>
            )}

            {/* Chat Link - Mobile */}
            <Link 
                to="/messages" 
                className={`flex flex-col items-center justify-center w-full h-full space-y-1 select-none ${isActive({path: '/messages'}) ? theme.text : 'text-gray-400'}`}
            >
                <div className="relative">
                    <MessageCircle size={22} strokeWidth={isActive({path: '/messages'}) ? 2.5 : 2} />
                    {unreadCount > 0 && (
                        <span className={`absolute -top-1.5 -right-1.5 ${theme.bg} text-white text-[9px] min-w-[14px] h-[14px] px-0.5 flex items-center justify-center rounded-full font-bold shadow-sm border border-white z-10`}>
                            {unreadCount > 9 ? '9+' : unreadCount}
                        </span>
                    )}
                </div>
                <span className="text-[10px] font-medium">Chat</span>
            </Link>

            <BottomNavLink to={user ? "/dashboard" : "/login"} icon={UserIcon} label={user ? "Profile" : "Login"} active={isActive({path: '/dashboard'}) || isActive({path: '/login'})} theme={theme} />
            </div>
        </div>
      )}
    </>
  );
};

const BottomNavLink = ({ to, icon: Icon, label, active, theme }: { to: string, icon: any, label: string, active: boolean, theme: any }) => (
  <Link to={to} className={`flex flex-col items-center justify-center w-full h-full space-y-1 select-none ${active ? theme.text : 'text-gray-400'}`}>
    <Icon size={22} strokeWidth={active ? 2.5 : 2} />
    <span className="text-[10px] font-medium">{label}</span>
  </Link>
);

const LeafIcon = () => (
   <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/></svg>
);

export default Navbar;
