import React, { useState } from 'react';
import { Item } from '../types';
import { Clock, Heart, MapPin, BadgeCheck, ShoppingBag, Zap, Truck, CalendarClock, ShoppingCart, Check, Plus, Minus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useStore } from '../contexts/StoreContext';

interface ItemCardProps {
  item: Item;
  featured?: boolean;
  variant?: 'default' | 'dark' | 'rose' | 'male';
}

const ItemCard: React.FC<ItemCardProps> = ({ item, featured, variant }) => {
  const { toggleWishlist, isInWishlist, addToCart, getItemQuantity, updateQuantity } = useStore();
  const [isAdded, setIsAdded] = useState(false);
  
  const isFlashSale = item.type === 'flash';
  const isRental = item.type === 'rent' || item.type === 'roommate';
  const isDonation = item.type === 'donate';
  const isStore = item.type === 'store';
  const inWishlist = isInWishlist(item.id);
  const qty = getItemQuantity(item.id);
  
  const effectiveVariant = variant || (isStore ? 'dark' : 'default');
  const location = item.seller.campus || "Student Center";

  let containerClasses = 'bg-white border-gray-100 hover:shadow-lg shadow-sm';
  let textPrimary = 'text-gray-900';
  let textSecondary = 'text-gray-500';
  let dividerColor = 'border-gray-50';
  let iconColor = 'text-gray-400';
  let hoverGradientClass = 'group-hover:text-forest'; 
  let wishlistBtnClass = 'bg-white/90 text-gray-400 hover:text-red-500 shadow-sm';

  if (effectiveVariant === 'dark') {
      containerClasses = 'bg-zinc-900 border-zinc-800 hover:border-purple-500/50 hover:shadow-[0_0_25px_-5px_rgba(168,85,247,0.15)] shadow-none';
      textPrimary = 'text-white';
      textSecondary = 'text-zinc-400';
      dividerColor = 'border-zinc-800';
      iconColor = 'text-purple-500';
      hoverGradientClass = 'group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-purple-400 group-hover:to-pink-400';
      wishlistBtnClass = 'bg-black/50 text-white hover:bg-purple-500 hover:text-white';
  } else if (effectiveVariant === 'rose') {
      containerClasses = 'bg-white border-rose-100 hover:border-rose-300 hover:shadow-[0_0_20px_-5px_rgba(244,63,94,0.15)] shadow-sm';
      textPrimary = 'text-gray-900';
      textSecondary = 'text-gray-500';
      dividerColor = 'border-rose-50';
      iconColor = 'text-rose-400';
      hoverGradientClass = 'group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-rose-500 group-hover:to-orange-400';
      wishlistBtnClass = 'bg-white/90 text-rose-400 hover:text-rose-600 shadow-sm ring-1 ring-rose-100';
  } else if (effectiveVariant === 'male') {
      containerClasses = 'bg-[#1e293b] border-slate-700 hover:border-blue-500/50 hover:shadow-[0_0_20px_-5px_rgba(59,130,246,0.3)] shadow-none';
      textPrimary = 'text-slate-50';
      textSecondary = 'text-slate-400';
      dividerColor = 'border-slate-700';
      iconColor = 'text-blue-400';
      hoverGradientClass = 'group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-cyan-300';
      wishlistBtnClass = 'bg-slate-900/60 text-slate-300 hover:text-white hover:bg-blue-600 border border-slate-600';
  }

  const discountPercentage = (item.originalPrice && item.originalPrice > item.price)
    ? Math.round(((item.originalPrice - item.price) / item.originalPrice) * 100)
    : 0;

  let deliveryDisplay = null;
  const iconClasses = "mr-0.5 flex-shrink-0";
  let deliveryIcon = <Truck size={9} strokeWidth={2.5} className={iconClasses} />;
  let deliveryColor = effectiveVariant === 'male' ? 'text-blue-400' : 'text-cyan-400';
  let deliveryAnimation = '';

  if (isStore && item.deliveryDuration) {
      const isNumeric = /^\d+$/.test(item.deliveryDuration);
      if (isNumeric) {
          const daysToAdd = parseInt(item.deliveryDuration, 10);
          const date = new Date();
          date.setDate(date.getDate() + daysToAdd);
          const dateStr = date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
          deliveryDisplay = `Get it by ${dateStr}`;
          deliveryIcon = <CalendarClock size={9} strokeWidth={2.5} className={iconClasses} />;
      } else {
          deliveryDisplay = item.deliveryDuration;
          if (deliveryDisplay.toLowerCase().includes('10 min')) {
              deliveryIcon = <Zap size={9} fill="currentColor" strokeWidth={2.5} className={`${iconClasses} animate-lightning`} />;
              deliveryColor = 'text-yellow-400'; 
          }
      }
  }

  const handleAddToCart = (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      addToCart(item);
      setIsAdded(true);
      setTimeout(() => setIsAdded(false), 2000);
  };

  const handleIncrement = (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      updateQuantity(item.id, 1);
  };

  const handleDecrement = (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      updateQuantity(item.id, -1);
  };

  return (
    <div className={`group relative rounded-lg md:rounded-xl border overflow-hidden transition-all duration-300 flex flex-col h-full snap-start flex-shrink-0 min-w-[145px] w-[145px] md:min-w-0 md:w-full ${containerClasses}`}>
      <div className="aspect-[4/3] bg-gray-100 relative overflow-hidden">
        <img
          src={item.image}
          alt={item.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        
        {isAdded && (
            <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/20 backdrop-blur-sm animate-in fade-in duration-200">
                <div className="bg-white rounded-lg px-2 py-1 shadow-xl flex flex-col items-center animate-in zoom-in-50 duration-300">
                    <span className="text-[8px] font-black text-gray-900 uppercase tracking-wider">Added</span>
                </div>
            </div>
        )}
        
        <div className="absolute top-1 left-1 md:top-3 md:left-3 flex flex-wrap gap-0.5 md:gap-1 max-w-[85%]">
            {isFlashSale && (
                <span className="bg-amber text-white text-[7px] md:text-[10px] font-bold px-1 py-0.5 rounded-full uppercase tracking-wide shadow-sm flex items-center">
                    <Clock size={7} className="mr-0.5" /> Flash
                </span>
            )}
            {isRental && (
                <span className="bg-blue-500 text-white text-[7px] md:text-[10px] font-bold px-1 py-0.5 rounded-full uppercase tracking-wide shadow-sm">
                    {item.type === 'roommate' ? 'Room' : 'Rent'}
                </span>
            )}
            {isDonation && (
                <span className="bg-purple-500 text-white text-[7px] md:text-[10px] font-bold px-1 py-0.5 rounded-full uppercase tracking-wide shadow-sm">
                    Free
                </span>
            )}
            {item.isPremium && (
                <span className="bg-black/90 backdrop-blur-md text-white text-[7px] md:text-[10px] font-bold px-1 py-0.5 rounded-full uppercase tracking-wide shadow-sm flex items-center border border-purple-500/30">
                    Premium
                </span>
            )}
        </div>

        <button 
            onClick={(e) => { e.preventDefault(); toggleWishlist(item); }}
            className={`absolute top-1 right-1 md:top-3 md:right-3 p-1 md:p-2 backdrop-blur-sm rounded-full transition-colors z-10 ${wishlistBtnClass} ${inWishlist ? 'text-red-500 bg-white shadow-md' : ''}`}
        >
          <Heart size={10} className="md:w-4 md:h-4" fill={inWishlist ? "currentColor" : "none"} />
        </button>

        {isFlashSale && item.flashSaleEndsAt && (
             <div className="absolute bottom-1 left-1 right-1 md:bottom-3 md:left-3 md:right-3 bg-white/95 backdrop-blur-sm px-1 py-0.5 md:px-3 md:py-1.5 rounded-md md:rounded-lg shadow-sm flex items-center text-[7px] md:text-xs font-semibold text-red-600 justify-center">
                <Clock size={7} className="mr-0.5 md:w-3 md:h-3 md:mr-1.5" />
                <span className="truncate">Ending Soon</span>
             </div>
        )}
      </div>

      <div className="p-1.5 md:p-4 flex flex-col flex-grow">
        <div className="flex-grow">
            <h3 className={`font-bold text-[11px] md:text-base line-clamp-2 leading-tight mb-0.5 md:mb-1 transition-all ${hoverGradientClass} ${textPrimary}`} title={item.title}>
                <Link to={`/item/${item.id}?type=${item.type}`}>
                    <span className="absolute inset-0" />
                    {item.title}
                </Link>
            </h3>
            
            {!isStore && (
                <div className={`flex items-center text-[8px] md:text-xs mb-1 md:mb-2 ${textSecondary}`}>
                    <MapPin size={8} className={`mr-0.5 md:mr-1 flex-shrink-0 ${iconColor}`} />
                    <span className="truncate">{location}</span>
                </div>
            )}

            {isStore && deliveryDisplay && (
                <div className={`flex items-center text-[7px] md:text-[10px] font-bold uppercase tracking-wide mb-1.5 md:mb-3 ${deliveryColor} ${deliveryAnimation}`}>
                    {deliveryIcon}
                    <span className="truncate">{deliveryDisplay}</span>
                </div>
            )}
        </div>

        <div className={`mt-auto pt-1 md:pt-2 border-t ${dividerColor}`}>
            <div className="flex items-end justify-between gap-0.5">
                <div className="flex flex-col">
                    {item.type === 'donate' ? (
                        <span className="text-sm md:text-xl font-bold text-forest">Free</span>
                    ) : (
                        <>
                            <div className="flex flex-wrap items-baseline gap-x-0.5 md:gap-x-1">
                                <span className={`text-sm md:text-xl font-black ${textPrimary}`}>
                                    ₹{item.price.toLocaleString()}
                                    {(item.type === 'rent' || item.type === 'roommate') && <span className="text-[7px] md:text-xs text-gray-500 font-normal ml-0.5">/{item.rentalPeriod || 'day'}</span>}
                                </span>
                                {item.originalPrice && item.originalPrice > item.price && (
                                    <span className="text-[8px] md:text-[10px] text-gray-400 line-through decoration-gray-400/70">₹{item.originalPrice.toLocaleString()}</span>
                                )}
                            </div>
                            
                            {discountPercentage > 0 && (
                                <span className="text-[7px] md:text-[10px] font-bold text-green-600 w-fit px-1 py-0.5 bg-green-100 rounded mt-0.5">
                                    {discountPercentage}% OFF
                                </span>
                            )}
                        </>
                    )}
                </div>
                
                <div className="flex items-center gap-0.5 md:gap-1 z-20 relative flex-shrink-0">
                     {isStore ? (
                        qty > 0 ? (
                            <div className="flex items-center bg-white border border-black rounded-md md:rounded-lg shadow-sm h-6 md:h-8 overflow-hidden">
                                <button 
                                    onClick={handleDecrement}
                                    className="px-1 md:px-2 h-full flex items-center justify-center text-black hover:bg-gray-50 transition active:bg-gray-200"
                                >
                                    <Minus size={9} strokeWidth={3} />
                                </button>
                                <span className="px-0.5 md:px-1 text-[8px] md:text-xs font-black text-black min-w-[12px] md:min-w-[18px] text-center select-none">{qty}</span>
                                <button 
                                    onClick={handleIncrement}
                                    className="px-1 md:px-2 h-full flex items-center justify-center text-black hover:bg-gray-50 transition active:bg-gray-200"
                                >
                                    <Plus size={9} strokeWidth={3} />
                                </button>
                            </div>
                        ) : (
                            <button
                                onClick={handleAddToCart}
                                className={`flex items-center gap-0.5 px-1.5 py-1 md:px-3 md:py-1.5 rounded-md md:rounded-lg text-[8px] md:text-xs font-bold uppercase tracking-wide transition-all shadow-sm active:scale-95 ${
                                    effectiveVariant === 'dark'
                                        ? 'bg-purple-600 text-white'
                                        : effectiveVariant === 'rose'
                                            ? 'bg-rose-100 text-rose-600 border border-rose-200' 
                                            : effectiveVariant === 'male'
                                                ? 'bg-[#000080] text-white'
                                                : 'bg-forest text-white'
                                }`}
                            >
                                <ShoppingCart size={9} strokeWidth={2.5} />
                                <span>Add</span>
                            </button>
                        )
                     ) : (
                        <div className="flex items-center gap-0.5 max-w-[60px] md:max-w-none">
                             <div className="w-3.5 h-3.5 md:w-6 md:h-6 rounded-full bg-gray-100 border border-white shadow-sm flex items-center justify-center flex-shrink-0 overflow-hidden">
                                 <span className="text-[7px] md:text-[10px] font-bold text-gray-500">{item.seller.name?.charAt(0).toUpperCase()}</span>
                             </div>
                             <span className="text-[8px] md:text-[10px] text-gray-600 font-medium truncate">
                                {item.seller.name.split(' ')[0]}
                             </span>
                             {item.seller.verified && (
                                <div title="Verified Seller" className="-ml-0.5 flex items-center justify-center">
                                   <BadgeCheck size={9} className="text-blue-500" />
                                </div>
                             )}
                        </div>
                     )}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ItemCard;