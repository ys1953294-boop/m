
import React from 'react';
import { Facebook, Twitter, Instagram } from 'lucide-react';
import { useLocation, useSearchParams } from 'react-router-dom';

const Footer: React.FC = () => {
  const location = useLocation();
  const [searchParams] = useSearchParams();

  const activeSection = searchParams.get('section');
  const typeParam = searchParams.get('type');

  // Determine context
  // EcoStore: Home section 'ecostore' OR browse type 'store'
  const isEcoStore = (location.pathname === '/' && activeSection === 'ecostore') || typeParam === 'store';
  
  // EcoLearn: Home section 'ecolearn' OR browse type 'learn' OR any path starting with /learn
  const isEcoLearn = (location.pathname === '/' && activeSection === 'ecolearn') || typeParam === 'learn' || location.pathname.startsWith('/learn');

  // Theme Configuration
  const getTheme = () => {
    if (isEcoStore) {
        return {
            bg: 'bg-zinc-950',
            border: 'border-zinc-800',
            text: 'text-zinc-400',
            textHover: 'hover:text-purple-400',
            iconBg: 'bg-zinc-900',
            iconHover: 'hover:bg-zinc-800',
            logoBg: 'bg-purple-600 text-white',
            divider: 'text-zinc-800',
            subtext: 'text-zinc-500',
            borderTop: 'border-zinc-900'
        };
    }
    if (isEcoLearn) {
        return {
            bg: 'bg-[#083344]', // Cyan-950
            border: 'border-cyan-900',
            text: 'text-cyan-200',
            textHover: 'hover:text-white',
            iconBg: 'bg-cyan-900/50',
            iconHover: 'hover:bg-cyan-800',
            logoBg: 'bg-cyan-600 text-white',
            divider: 'text-cyan-800',
            subtext: 'text-cyan-400/60',
            borderTop: 'border-cyan-900'
        };
    }
    // Default EcoDorm (Forest Theme)
    return {
        bg: 'bg-forest-dark',
        border: 'border-green-900',
        text: 'text-green-100',
        textHover: 'hover:text-white',
        iconBg: 'bg-white/10',
        iconHover: 'hover:bg-white/20',
        logoBg: 'bg-white text-forest',
        divider: 'text-green-200/40',
        subtext: 'text-green-200/60',
        borderTop: 'border-white/10'
    };
  };

  const theme = getTheme();

  return (
    <footer className={`${theme.bg} ${theme.border} border-t transition-colors duration-500`}>
      <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          
          {/* Logo Section */}
          <div className="flex items-center gap-3">
             <div className={`${theme.logoBg} p-1.5 rounded-lg shadow-sm`}>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/></svg>
             </div>
             <div>
                 <span className={`font-bold text-xl tracking-tight ${isEcoStore ? 'text-white' : 'text-white'}`}>
                    Eco{isEcoStore ? <span className="text-purple-400">Store</span> : isEcoLearn ? <span className="text-cyan-400">Learn</span> : <span>Dorm</span>}
                 </span>
                 <p className={`text-[10px] uppercase tracking-wider font-medium ${theme.subtext}`}>
                    {isEcoStore ? 'Premium Campus Gear' : isEcoLearn ? 'Academic Resources' : 'Sustainable Marketplace'}
                 </p>
             </div>
          </div>

          {/* Social Icons */}
          <div className="flex items-center gap-6">
             <div className="flex space-x-4">
                <a 
                  href="https://www.instagram.com/yash.the.builder?igsh=MWUxNWY1dTR1MGcyOA==" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className={`p-2 rounded-full transition ${theme.iconBg} ${theme.iconHover} ${theme.text} hover:scale-110`}
                >
                  <Instagram size={16} />
                </a>
                <a href="#" className={`p-2 rounded-full transition ${theme.iconBg} ${theme.iconHover} ${theme.text} hover:scale-110`}><Twitter size={16} /></a>
                <a href="#" className={`p-2 rounded-full transition ${theme.iconBg} ${theme.iconHover} ${theme.text} hover:scale-110`}><Facebook size={16} /></a>
             </div>
          </div>
          
        </div>
        
        {/* Bottom Links */}
        <div className={`mt-8 pt-6 border-t flex flex-col md:flex-row justify-between items-center gap-4 ${theme.borderTop}`}>
          <p className={`text-[10px] ${theme.subtext}`}>&copy; 2026 EcoDorm. Built with ❤️ for Students.</p>
          <div className={`flex gap-6 text-[10px] font-medium ${theme.subtext}`}>
             <a href="#" className={`transition ${theme.textHover}`}>Privacy Policy</a>
             <a href="#" className={`transition ${theme.textHover}`}>Terms of Service</a>
             <a 
               href="https://www.instagram.com/yash.the.builder?igsh=MWUxNWY1dTR1MGcyOA==" 
               target="_blank"
               rel="noopener noreferrer"
               className={`transition ${theme.textHover}`}
             >
               Contact Support
             </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
