
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { Mic, MicOff, Sparkles, X, Loader2 } from 'lucide-react';
import { useLocation, useSearchParams } from 'react-router-dom';

const VoiceAssistant: React.FC = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  
  const location = useLocation();
  const [searchParams] = useSearchParams();

  // Audio Context Refs
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  // Track session promise to ensure we use the active one
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  // Keep track of sources to stop them on interrupt
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Check for EcoStore context to hide AI
  const isEcoStore = 
    (location.pathname === '/' && searchParams.get('section') === 'ecostore') ||
    (location.pathname === '/browse' && searchParams.get('type') === 'store') ||
    (searchParams.get('type') === 'store'); // General catch for items/other pages with type=store

  if (isEcoStore) return null;

  const disconnect = () => {
    sessionPromiseRef.current = null;
    
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }

    if (inputAudioContextRef.current) {
      inputAudioContextRef.current.close().catch(() => {});
      inputAudioContextRef.current = null;
    }

    if (outputAudioContextRef.current) {
      outputAudioContextRef.current.close().catch(() => {});
      outputAudioContextRef.current = null;
    }

    sourcesRef.current.forEach(source => source.stop());
    sourcesRef.current.clear();

    setIsConnected(false);
    setIsSpeaking(false);
    setIsConnecting(false);
    nextStartTimeRef.current = 0;
  };

  const startSession = async () => {
    try {
      setIsConnecting(true);
      
      // 1. Initialize Audio Contexts
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      inputAudioContextRef.current = new AudioContextClass({ sampleRate: 16000 });
      outputAudioContextRef.current = new AudioContextClass({ sampleRate: 24000 });
      
      // 2. Get User Media
      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaStreamRef.current = stream;
      } catch (e) {
        console.error("Microphone access denied:", e);
        alert("Please allow microphone access to use the assistant.");
        setIsConnecting(false);
        return;
      }

      // 3. Initialize Gemini
      // FIX: Use process.env.API_KEY exclusively as per guidelines
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          systemInstruction: `
            You are Eco, a female personal assistant created by Yash.
            
            ROLE:
            - Help students with buying, selling, renting, and donating on EcoDorm.
            - Keep answers short and concise.
            - Maintain a friendly, helpful, and polite persona.

            LANGUAGE:
            - Speak primarily in Hindi mixed with English (Hinglish).
          `,
        },
        callbacks: {
          onopen: () => {
            setIsConnected(true);
            setIsConnecting(false);
            
            if (!inputAudioContextRef.current) return;
            
            const source = inputAudioContextRef.current.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              
              sessionPromise.then(session => {
                  session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContextRef.current.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const serverContent = message.serverContent;
            
            if (serverContent?.modelTurn?.parts?.[0]?.inlineData) {
              const base64Audio = serverContent.modelTurn.parts[0].inlineData.data;
              if (base64Audio && outputAudioContextRef.current) {
                setIsSpeaking(true);
                
                // Decode
                const audioData = decode(base64Audio);
                const audioBuffer = await decodeAudioData(audioData, outputAudioContextRef.current, 24000, 1);
                
                // Play
                playAudio(audioBuffer);
              }
            }
            
            if (serverContent?.turnComplete) {
              setIsSpeaking(false);
            }

            if (serverContent?.interrupted) {
                sourcesRef.current.forEach(source => {
                    source.stop();
                    sourcesRef.current.delete(source);
                });
                nextStartTimeRef.current = 0;
                setIsSpeaking(false);
            }
          },
          onclose: () => {
            disconnect();
          },
          onerror: (err) => {
            console.error("Gemini Live Error:", err);
            disconnect();
          }
        }
      });

      sessionPromiseRef.current = sessionPromise;

    } catch (error) {
      console.error("Failed to start voice session:", error);
      disconnect();
    }
  };

  // Helper functions from guidelines
  function createBlob(data: Float32Array) {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
        int16[i] = data[i] * 32768;
    }
    return {
        data: encode(new Uint8Array(int16.buffer)),
        mimeType: 'audio/pcm;rate=16000',
    };
  }

  function encode(bytes: Uint8Array) {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  function decode(base64: string) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }

  async function decodeAudioData(
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
        const channelData = buffer.getChannelData(channel);
        for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
        }
    }
    return buffer;
  }

  const playAudio = (audioBuffer: AudioBuffer) => {
    if (!outputAudioContextRef.current) return;
    
    const context = outputAudioContextRef.current;
    const source = context.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(context.destination);
    
    source.addEventListener('ended', () => {
        sourcesRef.current.delete(source);
        if (sourcesRef.current.size === 0) setIsSpeaking(false);
    });

    const currentTime = context.currentTime;
    if (nextStartTimeRef.current < currentTime) {
      nextStartTimeRef.current = currentTime;
    }
    
    source.start(nextStartTimeRef.current);
    nextStartTimeRef.current += audioBuffer.duration;
    sourcesRef.current.add(source);
  };

  const toggleAssistant = () => {
    if (isConnected || isConnecting) {
      disconnect();
    } else {
      startSession();
    }
  };

  return (
    <div className="fixed bottom-24 md:bottom-6 right-6 z-50">
        {(isConnected || isConnecting) && (
            <div className="absolute bottom-full mb-3 right-0 bg-white shadow-lg rounded-lg px-4 py-2 flex items-center gap-2 border border-green-100 min-w-[200px] animate-fade-in-up">
                <div className={`h-2 w-2 rounded-full ${isConnecting ? 'bg-yellow-400 animate-pulse' : (isSpeaking ? 'bg-green-500 animate-pulse' : 'bg-gray-400')}`}></div>
                <div>
                   <p className="text-xs font-bold text-gray-900">Eco Assistant</p>
                   <p className="text-[10px] text-gray-500">
                     {isConnecting ? 'Connecting...' : (isSpeaking ? 'Speaking...' : 'Listening...')}
                   </p>
                </div>
                <button onClick={disconnect} className="ml-auto text-gray-400 hover:text-red-500">
                    <X size={14} />
                </button>
            </div>
        )}

        <button
            onClick={toggleAssistant}
            disabled={isConnecting}
            className={`h-14 w-14 rounded-full shadow-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 ${
                isConnected || isConnecting
                ? 'bg-red-500 text-white ring-4 ring-red-100' 
                : 'bg-forest text-white ring-4 ring-green-100 hover:bg-green-700'
            }`}
        >
            {isConnecting ? (
               <Loader2 size={24} className="animate-spin" />
            ) : isConnected ? (
                <div className="relative">
                    <MicOff size={24} />
                    <span className="absolute -top-1 -right-1 flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                    </span>
                </div>
            ) : (
                <div className="relative">
                    <Sparkles size={24} />
                </div>
            )}
        </button>
    </div>
  );
};

export default VoiceAssistant;
