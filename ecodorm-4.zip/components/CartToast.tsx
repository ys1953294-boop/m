
import React, { useEffect, useState } from 'react';
import { useStore } from '../contexts/StoreContext';
import { ShoppingBag, ArrowRight, X } from 'lucide-react';

const CartToast: React.FC = () => {
  const { showCartToast, setShowCartToast, setIsCartOpen, cart } = useStore();
  const [shouldRender, setShouldRender] = useState(false);
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    if (showCartToast) {
      setShouldRender(true);
      // Double rAF ensures the browser paints the initial state before applying the active class
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            setAnimate(true);
        });
      });
    } else {
      setAnimate(false);
      const timer = setTimeout(() => {
        setShouldRender(false);
      }, 300); // Wait for transition to finish
      return () => clearTimeout(timer);
    }
  }, [showCartToast]);

  if (!shouldRender) return null;

  const itemCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const handleViewCart = () => {
      // Open cart first
      setIsCartOpen(true);
      // Then hide toast (triggers exit animation via effect)
      setShowCartToast(false);
  };

  return (
    <div className={`fixed bottom-24 md:bottom-8 left-1/2 -translate-x-1/2 z-[100] w-[90%] max-w-sm transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) transform ${animate ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-4 opacity-0 scale-95'}`}>
      <div className="bg-white/95 backdrop-blur-xl text-gray-900 p-3 pl-4 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] flex items-center justify-between gap-4 border border-gray-100 ring-1 ring-black/5 hover:scale-[1.02] transition-transform duration-200 ease-out">
        <div className="flex items-center gap-3.5">
           <div className="bg-forest/10 p-2.5 rounded-full text-forest shadow-sm ring-1 ring-forest/20 animate-pulse">
             <ShoppingBag size={20} strokeWidth={2.5} />
           </div>
           <div>
             <p className="text-sm font-bold leading-none text-gray-900">Added to Cart</p>
             <p className="text-xs text-gray-500 mt-0.5 font-medium">{itemCount} item{itemCount !== 1 ? 's' : ''} in cart</p>
           </div>
        </div>
        <div className="flex items-center gap-2">
            <button 
              onClick={handleViewCart}
              className="bg-forest text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-green-700 transition-all duration-200 flex items-center gap-1.5 shadow-md shadow-green-900/20 active:scale-95 active:shadow-none"
            >
              View <ArrowRight size={14} strokeWidth={3} />
            </button>
            <button onClick={() => setShowCartToast(false)} className="text-gray-400 hover:text-gray-600 transition p-1.5 hover:bg-gray-100 rounded-full">
                <X size={18} />
            </button>
        </div>
      </div>
    </div>
  );
};

export default CartToast;
