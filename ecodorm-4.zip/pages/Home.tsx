import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowRight, BookOpen, Monitor, Sofa, Shirt, Utensils, MoreHorizontal, MessageCircle, Users, Leaf, Camera, Pencil, Sparkles, ShoppingBag, RefreshCw, Package, Lightbulb, GraduationCap, ChevronRight, Star, Coffee, Zap, Palette, Code, Video, Clock, ShieldCheck, Truck, PlayCircle, FileText, Headphones, Watch, Smartphone, Crown, Shield, Book, Search, Heart, X, LayoutGrid, ThumbsUp, Scissors, UserCheck, Smile, Activity, MapPin, ChevronDown, Navigation, LocateFixed, Building2, Eye, Gem, SprayCan, ShoppingCart, Gift, Plus, Loader2, Tag, ArrowUpRight, Calendar, Wallet } from 'lucide-react';
import { supabase } from '../lib/supabase';
import ItemCard from '../components/ItemCard';
import { Item } from '../types';
import { CAMPUS_OPTIONS } from '../constants';
import { useAuth } from '../contexts/AuthContext';
import { useStore } from '../contexts/StoreContext';

// --- CUSTOM ICONS FOR WOMEN'S SECTION ---

const JewelryIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M16 19H8l-1.5-9C6 7 8 4 12 4s6 3 5.5 6L16 19z" fill="currentColor" fillOpacity="0.2" />
    <path d="M12 19v3" />
    <path d="M7 22h10" />
    <path d="M9 7c0 3 1.5 5 3 5s3-2 3-5" stroke="currentColor" strokeWidth="1.5" />
    <circle cx="12" cy="14" r="1.5" fill="currentColor" className="text-yellow-200" /> 
    <path d="M12 12v2" />
  </svg>
);

const DressIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M9 2 L9 5" /> <path d="M15 2 L15 5" />
    <path d="M8 5 h8 l1 6 h-10 z" fill="currentColor" fillOpacity="0.2"/>
    <path d="M7 11 l-2 11 h14 l-2 -11" fill="currentColor" fillOpacity="0.2"/>
    <path d="M7 11 h10" />
    <path d="M12 11 v11" opacity="0.5"/>
  </svg>
);

const LipstickIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M10 8h4v6h-4z" />
    <path d="M10 8l1.5-5h1L14 8" fill="currentColor" fillOpacity="0.6"/>
    <rect x="7" y="14" width="10" height="8" rx="1" fill="currentColor" fillOpacity="0.2"/>
  </svg>
);

const PerfumeIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="14" r="6" fill="currentColor" fillOpacity="0.2"/>
    <rect x="10" y="6" width="4" height="2" />
    <rect x="9" y="2" width="6" height="4" rx="1" />
    <rect x="10" y="12" width="4" height="4" rx="1" stroke="currentColor"/>
    <path d="M18 5l2-2" opacity="0.5"/>
  </svg>
);

const BagIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M6 10 L5 21 H19 L18 10 H6 Z" fill="currentColor" fillOpacity="0.2"/>
    <path d="M9 10 V6 A3 3 0 0 1 15 6 V10" strokeWidth="1.5"/>
    <rect x="11" y="13" width="2" height="3" rx="0.5" fill="currentColor" />
    <path d="M6 18 h12" opacity="0.3" strokeDasharray="2 2" />
  </svg>
);

// --- MEN'S CUSTOM ICONS ---

const SneakerIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M3 16h18" strokeWidth="2" strokeLinecap="square" />
    <path d="M3 16c0-3 1-4 4-5 1-1 3-2 5-2 1 0 3 1 4 2v5" />
    <path d="M16 11l3 1c1 0 2 2 2 4" />
    <path d="M9 11l2-2" />
    <path d="M11 9l2-2" />
    <path d="M6 16v-2" opacity="0.3" />
    <path d="M18 16v-2" opacity="0.3" />
    <path d="M5 14h14" opacity="0.1" fill="currentColor" stroke="none" />
  </svg>
);

type SectionType = 'ecodorm' | 'ecostore' | 'ecolearn' | 'ecostyle';

const Home: React.FC = () => {
  const { user } = useAuth();
  const { setIsCartOpen, cart } = useStore();
  const [displayItems, setDisplayItems] = useState<Item[]>([]);
  const [suggestedItems, setSuggestedItems] = useState<Item[]>([]);
  const [sellHomeItems, setSellHomeItems] = useState<Item[]>([]);
  const [rentHomeItems, setRentHomeItems] = useState<Item[]>([]);
  const [roommateItems, setRoommateItems] = useState<Item[]>([]);
  const [donationHomeItems, setDonationHomeItems] = useState<Item[]>([]);
  const [menItems, setMenItems] = useState<Item[]>([]);
  const [womenItems, setWomenItems] = useState<Item[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [storeSearchQuery, setStoreSearchQuery] = useState('');
  const [heroBanners, setHeroBanners] = useState<string[]>([]);
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);
  const [userLocation, setUserLocation] = useState('Select Location');
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [locationQuery, setLocationQuery] = useState('');
  const [detectingLocation, setDetectingLocation] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();
  
  const validSections: SectionType[] = ['ecodorm', 'ecostore', 'ecolearn', 'ecostyle'];
  const rawSection = searchParams.get('section');
  const activeSection = (validSections.includes(rawSection as SectionType) ? rawSection : 'ecodorm') as SectionType;
  const categoryParam = searchParams.get('category');
  const navigate = useNavigate();

  useEffect(() => {
    updatePageContent();
  }, [activeSection, categoryParam]);

  useEffect(() => {
    if (user?.campus && userLocation === 'Select Location') {
        setUserLocation(user.campus);
    }
  }, [user]);

  useEffect(() => {
    if (activeSection === 'ecostore' && heroBanners.length > 1 && !categoryParam) {
        const interval = setInterval(() => {
            setCurrentBannerIndex((prev) => (prev + 1) % heroBanners.length);
        }, 4000);
        return () => clearInterval(interval);
    }
  }, [activeSection, heroBanners, categoryParam]);

  const setActiveSection = (section: SectionType) => {
      setSearchParams({ section });
      setCurrentBannerIndex(0);
  };

  const handleDetectLocation = () => {
      setDetectingLocation(true);
      if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
              async (position) => {
                  const { latitude, longitude } = position.coords;
                  try {
                      const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`);
                      const data = await response.json();
                      if (data && data.address) {
                          const addr = data.address;
                          const placeName = addr.college || addr.university || addr.suburb || addr.neighbourhood || addr.city_district || addr.city || addr.town || addr.village;
                          const region = addr.state_district || addr.state || "";
                          const formattedLocation = placeName ? `${placeName}${region ? `, ${region}` : ''}` : "Current Location";
                          setUserLocation(formattedLocation);
                      } else {
                          setUserLocation("Current Location");
                      }
                  } catch (error) {
                      setUserLocation(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
                  } finally {
                      setDetectingLocation(false);
                      setShowLocationModal(false);
                  }
              },
              (error) => {
                  setDetectingLocation(false);
              },
              { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }
          );
      } else {
          setDetectingLocation(false);
      }
  };

  const updatePageContent = async () => {
    setLoading(true);
    if (activeSection === 'ecodorm') {
        const mainItems = await fetchRealData('market');
        fetchSuggestedItems('market', mainItems); 
        fetchSellHomeItems();
        fetchRentHomeItems();
        fetchRoommateItems();
        fetchDonationHomeItems();
    } else if (activeSection === 'ecostore') {
        const mainItems = await fetchRealData('store');
        fetchActiveBanners();
        fetchSuggestedItems('store', mainItems);
        fetchGenderedCollections('ecostore');
    } else if (activeSection === 'ecolearn') {
        await fetchRealData('learn');
    } else if (activeSection === 'ecostyle') {
        const mainItems = await fetchRealData('style');
        fetchSuggestedItems('style', mainItems);
        fetchGenderedCollections('ecostyle');
    }
  };

  const fetchActiveBanners = async () => {
      const { data } = await supabase.from('banners').select('image_url').eq('active', true).order('created_at', { ascending: false });
      if (data && data.length > 0) setHeroBanners(data.map(b => b.image_url));
  };

  const fetchRealData = async (mode: 'market' | 'store' | 'learn' | 'style'): Promise<Item[]> => {
    try {
      const limit = mode === 'store' ? 4 : 8;
      let query = supabase.from('items').select('*, seller:users(*)').eq('is_active', true).order('created_at', { ascending: false }).limit(limit);

      if (mode === 'market') {
          query = query.neq('type', 'store').neq('type', 'learn').neq('type', 'roommate');
      } else if (mode === 'store') {
          query = query.eq('type', 'store');
      } else if (mode === 'learn') {
          query = query.eq('type', 'learn');
      } else if (mode === 'style') {
          query = query.eq('category', 'Clothing');
      }

      if (categoryParam && categoryParam !== 'All') {
          query = query.eq('category', categoryParam);
      }

      const { data } = await query;
      if (data) {
        const mapped = mapItems(data);
        setDisplayItems(mapped);
        return mapped;
      }
      return [];
    } catch (error) {
      return [];
    } finally {
      setLoading(false);
    }
  };

  const fetchSellHomeItems = async () => {
    try {
        const { data } = await supabase.from('items').select('*, seller:users(*)').eq('type', 'sell').eq('is_active', true).order('created_at', { ascending: false }).limit(4);
        if (data) setSellHomeItems(mapItems(data));
    } catch (err) {}
  };

  const fetchRentHomeItems = async () => {
    try {
        const { data } = await supabase.from('items').select('*, seller:users(*)').eq('type', 'rent').eq('is_active', true).order('created_at', { ascending: false }).limit(4);
        if (data) setRentHomeItems(mapItems(data));
    } catch (err) {}
  };

  const fetchRoommateItems = async () => {
      try {
          const { data } = await supabase.from('items').select('*, seller:users(*)').eq('type', 'roommate').eq('is_active', true).order('created_at', { ascending: false }).limit(4);
          if (data) setRoommateItems(mapItems(data));
      } catch (err) {}
  };

  const fetchDonationHomeItems = async () => {
      try {
          const { data } = await supabase.from('items').select('*, seller:users(*)').eq('type', 'donate').eq('is_active', true).order('created_at', { ascending: false }).limit(4);
          if (data) setDonationHomeItems(mapItems(data));
      } catch (err) {}
  };

  const fetchGenderedCollections = async (section: 'ecostyle' | 'ecostore') => {
      const isStyle = section === 'ecostyle';
      let menData: any[] = [];
      if (isStyle) {
          const { data } = await supabase.from('items').select('*, seller:users(*)').eq('is_active', true).eq('category', 'Clothing').ilike('title', '%Men%').limit(4);
          menData = data || [];
      } else {
          const { data } = await supabase.from('items').select('*, seller:users(*)').eq('is_active', true).eq('type', 'store').or('gender.eq.Men,gender.eq.Unisex').limit(4);
          menData = data || [];
      }
      if (menData.length > 0) setMenItems(mapItems(menData));

      let womenData: any[] = [];
      if (isStyle) {
          const { data } = await supabase.from('items').select('*, seller:users(*)').eq('is_active', true).eq('category', 'Clothing').ilike('title', '%Women%').limit(4);
          womenData = data || [];
      } else {
          const { data } = await supabase.from('items').select('*, seller:users(*)').eq('is_active', true).eq('type', 'store').or('gender.eq.Women,gender.eq.Unisex').limit(4);
          womenData = data || [];
      }
      if (womenData.length > 0) setWomenItems(mapItems(womenData));
  };

  const fetchSuggestedItems = async (mode: 'market' | 'store' | 'style', mainItems: Item[]) => {
      try {
          const userInterests = JSON.parse(localStorage.getItem('eco_user_interests') || '[]');
          let data: any[] = [];
          let query = supabase.from('items').select('*, seller:users(*)').eq('is_active', true);
          if (mode === 'store') query = query.eq('type', 'store');
          else if (mode === 'style') query = query.eq('category', 'Clothing');
          else if (mode === 'market') query = query.neq('type', 'store').neq('type', 'learn');

          if (userInterests.length > 0) {
              const { data: interestData } = await query.in('category', userInterests).limit(10);
              if (interestData) data = interestData;
          }
          if (!data || data.length < 4) {
              const { data: randomData } = await query.order('created_at', { ascending: false }).limit(20);
              if (randomData) {
                  const existingIds = new Set(data.map(d => d.id));
                  const newItems = randomData.filter((d: any) => !existingIds.has(d.id));
                  data = [...data, ...newItems];
              }
          }
          if (data && data.length > 0) {
              let mapped = mapItems(data);
              const mainIds = new Set(mainItems.map(i => i.id));
              let uniqueSuggestions = mapped.filter(i => !mainIds.has(i.id));
              if (uniqueSuggestions.length === 0 && mapped.length > 0) uniqueSuggestions = [...mapped].sort(() => 0.5 - Math.random());
              setSuggestedItems(uniqueSuggestions.slice(0, 4));
          }
      } catch (error) {}
  };

  const mapItems = (data: any[]): Item[] => {
    return data.map((d: any) => ({
        id: d.id, title: d.title, description: d.description, price: d.price, originalPrice: d.original_price,
        image: d.images?.[0] || 'https://via.placeholder.com/400', images: d.images, category: d.category,
        condition: d.condition, type: d.type, postedAt: d.created_at, isActive: d.is_active,
        flashSaleEndsAt: d.flash_sale_ends_at, externalLink: d.external_link, year: d.year, subject: d.subject,
        deliveryDuration: d.delivery_duration, isPremium: d.is_premium, rentalPeriod: d.rental_period,
        seller: { id: d.seller?.id || 'unknown', name: d.seller?.name || 'Unknown', campus: d.seller?.campus, verified: d.seller?.verified, avatar: d.seller?.avatar, sustainabilityScore: d.seller?.sustainability_score }
    }));
  };

  const handleStoreSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if(storeSearchQuery.trim()) {
        if (activeSection === 'ecostore') navigate(`/browse?type=store&search=${encodeURIComponent(storeSearchQuery)}`);
        else if (activeSection === 'ecostyle') navigate(`/browse?category=Clothing&search=${encodeURIComponent(storeSearchQuery)}`);
        else navigate(`/browse?search=${encodeURIComponent(storeSearchQuery)}`);
    }
  };

  const categoriesBySection = {
      ecodorm: [
        { name: 'Textbooks', icon: <BookOpen />, gradient: 'from-orange-400 to-red-500', border: 'border-orange-100' },
        { name: 'Stationery', icon: <Pencil />, gradient: 'from-purple-400 to-indigo-500', border: 'border-purple-100' },
        { name: 'Electronics', icon: <Monitor />, gradient: 'from-blue-400 to-cyan-500', border: 'border-blue-100' },
        { name: 'Furniture', icon: <Sofa />, gradient: 'from-emerald-400 to-teal-500', border: 'border-emerald-100' },
        { name: 'Clothing', icon: <Shirt />, gradient: 'from-pink-400 to-rose-500', border: 'border-pink-100' },
        { name: 'Kitchen', icon: <Utensils />, gradient: 'from-red-400 to-orange-500', border: 'border-red-100' },
        { name: 'Other', icon: <MoreHorizontal />, gradient: 'from-gray-400 to-slate-500', border: 'border-gray-100' },
      ],
      ecostore: [
        { name: 'Gadgets', icon: <Smartphone />, gradient: 'from-purple-600 to-indigo-600' },
        { name: 'Audio', icon: <Headphones />, gradient: 'from-purple-600 to-indigo-600' },
        { name: 'Accessories', icon: <Watch />, gradient: 'from-purple-600 to-indigo-600' },
        { name: 'Decor', icon: <Sparkles />, gradient: 'from-purple-600 to-indigo-600' },
        { name: 'Setup', icon: <Monitor />, gradient: 'from-purple-600 to-indigo-600' },
        { name: 'Merch', icon: <Shirt />, gradient: 'from-purple-600 to-indigo-600' },
        { name: 'Limited', icon: <Crown />, gradient: 'from-purple-600 to-indigo-600' },
      ],
      ecolearn: [
        { name: 'B.Tech Notes', icon: <Book />, gradient: 'from-blue-400 to-indigo-500' },
        { name: 'B.Tech PYQ', icon: <FileText />, gradient: 'from-pink-400 to-rose-500' },
        { name: 'BCA Notes', icon: <Code />, gradient: 'from-yellow-400 to-orange-500' },
        { name: 'BCA PYQ', icon: <Clock />, gradient: 'from-green-400 to-emerald-500' },
      ],
      ecostyle: [
        { name: 'Men', icon: <UserCheck />, gradient: 'from-blue-400 to-indigo-500' },
        { name: 'Women', icon: <Sparkles />, gradient: 'from-pink-400 to-rose-500' },
        { name: 'Unisex', icon: <Smile />, gradient: 'from-yellow-400 to-amber-500' },
        { name: 'Winter', icon: <Leaf />, gradient: 'from-cyan-400 to-blue-500' },
      ]
  };

  const featuresBySection = {
      ecodorm: [
        { icon: Camera, color: "text-emerald-600", bg: "bg-emerald-100", title: "Snap & Sell", desc: "List in seconds" },
        { icon: MessageCircle, color: "text-amber-600", bg: "bg-amber-100", title: "Chat Securely", desc: "Connect instantly" },
        { icon: Users, color: "text-blue-600", bg: "bg-blue-100", title: "Meet on Campus", desc: "Safe exchanges" },
        { icon: Leaf, color: "text-green-600", bg: "bg-green-100", title: "Go Green", desc: "Reduce waste" }
      ],
      ecostore: [
        { icon: ShieldCheck, color: "text-purple-600", bg: "bg-purple-100", title: "Authenticity", desc: "100% Genuine" },
        { icon: Crown, color: "text-fuchsia-600", bg: "bg-fuchsia-100", title: "Premium", desc: "Curated Selection" },
        { icon: Package, color: "text-violet-600", bg: "bg-violet-100", title: "Safe Packed", desc: "Damage Proof" },
        { icon: Star, color: "text-zinc-700", bg: "bg-zinc-200", title: "Top Rated", desc: "Student Favorites" }
      ],
      ecolearn: [
        { icon: Video, color: "text-red-600", bg: "bg-red-100", title: "HD Courses", desc: "Learn at your pace" },
        { icon: FileText, color: "text-yellow-600", bg: "bg-yellow-100", title: "Verified Notes", desc: "Exam focused" },
        { icon: Users, color: "text-blue-600", bg: "bg-blue-100", title: "Peer Support", desc: "Community doubts" },
        { icon: GraduationCap, color: "text-cyan-600", bg: "bg-cyan-100", title: "Mentorship", desc: "Career guidance" }
      ],
      ecostyle: [
        { icon: Shirt, color: "text-pink-600", bg: "bg-pink-100", title: "Fresh Trends", desc: "Campus Fashion" },
        { icon: RefreshCw, color: "text-rose-600", bg: "bg-rose-100", title: "Thrift It", desc: "Sustainable Style" },
        { icon: Scissors, color: "text-orange-600", bg: "bg-orange-100", title: "Unique Finds", desc: "One of a kind" },
        { icon: Smile, color: "text-indigo-600", bg: "bg-indigo-100", title: "Inclusive", desc: "For Everyone" }
      ]
  };

  const sectionTitles = {
      ecodorm: { title: "Recently Listed", subtitle: "Latest marketplace finds", badge: "Live" },
      ecostore: { title: "Premium Collection", subtitle: "Exclusive high-quality gear", badge: "Lux" },
      ecolearn: { title: "Top Resources", subtitle: "Trending notes & PYQs", badge: "Popular" },
      ecostyle: { title: "Campus Fashion", subtitle: "Men & Women's Clothing", badge: "Style" }
  };

  const heroConfig = {
    ecodorm: { id: 'ecodorm', bgGradient: 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-teal-700 via-emerald-800 to-green-950', highlightColor: 'from-green-200 to-teal-300', badge: { text: 'P2P MARKETPLACE', bg: 'bg-white/10', border: 'border-green-400/30', textCol: 'text-green-100' }, titlePart1: 'Sustainable', titlePart2: 'Campus Living', description: 'Buy, sell, and rent essentials within your campus community. Reduce waste and connect with peers.', ctaText: null, ctaLink: '/browse', buttonGradient: 'bg-gradient-to-r from-emerald-400 to-teal-500 shadow-lg shadow-emerald-500/25' },
    ecostore: { id: 'ecostore', bgGradient: 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-zinc-900 via-zinc-950 to-black', highlightColor: 'from-purple-400 to-fuchsia-400', badge: { text: 'EXCLUSIVE STORE', bg: 'bg-purple-500/10', border: 'border-purple-500/20', textCol: 'text-purple-300' }, titlePart1: 'Exclusive', titlePart2: '& Premium', description: 'Elevate your campus lifestyle with our curated selection of premium gadgets and limited merchandise.', ctaText: null, ctaLink: '/browse?type=store&premium=true', buttonGradient: 'bg-gradient-to-r from-purple-600 to-fuchsia-600 shadow-lg shadow-purple-900/20' },
    ecolearn: { id: 'ecolearn', bgGradient: 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-900 via-[#0e7490] to-[#083344]', highlightColor: 'from-cyan-300 to-blue-400', badge: { text: 'EDTECH HUB', bg: 'bg-cyan-500/20', border: 'border-cyan-500/30', textCol: 'text-cyan-300' }, titlePart1: 'Upskill', titlePart2: '& Grow', description: 'Access exclusive notes, video courses, and mentorship from top seniors. Level up today.', ctaText: 'Start Learning', ctaLink: '/learn', buttonGradient: 'bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/25' },
    ecostyle: { id: 'ecostyle', bgGradient: 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-rose-900 via-pink-900 to-slate-900', highlightColor: 'from-pink-200 to-rose-300', badge: { text: 'CAMPUS FASHION', bg: 'bg-white/10', border: 'border-pink-400/30', textCol: 'text-pink-100' }, titlePart1: 'Trends', titlePart2: '& Thrift', description: 'Discover pre-loved fashion and fresh trends. Buy and sell clothing within your campus sustainably.', ctaText: 'Shop Style', ctaLink: '/browse?category=Clothing', buttonGradient: 'bg-gradient-to-r from-pink-500 to-rose-600 shadow-lg shadow-pink-500/25' }
  };

  const currentConfig = heroConfig[activeSection] || heroConfig['ecodorm']; 
  const currentCategories = categoriesBySection[activeSection] || categoriesBySection['ecodorm']; 
  const currentFeatures = featuresBySection[activeSection] || featuresBySection['ecodorm']; 
  const currentTitles = sectionTitles[activeSection] || sectionTitles['ecodorm']; 
  const isEcoStore = activeSection === 'ecostore';

  const SectionHeader = ({ icon: Icon, title, subtitle, link, colorClass, badgeText }: any) => (
    <div className="flex items-center justify-between mb-4 md:mb-8 gap-3 animate-fade-in px-1">
        <div className="relative flex items-center gap-2 md:gap-3">
            <div className={`absolute -left-4 -top-4 w-12 h-12 rounded-full blur-2xl opacity-20 ${colorClass.replace('text-', 'bg-')}`}></div>
            <div className={`p-1.5 md:p-2 rounded-lg md:rounded-xl bg-white shadow-sm border border-gray-100 relative z-10 ${colorClass}`}>
                <Icon size={18} strokeWidth={2.5} className="md:w-6 md:h-6" />
            </div>
            <div className="flex flex-col relative z-10">
                <div className="flex items-center gap-1.5 md:gap-2">
                    <h2 className={`text-base md:text-3xl font-black tracking-tight leading-none ${isEcoStore ? 'text-white' : 'text-gray-900'}`}>{title}</h2>
                    {badgeText && (
                        <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[7px] md:text-[9px] font-black uppercase tracking-wider border shadow-sm ${colorClass} bg-white border-current/20`}>
                            <Sparkles size={7} className="mr-0.5 animate-pulse fill-current" /> {badgeText}
                        </span>
                    )}
                </div>
                <p className={`text-[9px] md:text-sm font-medium mt-0.5 md:mt-1 ${isEcoStore ? 'text-zinc-400' : 'text-gray-500'}`}>{subtitle}</p>
            </div>
        </div>
        {link && (
            <Link to={link} className={`inline-flex items-center gap-1 md:gap-2 text-[9px] md:text-xs font-black uppercase tracking-widest px-2 py-1.5 md:px-4 md:py-2 rounded-lg bg-gray-50 border border-gray-100 hover:bg-white hover:shadow-sm transition-all active:scale-95 flex-shrink-0 ${colorClass}`}>
                <span className="hidden md:inline">View All</span> <ArrowUpRight size={10} className="md:w-[14px] md:h-[14px]" />
            </Link>
        )}
    </div>
  );

  return (
    <div className="flex flex-col min-h-screen bg-gray-50/50 w-full max-w-[100vw]">
      {/* 1. HERO SECTION */}
      <div className={`relative w-full transition-all duration-1000 ease-in-out ${currentConfig.bgGradient} pb-6 md:pb-16 overflow-hidden`}>
        {isEcoStore && heroBanners.length > 0 && (
            <div className="absolute inset-0 z-0">
                {heroBanners.map((banner, idx) => (
                    <div 
                        key={idx}
                        className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${idx === currentBannerIndex ? 'opacity-30 md:opacity-40' : 'opacity-0'}`}
                    >
                        <img src={banner} className="w-full h-full object-cover" alt="Hero Banner" />
                        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-zinc-950/50 to-zinc-950"></div>
                    </div>
                ))}
            </div>
        )}
        
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-3xl h-64 bg-white/5 blur-3xl rounded-full pointer-events-none"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 pointer-events-none mix-blend-overlay z-0"></div>
        
        <div className="pt-2 md:pt-6 px-4 max-w-7xl mx-auto w-full relative z-10">
            <div className="grid grid-cols-3 gap-1.5 md:gap-4 mb-4 md:mb-10">
                <div onClick={() => setActiveSection('ecodorm')} className={`relative cursor-pointer group rounded-lg md:rounded-2xl h-12 md:h-24 transition-all duration-500 ease-out overflow-hidden flex flex-col justify-center items-center text-center px-1 md:px-5 border select-none ${activeSection === 'ecodorm' ? 'bg-zinc-900 border-emerald-500/50 shadow-[0_0_20px_-5px_rgba(16,185,129,0.4)] ring-1 ring-emerald-500/20 z-20' : 'bg-zinc-900/40 border-white/5 hover:bg-zinc-900/60 hover:border-white/10 backdrop-blur-sm'}`}>
                     <div className="relative z-10 flex flex-col h-full justify-center items-center">
                        <div className="flex items-center gap-1 md:gap-2 justify-center">
                            <div className={`p-0.5 md:p-1 rounded-md ${activeSection === 'ecodorm' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/5 text-zinc-500'}`}>
                                <RefreshCw size={10} className="md:w-5 md:h-5" strokeWidth={2.5} />
                            </div>
                            <h3 className={`font-bold tracking-tight leading-none transition-colors duration-300 text-[9px] md:text-lg ${activeSection === 'ecodorm' ? 'text-white' : 'text-zinc-400'}`}>
                                Eco<span className={activeSection === 'ecodorm' ? 'text-emerald-400' : 'text-zinc-500'}>Dorm</span>
                            </h3>
                        </div>
                        <p className={`text-[7px] md:text-[10px] font-bold mt-0.5 md:mt-1.5 uppercase tracking-widest ${activeSection === 'ecodorm' ? 'text-emerald-500/80' : 'text-zinc-600'}`}>Market</p>
                     </div>
                </div>
                <div onClick={() => setActiveSection('ecostore')} className={`relative cursor-pointer group rounded-lg md:rounded-2xl h-12 md:h-24 transition-all duration-500 ease-out overflow-hidden flex flex-col justify-center items-center text-center px-1 md:px-5 border select-none ${activeSection === 'ecostore' ? 'bg-zinc-900 border-purple-500/50 shadow-[0_0_20px_-5px_rgba(168,85,247,0.4)] ring-1 ring-purple-500/20 z-20' : 'bg-zinc-900/40 border-white/5 hover:bg-zinc-900/60 hover:border-white/10 backdrop-blur-sm'}`}>
                     <div className="relative z-10 flex flex-col h-full justify-center items-center">
                        <div className="flex items-center gap-1 md:gap-2 justify-center">
                            <div className={`p-0.5 md:p-1 rounded-md ${activeSection === 'ecostore' ? 'bg-purple-500/20 text-purple-400' : 'bg-white/5 text-zinc-500'}`}>
                                <ShoppingBag size={10} className="md:w-5 md:h-5" strokeWidth={2.5} />
                            </div>
                            <h3 className={`font-bold tracking-tight leading-none transition-colors duration-300 text-[9px] md:text-lg ${activeSection === 'ecostore' ? 'text-white' : 'text-zinc-400'}`}>
                                Eco<span className={activeSection === 'ecostore' ? 'text-purple-400' : 'text-zinc-500'}>Store</span>
                            </h3>
                        </div>
                        <p className={`text-[7px] md:text-[10px] font-bold mt-0.5 md:mt-1.5 uppercase tracking-widest ${activeSection === 'ecostore' ? 'text-purple-500/80' : 'text-zinc-600'}`}>Premium</p>
                     </div>
                </div>
                <div onClick={() => setActiveSection('ecolearn')} className={`relative cursor-pointer group rounded-lg md:rounded-2xl h-12 md:h-24 transition-all duration-500 ease-out overflow-hidden flex flex-col justify-center items-center text-center px-1 md:px-5 border select-none ${activeSection === 'ecolearn' ? 'bg-zinc-900 border-cyan-500/50 shadow-[0_0_20px_-5px_rgba(6,182,212,0.4)] ring-1 ring-cyan-500/20 z-20' : 'bg-zinc-900/40 border-white/5 hover:bg-zinc-900/60 hover:border-white/10 backdrop-blur-sm'}`}>
                     <div className="relative z-10 flex flex-col h-full justify-center items-center">
                        <div className="flex items-center gap-1 md:gap-2 justify-center">
                            <div className={`p-0.5 md:p-1 rounded-md ${activeSection === 'ecolearn' ? 'bg-cyan-500/20 text-cyan-400' : 'bg-white/5 text-zinc-500'}`}>
                                <GraduationCap size={10} className="md:w-5 md:h-5" strokeWidth={2.5} />
                            </div>
                            <h3 className={`font-bold tracking-tight leading-none transition-colors duration-300 text-[9px] md:text-lg ${activeSection === 'ecolearn' ? 'text-white' : 'text-zinc-400'}`}>
                                Eco<span className={activeSection === 'ecolearn' ? 'text-cyan-400' : 'text-zinc-500'}>Learn</span>
                            </h3>
                        </div>
                        <p className={`text-[7px] md:text-[10px] font-bold mt-0.5 md:mt-1.5 uppercase tracking-widest ${activeSection === 'ecolearn' ? 'text-cyan-500/80' : 'text-zinc-600'}`}>EdTech</p>
                     </div>
                </div>
            </div>
            <div className="flex flex-col items-center text-center relative z-20 pb-2 md:pb-0">
                <div className="animate-fade-in-up">
                    <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border backdrop-blur-md text-[8px] md:text-[10px] font-bold tracking-widest uppercase mb-1.5 md:mb-3 shadow-lg select-none ${currentConfig.badge.bg} ${currentConfig.badge.border} ${currentConfig.badge.textCol}`}>
                        <Star size={8} className="md:w-3 md:h-3 fill-current" />
                        {currentConfig.badge.text}
                    </div>
                </div>
                <div className="animate-fade-in-up">
                    <h1 className="text-xl md:text-5xl lg:text-6xl font-black text-white tracking-tighter leading-[1.1] mb-1 md:mb-3 drop-shadow-xl select-none">
                       <span className="opacity-95">{currentConfig.titlePart1}</span>
                       <br className="md:hidden" /> 
                       <span className={`text-transparent bg-clip-text bg-gradient-to-r from-white to-white/70 ${currentConfig.highlightColor} ml-1 md:ml-3`}>
                           {currentConfig.titlePart2}
                       </span>
                    </h1>
                </div>
                <div className="animate-fade-in-up">
                    <p className="text-[10px] md:text-lg text-white/80 font-medium mb-3 md:mb-6 max-w-lg mx-auto leading-normal drop-shadow-sm px-4">
                       {currentConfig.description}
                    </p>
                </div>
                {currentConfig.ctaText && currentConfig.ctaLink && (
                    <div className="animate-fade-in-up">
                        <button onClick={() => navigate(currentConfig.ctaLink!)} className={`group relative inline-flex items-center gap-2 md:gap-3 pl-4 md:pl-6 pr-1.5 md:pr-2 py-1 md:py-1.5 rounded-full text-white font-bold text-xs md:text-lg transition-all duration-300 hover:scale-105 active:scale-95 select-none ${currentConfig.buttonGradient}`}>
                            <span className="py-0.5 md:py-1.5">{currentConfig.ctaText}</span>
                            <div className="bg-white/20 rounded-full p-1 md:p-1.5 group-hover:bg-white/30 transition shadow-inner">
                                <ChevronRight size={12} className="md:w-[18px] md:h-[18px] text-white" />
                            </div>
                        </button>
                    </div>
                )}
            </div>
        </div>
      </div>

      {/* 2. DYNAMIC ITEM GRID WITH DIFFERENTIATED SECTION BACKGROUNDS */}
      <section className={`relative rounded-t-[25px] md:rounded-t-[40px] shadow-[0_-20px_60px_-15px_rgba(0,0,0,0.1)] -mt-5 md:-mt-8 z-30 transition-all duration-500 ${isEcoStore ? 'bg-[#09090b] border-t border-white/5 pt-4 md:pt-12' : 'bg-white border-t border-gray-100'}`}>
         
         {!isEcoStore && <div className="absolute inset-0 bg-[radial-gradient(at_top_left,_#ffffff_0%,_#f9fafb_100%)] pointer-events-none rounded-t-[25px] md:rounded-t-[40px]"></div>}

         <div className="max-w-7xl mx-auto relative z-10">
            {/* Sticky Navigation & Location Header */}
            {(activeSection === 'ecostore' || activeSection === 'ecodorm') && (
                <div className="px-4 sm:px-6 lg:px-8">
                    <div className="mb-1.5 md:mb-2 px-1 pt-4 md:pt-8">
                        <div className="flex items-center gap-1 cursor-pointer group w-fit select-none" onClick={() => setShowLocationModal(true)}>
                            <div className={`p-1 rounded-full ${isEcoStore ? 'bg-zinc-800 text-zinc-300' : 'bg-gray-100 text-gray-700'}`}>
                                <MapPin size={10} fill="currentColor" />
                            </div>
                            <div className="flex flex-col">
                                <span className={`text-[7px] font-bold uppercase tracking-wider ${isEcoStore ? 'text-zinc-500' : 'text-gray-500'}`}>Delivery to</span>
                                <div className="flex items-center gap-1 -mt-0.5">
                                    <span className={`text-[11px] font-bold truncate max-w-[120px] md:max-w-[200px] ${isEcoStore ? 'text-white group-hover:text-purple-400' : 'text-gray-900 group-hover:text-gray-600'} transition-colors`}>{userLocation}</span>
                                    <ChevronDown size={10} className={isEcoStore ? 'text-zinc-500' : 'text-gray-400'} />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className={`sticky top-14 md:top-16 z-30 backdrop-blur-xl py-2 md:py-3 mb-4 -mx-4 px-4 md:-mx-8 md:px-8 border-b shadow-sm transition-all duration-200 ${isEcoStore ? 'bg-[#09090b]/90 border-white/10' : 'bg-white/95 border-gray-100/50'}`}>
                        <div className="max-w-7xl mx-auto w-full flex flex-col gap-2 md:gap-3">
                            <div className="flex items-center gap-2 md:gap-3 w-full">
                                <form onSubmit={handleStoreSearch} className="relative group flex-1 h-9 md:h-12">
                                    <div className="absolute inset-y-0 left-0 pl-2.5 md:pl-4 flex items-center pointer-events-none z-10">
                                        <Search size={14} className={`md:w-5 md:h-5 ${isEcoStore ? 'text-zinc-500 group-focus-within:text-purple-400' : 'text-gray-400 group-focus-within:text-forest'}`} />
                                    </div>
                                    <input type="text" value={storeSearchQuery} onChange={(e) => setStoreSearchQuery(e.target.value)} placeholder={isEcoStore ? "Search Premium Shop..." : "Search Campus..." } className={`w-full h-full pl-8 md:pl-11 pr-4 rounded-lg md:rounded-2xl focus:outline-none focus:ring-2 transition-all shadow-inner relative z-0 bg-transparent text-xs md:text-base ${isEcoStore ? 'bg-zinc-800/50 border border-zinc-700/50 text-white placeholder-zinc-600' : 'bg-gray-50 border border-gray-200 text-gray-900 placeholder-gray-400'}`} />
                                </form>
                                <div className="flex items-center gap-1.5 md:gap-2 flex-shrink-0">
                                    <button onClick={() => setIsCartOpen(true)} className={`relative h-9 w-9 md:h-12 md:w-12 flex items-center justify-center rounded-lg md:rounded-2xl border transition-all shadow-lg active:scale-95 select-none ${isEcoStore ? 'bg-purple-600 border-purple-500 text-white' : 'bg-forest border-forest text-white'}`}>
                                        <ShoppingCart size={14} className="md:w-[20px] md:h-[20px]" />
                                        {cart.length > 0 && <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[8px] md:text-[10px] font-bold h-4 md:h-5 min-w-[16px] md:min-w-[20px] px-0.5 flex items-center justify-center rounded-full border-2 border-white shadow-sm">{cart.length}</span>}
                                    </button>
                                </div>
                            </div>
                            <div className="w-full overflow-x-auto scrollbar-hide -mx-4 px-4 md:mx-0 md:px-0">
                                <div className="flex gap-1.5 md:gap-2 items-center px-1 py-1 min-w-max">
                                    <button onClick={() => { const newParams = new URLSearchParams(searchParams); newParams.delete('category'); setSearchParams(newParams); }} className={`group flex items-center gap-1 px-2.5 py-1 md:px-4 md:py-2 rounded-full text-[10px] md:text-sm font-bold transition-all duration-300 whitespace-nowrap select-none border ${isEcoStore ? (!categoryParam ? 'bg-zinc-100 text-zinc-900 border-white shadow-lg' : 'bg-zinc-900/50 border-zinc-800 text-zinc-400') : (!categoryParam ? 'bg-zinc-900 border-zinc-900 text-white' : 'bg-white border-gray-100 text-gray-600')}`}>
                                        <span className={`transition-colors ${!categoryParam ? (isEcoStore ? 'text-purple-600' : 'text-forest') : (isEcoStore ? 'text-gray-400' : 'text-gray-400')}`}><LayoutGrid size={12} strokeWidth={2.5} /></span>
                                        <span>All</span>
                                    </button>
                                    {currentCategories.map((cat) => { const isActive = categoryParam === cat.name; return ( <button key={cat.name} onClick={() => { if (isActive) { const newParams = new URLSearchParams(searchParams); newParams.delete('category'); setSearchParams(newParams); } else { setSearchParams({ section: activeSection, category: cat.name }); } }} className={`group flex items-center gap-1 px-2.5 py-1 md:px-4 md:py-2 rounded-full text-[10px] md:text-sm font-bold transition-all duration-300 whitespace-nowrap select-none border ${isEcoStore ? (isActive ? 'bg-zinc-100 text-zinc-900 border-white shadow-lg' : 'bg-zinc-900/50 border-zinc-800 text-zinc-400') : (isActive ? 'bg-zinc-900 text-white border-zinc-900' : 'bg-white border-gray-100 text-gray-600')}`}> <span className={`transition-colors ${isActive ? (isEcoStore ? 'text-purple-600' : 'text-forest') : (isEcoStore ? 'text-gray-400' : 'text-gray-400')}`}> {React.cloneElement(cat.icon as React.ReactElement<any>, { size: 12, strokeWidth: 2.5 })} </span> <span>{cat.name}</span> </button> ); })}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* MAIN SECTIONS WITH HORIZONTAL SCROLL - WRAPPED IN THEMED STRIPS */}
            {activeSection === 'ecodorm' && (
                <>
                    <div className="py-6 md:py-10 px-4 sm:px-6 lg:px-8 border-b border-gray-100 bg-gradient-to-b from-amber-50/30 to-white/0">
                         <SectionHeader icon={Zap} title="Recently Listed" subtitle="Latest marketplace finds" badgeText="Live" colorClass="text-amber-600" link="/browse" />
                        {loading ? (
                            <div className="flex overflow-x-auto gap-2 -mx-4 px-4 pb-3 scrollbar-hide md:grid md:grid-cols-4 md:gap-4 md:mx-0 md:px-0">
                                {[1,2,3,4].map(i => <div key={i} className="rounded-lg h-40 md:h-64 animate-pulse bg-gray-100 border border-gray-100 min-w-[145px] md:min-w-0"></div>)}
                            </div>
                        ) : displayItems.length > 0 ? (
                            <div className="flex overflow-x-auto gap-2 -mx-4 px-4 pb-3 scrollbar-hide snap-x md:grid md:grid-cols-3 lg:grid-cols-4 md:gap-4 md:mx-0 md:px-0 md:overflow-visible">
                                {displayItems.map(item => <ItemCard key={item.id} item={item} />)}
                            </div>
                        ) : (
                            <div className="text-center py-8 bg-white/50 rounded-xl border border-dashed border-gray-200">
                                <ShoppingBag className="mx-auto h-7 w-7 text-gray-300 mb-1.5" />
                                <h3 className="text-xs font-bold text-gray-900">Market is quiet today</h3>
                            </div>
                        )}
                    </div>

                    {suggestedItems.length > 0 && (
                        <div className="py-6 md:py-10 px-4 sm:px-6 lg:px-8 border-b border-gray-100 bg-emerald-50/20">
                            <SectionHeader icon={ThumbsUp} title="Suggestion For You" subtitle="Tailored suggestions" colorClass="text-forest" />
                            <div className="flex overflow-x-auto gap-2 -mx-4 px-4 pb-3 scrollbar-hide snap-x md:grid md:grid-cols-4 md:gap-4 md:mx-0 md:px-0 md:overflow-visible">
                                {suggestedItems.map(item => <ItemCard key={item.id} item={item} />)}
                            </div>
                        </div>
                    )}

                    <div className="py-6 md:py-10 px-4 sm:px-6 lg:px-8 border-b border-gray-100">
                        <SectionHeader icon={ShoppingCart} title="Quick Buy" subtitle="Browse top essentials" colorClass="text-forest" />
                        <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3 md:gap-4">
                            {currentCategories.map((cat, i) => (
                                <Link 
                                    key={i} 
                                    to={`/browse?category=${cat.name}`}
                                    className="group flex flex-col items-center text-center p-3 md:p-6 rounded-2xl bg-white border border-gray-100 hover:border-forest/30 hover:shadow-xl transition-all duration-300 shadow-sm"
                                >
                                    <div className={`h-10 w-10 md:h-14 md:w-14 rounded-xl flex items-center justify-center mb-2 md:mb-3 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3 shadow-sm bg-gradient-to-br ${cat.gradient} text-white`}>
                                        {React.cloneElement(cat.icon as React.ReactElement<any>, { size: 24, strokeWidth: 2 })}
                                    </div>
                                    <span className="text-[10px] md:text-sm font-black text-gray-900 tracking-tight">{cat.name}</span>
                                </Link>
                            ))}
                        </div>
                    </div>

                    {roommateItems.length > 0 && (
                        <div className="py-6 md:py-10 px-4 sm:px-6 lg:px-8 border-b border-gray-100 bg-indigo-50/20">
                            <SectionHeader icon={Users} title="Roommates & Flats" subtitle="Find your room" link="/browse?type=roommate" colorClass="text-indigo-600" />
                            <div className="flex overflow-x-auto gap-2 -mx-4 px-4 pb-3 scrollbar-hide snap-x md:grid md:grid-cols-4 md:gap-4 md:mx-0 md:px-0 md:overflow-visible mb-6">
                                {roommateItems.map(item => <ItemCard key={item.id} item={item} />)}
                            </div>
                            <div className="relative group overflow-hidden bg-gradient-to-br from-indigo-600 to-blue-700 rounded-xl md:rounded-3xl py-3 md:py-4 px-5 md:px-8 shadow-lg shadow-indigo-100">
                                <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full blur-2xl -mr-8 -mt-8"></div>
                                <div className="flex flex-col md:flex-row items-center justify-between gap-3 md:gap-8 relative z-10">
                                    <div className="flex flex-col md:flex-row items-center gap-3 md:gap-6 text-center md:text-left">
                                        <div className="h-8 w-8 md:h-12 md:w-12 bg-white/20 backdrop-blur-md rounded-lg flex items-center justify-center border border-white/30">
                                            <Plus size={16} className="text-white md:w-6 md:h-6" />
                                        </div>
                                        <div>
                                            <h3 className="text-base md:text-xl font-black text-white leading-tight">Need a flatmate?</h3>
                                            <p className="text-[9px] md:text-sm text-indigo-100">Share your listing and connect with peers.</p>
                                        </div>
                                    </div>
                                    <Link to="/sell?type=roommate" className="w-full md:w-auto inline-flex items-center justify-center gap-1.5 bg-white text-indigo-700 font-black py-2 md:py-3 px-6 md:px-8 rounded-xl text-xs md:text-sm transition active:scale-95 shadow-sm">
                                        Post Ad <ChevronRight size={14} />
                                    </Link>
                                </div>
                            </div>
                        </div>
                    )}

                    {sellHomeItems.length > 0 && (
                        <div className="py-6 md:py-10 px-4 sm:px-6 lg:px-8 border-b border-gray-100 bg-emerald-50/10">
                            <SectionHeader icon={ShoppingBag} title="Buy & Sell" subtitle="Essentials from your peers" link="/browse?type=sell" colorClass="text-emerald-600" badgeText="Hot" />
                            <div className="flex overflow-x-auto gap-2 -mx-4 px-4 pb-3 scrollbar-hide snap-x md:grid md:grid-cols-4 md:gap-4 md:mx-0 md:px-0 md:overflow-visible mb-6">
                                {sellHomeItems.map(item => <ItemCard key={item.id} item={item} />)}
                            </div>
                            <div className="relative group overflow-hidden bg-gradient-to-br from-emerald-600 via-forest to-green-800 rounded-xl md:rounded-2xl py-3 md:py-4 px-5 md:px-8 shadow-2xl shadow-forest/20">
                                <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full blur-3xl -mr-16 -mt-16 group-hover:scale-125 transition-transform duration-1000"></div>
                                <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full blur-2xl -ml-8 -mb-8"></div>
                                <div className="flex flex-col md:flex-row items-center justify-between gap-3 md:gap-6 relative z-10">
                                    <div className="max-w-xl text-center md:text-left">
                                        <h2 className="text-lg md:text-2xl font-black text-white leading-[1.1] tracking-tight mb-1">
                                            Turn Clutter <br className="hidden sm:block"/><span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-200 to-white">into Cash</span>
                                        </h2>
                                        <p className="text-emerald-50/80 text-[9px] md:text-xs font-medium leading-tight mb-0 max-w-md">
                                            Snap a photo, set your price, and sell to peers instantly. Keep your campus sustainable.
                                        </p>
                                    </div>
                                    <div className="flex flex-col items-center w-full md:w-auto">
                                        <div className="relative w-full">
                                            <div className="absolute inset-0 bg-white/20 blur-xl rounded-xl group-hover:bg-white/30 transition-all duration-500"></div>
                                            <Link to="/sell" className="relative flex items-center justify-center gap-1.5 bg-white text-forest font-black py-2 md:py-2.5 px-6 md:px-8 rounded-xl text-xs md:text-sm transition-all duration-300 hover:scale-105 active:scale-95 shadow-xl group/btn overflow-hidden">
                                                <div className="absolute inset-0 bg-emerald-50 transform translate-y-full group-hover/btn:translate-y-0 transition-transform duration-300"></div>
                                                <Plus size={14} className="relative z-10" />
                                                <span className="relative z-10 whitespace-nowrap">List Now</span>
                                                <ArrowRight size={14} className="relative z-10 group-hover/btn:translate-x-1 transition-transform" />
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {rentHomeItems.length > 0 && (
                        <div className="py-6 md:py-10 px-4 sm:px-6 lg:px-8 border-b border-gray-100 bg-blue-50/20">
                            <SectionHeader icon={Clock} title="Student Rentals" subtitle="Pay less, use more" link="/browse?type=rent" colorClass="text-blue-600" />
                            <div className="flex overflow-x-auto gap-2 -mx-4 px-4 pb-3 scrollbar-hide snap-x md:grid md:grid-cols-4 md:gap-4 md:mx-0 md:px-0 md:overflow-visible mb-6">
                                {rentHomeItems.map(item => <ItemCard key={item.id} item={item} />)}
                            </div>
                            <div className="relative group overflow-hidden bg-gradient-to-br from-blue-600 via-sky-700 to-indigo-800 rounded-xl md:rounded-2xl py-3 md:py-4 px-5 md:px-8 shadow-2xl shadow-blue-900/20">
                                <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full blur-3xl -mr-16 -mt-16 group-hover:scale-125 transition-transform duration-1000"></div>
                                <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full blur-2xl -ml-8 -mb-8"></div>
                                <div className="flex flex-col md:flex-row items-center justify-between gap-3 md:gap-6 relative z-10">
                                    <div className="max-w-xl text-center md:text-left">
                                        <h2 className="text-lg md:text-2xl font-black text-white leading-[1.1] tracking-tight mb-1">
                                            Lend & <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-200 to-white">Earn Daily</span>
                                        </h2>
                                        <p className="text-blue-50/80 text-[9px] md:text-xs font-medium leading-tight mb-0 max-w-md">
                                            Don't let your gear sit idle. Rent out your cycle, camera, or books safely and earn.
                                        </p>
                                    </div>
                                    <div className="flex flex-col items-center w-full md:w-auto">
                                        <div className="relative w-full">
                                            <div className="absolute inset-0 bg-white/20 blur-xl rounded-xl group-hover:bg-white/30 transition-all duration-500"></div>
                                            <Link to="/sell?type=rent" className="relative flex items-center justify-center gap-1.5 bg-white text-blue-700 font-black py-2 md:py-2.5 px-6 md:px-8 rounded-xl text-xs md:text-sm transition-all duration-300 hover:scale-105 active:scale-95 shadow-xl group/btn overflow-hidden">
                                                <div className="absolute inset-0 bg-blue-50 transform translate-y-full group-hover/btn:translate-y-0 transition-transform duration-300"></div>
                                                <Plus size={14} className="relative z-10" />
                                                <span className="relative z-10 whitespace-nowrap">List for Rent</span>
                                                <ArrowRight size={14} className="relative z-10 group-hover/btn:translate-x-1 transition-transform" />
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {donationHomeItems.length > 0 && (
                        <div className="py-6 md:py-10 px-4 sm:px-6 lg:px-8 bg-purple-50/20 rounded-b-[25px] md:rounded-b-[40px]">
                            <SectionHeader icon={Heart} title="Kindness Corner" subtitle="Free student gifts" link="/donate" colorClass="text-purple-600" />
                            <div className="flex overflow-x-auto gap-2 -mx-4 px-4 pb-3 scrollbar-hide snap-x md:grid md:grid-cols-4 md:gap-4 md:mx-0 md:px-0 md:overflow-visible mb-6">
                                {donationHomeItems.map(item => <ItemCard key={item.id} item={item} />)}
                            </div>
                            <div className="relative group overflow-hidden bg-gradient-to-br from-purple-600 to-fuchsia-600 rounded-xl md:rounded-3xl py-3 md:py-4 px-5 md:px-8 shadow-lg shadow-purple-100">
                                <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full blur-2xl -ml-8 -mb-8"></div>
                                <div className="flex flex-col md:flex-row items-center justify-between gap-3 md:gap-8 relative z-10">
                                    <div className="flex flex-col md:flex-row items-center gap-3 md:gap-6 text-center md:text-left">
                                        <div className="h-8 w-8 md:h-12 md:w-12 bg-white/20 backdrop-blur-md rounded-lg flex items-center justify-center border border-white/30">
                                            <Gift size={16} className="text-white md:w-6 md:h-6" />
                                        </div>
                                        <div>
                                            <h3 className="text-base md:text-xl font-black text-white leading-tight">Spread Kindness</h3>
                                            <p className="text-[9px] md:text-sm text-purple-100">Help your campus go green by gifting items.</p>
                                        </div>
                                    </div>
                                    <Link to="/sell?type=donate" className="w-full md:w-auto inline-flex items-center justify-center gap-1.5 bg-white text-purple-700 font-black py-2 md:py-3 px-6 md:px-8 rounded-xl text-xs md:text-sm transition active:scale-95 shadow-sm">
                                        Donate Item <ChevronRight size={14} />
                                    </Link>
                                </div>
                            </div>
                        </div>
                    )}
                </>
            )}

            {/* ECOSTORE / OTHER CONTENT CAROUSELS */}
            {(activeSection !== 'ecodorm') && (
                <div className="px-4 sm:px-6 lg:px-8 mt-3 md:mt-8 pb-12">
                     <SectionHeader 
                        icon={activeSection === 'ecostore' ? ShoppingBag : activeSection === 'ecolearn' ? GraduationCap : Shirt} 
                        title={currentTitles.title} 
                        subtitle={currentTitles.subtitle} 
                        badgeText={currentTitles.badge}
                        colorClass={activeSection === 'ecostore' ? 'text-purple-400' : activeSection === 'ecolearn' ? 'text-cyan-600' : 'text-pink-600'}
                    />
                    <div className="flex overflow-x-auto gap-2 -mx-4 px-4 pb-3 scrollbar-hide snap-x md:grid md:grid-cols-3 lg:grid-cols-4 md:gap-4 md:mx-0 md:px-0 md:overflow-visible mb-12">
                        {displayItems.map(item => <ItemCard key={item.id} item={item} />)}
                    </div>
                </div>
            )}
         </div>
      </section>

      {/* COLLECTIONS WITH STYLIZED BANNERS & INTEGRATED NAVIGATION */}
      {(activeSection === 'ecostyle' || activeSection === 'ecostore') && (
          <>
            {menItems.length > 0 && (
                <section className="relative py-10 md:py-20 bg-[#0B1120] overflow-hidden border-t border-slate-900">
                    <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] pointer-events-none mix-blend-overlay"></div>
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                        <div className="flex flex-col md:flex-row justify-between items-end mb-4 md:mb-8 border-b border-slate-800 pb-2 md:pb-4 gap-2">
                            <h2 className="text-2xl md:text-6xl font-sans font-black text-white tracking-tighter leading-none"> For <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">Him</span> </h2>
                            <Link to={activeSection === 'ecostore' ? "/browse?type=store&gender=Men" : "/browse?category=Clothing&gender=Men"} className="group flex items-center gap-1 text-[9px] md:text-xs font-bold text-slate-300 uppercase tracking-widest hover:text-white transition-colors"> View Collection <ArrowRight size={10} className="group-hover:translate-x-1 transition-transform md:w-4 md:h-4"/></Link>
                        </div>
                        {/* THE MALE BANNER */}
                        <div className="relative w-full mb-4 md:mb-12 rounded-lg md:rounded-3xl overflow-hidden shadow-2xl group min-h-[180px] md:min-h-[420px] border border-white/10">
                            <div className="absolute inset-0 bg-gradient-to-br from-[#0B1120] to-[#1e293b]"></div>
                            <div className="absolute right-0 top-0 bottom-0 w-[90%] md:w-3/5 overflow-hidden"> 
                                <img 
                                    src="https://images.unsplash.com/photo-1536766820879-059fec98ec0a?q=80&w=1000&auto=format&fit=crop" 
                                    className="w-full h-full object-cover object-[center_15%] md:object-top transition-transform duration-1000 group-hover:scale-105" 
                                    style={{ maskImage: 'linear-gradient(to right, transparent 0%, black 40%)', WebkitMaskImage: 'linear-gradient(to right, transparent 0%, black 40%)' }}
                                /> 
                            </div>
                            <div className="relative p-3 md:p-16 flex flex-col justify-center h-full z-20">
                                <div className="max-w-lg animate-fade-in-up mb-3 md:mb-8 text-left">
                                    <div className="flex items-center gap-1 md:gap-3 mb-0.5 md:mb-4"> <span className="h-[1px] w-4 md:w-8 bg-slate-400"></span> <span className="text-slate-300 text-[7px] md:text-xs font-bold uppercase tracking-[0.2em] md:tracking-[0.3em]"> Runway '25 </span> </div>
                                    <h3 className="text-lg md:text-7xl font-serif font-bold text-white mb-0.5 md:mb-4 leading-none tracking-tight drop-shadow-lg"> The <br/> <span className="text-slate-200 font-sans font-light">Vogue Edit</span> </h3>
                                </div>
                                
                                {/* INTEGRATED SUB-NAV FOR HIM */}
                                <div className="flex items-center gap-3 overflow-x-auto scrollbar-hide pb-1">
                                    {[
                                        { icon: Smartphone, label: 'Gadgets' },
                                        { icon: Headphones, label: 'Audio' },
                                        { icon: Watch, label: 'Watches' },
                                        { icon: SneakerIcon, label: 'Shoes' }
                                    ].map((cat, i) => (
                                        <Link key={i} to={`/browse?type=store&category=${cat.label}&gender=Men`} className="flex flex-col items-center gap-1 group/item flex-shrink-0">
                                            <div className="h-10 w-10 md:h-14 md:w-14 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white group-hover/item:bg-blue-600 group-hover/item:border-blue-400 transition-all shadow-lg">
                                                <cat.icon className="w-5 h-5 md:w-6 md:h-6" />
                                            </div>
                                            <span className="text-[7px] md:text-[9px] font-bold text-slate-300 uppercase tracking-widest">{cat.label}</span>
                                        </Link>
                                    ))}
                                </div>
                            </div>
                        </div>
                        <div className="flex overflow-x-auto gap-2 -mx-4 px-4 pb-3 scrollbar-hide snap-x md:grid md:grid-cols-3 lg:grid-cols-4 md:gap-6 md:mx-0 md:px-0 md:overflow-visible"> {menItems.map(item => ( <ItemCard key={item.id} item={item} variant="male" /> ))} </div>
                    </div>
                </section>
            )}
            {womenItems.length > 0 && (
                <section className="relative py-10 md:py-20 bg-rose-50 overflow-hidden border-t border-rose-100">
                    <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-rose-100 via-white to-orange-50 opacity-60 pointer-events-none"></div>
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                        <div className="flex flex-col md:flex-row justify-between items-end mb-4 md:mb-8 gap-2 border-b border-rose-200 pb-2 md:pb-4">
                            <div className="text-left"> 
                                <span className="flex items-center gap-1 text-rose-500 font-serif italic text-xs md:text-lg tracking-wide mb-0.5"> <Sparkles size={10} className="md:w-4 md:h-4" /> Curated Selection </span> 
                                <h2 className="text-2xl md:text-6xl font-bold text-gray-900 tracking-tight leading-none"> For <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-500 to-orange-400">Her</span> </h2> 
                            </div>
                            <Link to={activeSection === 'ecostore' ? "/browse?type=store&gender=Women" : "/browse?category=Clothing&gender=Women"} className="group inline-flex items-center gap-1 text-[9px] md:text-sm font-bold text-rose-800/60 hover:text-rose-900 transition-colors"> Shop The Edit <ArrowRight size={10} className="group-hover:translate-x-1 transition-transform md:w-4 md:h-4"/></Link>
                        </div>
                        {/* THE FEMALE BANNER */}
                        <div className="relative w-full mb-4 md:mb-12 rounded-lg md:rounded-3xl overflow-hidden shadow-xl group min-h-[180px] md:min-h-[320px]">
                            <div className="absolute inset-0 bg-gradient-to-r from-rose-600 via-pink-600 to-pink-500"></div>
                            <div className="absolute right-0 top-0 bottom-0 w-[90%] md:w-1/2 overflow-hidden"> 
                                <img 
                                    src="https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=800&q=80" 
                                    className="w-full h-full object-cover object-top opacity-70 md:opacity-90 transition-transform duration-1000 group-hover:scale-105" 
                                    style={{ maskImage: 'linear-gradient(to right, transparent 0%, black 50%)', WebkitMaskImage: 'linear-gradient(to right, transparent 0%, black 50%)' }}
                                /> 
                            </div>
                            <div className="relative p-3 md:p-10 flex flex-col justify-center h-full z-20 text-left">
                                <div className="max-w-lg text-white animate-fade-in-up mb-3 md:mb-6"> 
                                    <span className="bg-white/20 backdrop-blur-md border border-white/30 text-white text-[7px] md:text-xs font-bold px-1.5 py-0.5 md:px-3 md:py-1 rounded-full uppercase tracking-widest mb-1.5 inline-flex items-center gap-1"> <Sparkles size={8} className="text-yellow-300" /> Beauty Lit Fest </span> 
                                    <h3 className="text-lg md:text-5xl font-serif font-medium mb-0.5 md:mb-2 leading-tight tracking-tight drop-shadow-md"> Beauty <br/><span className="italic font-light">LIT FEST</span> </h3> 
                                </div>
                                
                                {/* INTEGRATED SUB-NAV FOR HER */}
                                <div className="flex items-center gap-3 overflow-x-auto scrollbar-hide pb-1">
                                    {[
                                        { icon: JewelryIcon, label: 'Jewelry' },
                                        { icon: DressIcon, label: 'Dresses' },
                                        { icon: LipstickIcon, label: 'Makeup' },
                                        { icon: PerfumeIcon, label: 'Fragrance' },
                                        { icon: BagIcon, label: 'Bags' }
                                    ].map((cat, i) => (
                                        <Link key={i} to={`/browse?type=store&category=${cat.label}&gender=Women`} className="flex flex-col items-center gap-1 group/item flex-shrink-0">
                                            <div className="h-10 w-10 md:h-14 md:w-14 rounded-full bg-white/20 backdrop-blur-md border border-white/20 flex items-center justify-center text-white group-hover/item:bg-rose-600 group-hover/item:border-rose-400 transition-all shadow-lg">
                                                <cat.icon className="w-5 h-5 md:w-6 md:h-6" />
                                            </div>
                                            <span className="text-[7px] md:text-[9px] font-bold text-rose-100 uppercase tracking-widest">{cat.label}</span>
                                        </Link>
                                    ))}
                                </div>
                            </div>
                        </div>
                        <div className="flex overflow-x-auto gap-2 -mx-4 px-4 pb-3 scrollbar-hide snap-x md:grid md:grid-cols-3 lg:grid-cols-4 md:gap-6 md:mx-0 md:px-0 md:overflow-visible"> {womenItems.map(item => ( <ItemCard key={item.id} item={item} variant="rose" /> ))} </div>
                    </div>
                </section>
            )}
          </>
      )}

      {/* FOOTER PUSH */}
      <div className="h-10"></div>
      
      {/* LOCATION MODAL */}
      {showLocationModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in zoom-in-95">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col max-h-[85vh]">
                  <div className="px-5 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50"> <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2"><MapPin size={20} className="text-gray-500"/> Select Location</h3> <button onClick={() => setShowLocationModal(false)} className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-200 transition"><X size={20} /></button> </div>
                  <div className="p-4 overflow-y-auto text-left">
                      <button onClick={handleDetectLocation} disabled={detectingLocation} className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-gray-200 hover:bg-gray-50 rounded-xl transition text-left mb-4 shadow-sm group"> <div className="bg-gray-100 text-gray-800 p-2 rounded-full group-hover:scale-110 transition-transform"> {detectingLocation ? <Loader2 size={20} className="animate-spin text-forest"/> : <LocateFixed size={20}/>} </div> <div> <h4 className="text-sm font-bold text-gray-900">Detect Current Location</h4> <p className="text-xs text-gray-500">Using GPS (Approx)</p> </div> </button>
                      {user && user.campus && ( <div className="mb-4 text-left"> <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 ml-1">Saved Address</p> <button onClick={() => { setUserLocation(user.campus); setShowLocationModal(false); }} className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-gray-200 hover:border-forest hover:bg-green-50 rounded-xl transition text-left"> <div className="bg-gray-100 text-gray-500 p-2 rounded-full"> <Building2 size={20}/> </div> <div> <h4 className="text-sm font-bold text-gray-900">My Campus</h4> <p className="text-xs text-gray-500">{user.campus}</p> </div> </button> </div> )}
                      <div className="text-left"> <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 ml-1">Select Manually</p> <div className="relative mb-3"> <input type="text" placeholder="Search for college..." value={locationQuery} onChange={(e) => setLocationQuery(e.target.value)} className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-forest/20 focus:border-forest transition" /> <Search size={16} className="absolute left-3.5 top-3 text-gray-400 pointer-events-none" /> </div> <div className="space-y-1 max-h-60 overflow-y-auto custom-scrollbar"> {CAMPUS_OPTIONS.filter(c => c.toLowerCase().includes(locationQuery.toLowerCase())).map((campus, idx) => ( <button key={idx} onClick={() => { setUserLocation(campus); setShowLocationModal(false); }} className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition flex items-center justify-between group ${userLocation === campus ? 'bg-green-50 text-forest border border-green-100' : 'hover:bg-gray-50 text-gray-700'}`} > <span>{campus}</span> {userLocation === campus && <Navigation size={14} className="fill-current"/>} </button> ))} </div> </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default Home;