
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const EcoStore: React.FC = () => {
  const navigate = useNavigate();
  useEffect(() => {
    navigate('/?section=ecostore', { replace: true });
  }, [navigate]);
  return null;
};

export default EcoStore;
