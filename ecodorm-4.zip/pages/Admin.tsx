
import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Item, Category, ListingType, Banner } from '../types';
import { CATEGORIES, BTECH_1ST_YEAR_SUBJECTS, PYQ_YEARS } from '../constants';
import { Edit, Trash2, Search, CheckCircle, X, Save, EyeOff, Eye, Loader2, Plus, Upload, Link as LinkIcon, Image as ImageIcon, Book, GraduationCap, FileText, Calendar, Clock, Layout, Zap, Truck, Users, Crown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Admin: React.FC = () => {
  const { user, isAdmin, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [items, setItems] = useState<Item[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Tab State
  const [activeTab, setActiveTab] = useState<'items' | 'banners'>('items');

  // Edit State
  const [editingItem, setEditingItem] = useState<Item | null>(null);
  const [editForm, setEditForm] = useState<Partial<Item>>({});
  const [saveLoading, setSaveLoading] = useState(false);
  const [editImageFile, setEditImageFile] = useState<File | null>(null);
  const [editImagePreview, setEditImagePreview] = useState<string | null>(null);
  // Edit Delivery Duration State
  const [editDeliveryType, setEditDeliveryType] = useState('Same Day Delivery');
  const [editCustomDelivery, setEditCustomDelivery] = useState('');
  
  // Add New Item State
  const [showAddModal, setShowAddModal] = useState(false);
  
  // Banner Upload State
  const [bannerFile, setBannerFile] = useState<File | null>(null);
  const [bannerUploadLoading, setBannerUploadLoading] = useState(false);
  
  // Local state for split academic inputs
  const [academicCourse, setAcademicCourse] = useState('B.Tech');
  const [resourceType, setResourceType] = useState('Notes');
  const [pyqSession, setPyqSession] = useState('');

  // Add Item Delivery Duration State
  const [addDeliveryType, setAddDeliveryType] = useState('Same Day Delivery');
  const [addCustomDelivery, setAddCustomDelivery] = useState('');

  const [addForm, setAddForm] = useState({
      title: '',
      description: '',
      price: '',
      originalPrice: '', 
      category: 'Gadgets' as Category, 
      condition: 'New',
      type: 'store' as ListingType,
      externalLink: '',
      year: '1st Year',
      subject: '',
      gender: 'Unisex' as 'Men' | 'Women' | 'Unisex' | null,
      isPremium: false // Added Premium State
  });
  const [addImageFile, setAddImageFile] = useState<File | null>(null);
  const [addImagePreview, setAddImagePreview] = useState<string | null>(null);
  
  // Delete State
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // CATEGORY LISTS
  const STORE_CATEGORIES: Category[] = ['Gadgets', 'Audio', 'Accessories', 'Decor', 'Setup', 'Merch', 'Limited'];
  const GENERAL_CATEGORIES: Category[] = ['Textbooks', 'Stationery', 'Electronics', 'Furniture', 'Clothing', 'Kitchen', 'Other'];

  useEffect(() => {
    if (authLoading) return;
    if (!isAdmin) {
      navigate('/');
      return;
    }
    fetchItems();
    fetchBanners();
  }, [isAdmin, authLoading, navigate]);

  const fetchItems = async () => {
    setLoading(true);
    const { data, error } = await supabase
        .from('items')
        .select('*, seller:users(*)')
        .order('created_at', { ascending: false });

    if (error) {
        console.error('Error fetching items:', error);
    } else if (data) {
        const mapped: Item[] = data.map((d: any) => ({
            id: d.id,
            title: d.title,
            description: d.description,
            price: d.price,
            originalPrice: d.original_price,
            image: d.images?.[0] || 'https://via.placeholder.com/400',
            images: d.images,
            category: d.category,
            condition: d.condition,
            type: d.type,
            seller: {
              id: d.seller?.id,
              name: d.seller?.name || 'Unknown',
              campus: d.seller?.campus,
              verified: d.seller?.verified,
              avatar: d.seller?.avatar,
              sustainabilityScore: d.seller?.sustainability_score
            },
            postedAt: d.created_at,
            isActive: d.is_active,
            externalLink: d.external_link,
            year: d.year,
            subject: d.subject,
            deliveryDuration: d.delivery_duration,
            gender: d.gender,
            isPremium: d.is_premium // Map Premium from DB
        }));
        setItems(mapped);
    }
    setLoading(false);
  };

  const fetchBanners = async () => {
      const { data } = await supabase.from('banners').select('*').order('created_at', { ascending: false });
      if (data) setBanners(data);
  };

  const handleUploadBanner = async () => {
      if (!bannerFile) return;
      setBannerUploadLoading(true);
      try {
          const fileExt = bannerFile.name.split('.').pop();
          const fileName = `banner_${Math.random().toString(36).substring(2)}.${fileExt}`;
          const filePath = `admin-uploads/banners/${fileName}`;

          const { error: uploadError } = await supabase.storage
              .from('item-images')
              .upload(filePath, bannerFile);

          if (uploadError) throw uploadError;

          const { data } = supabase.storage
              .from('item-images')
              .getPublicUrl(filePath);
          
          const imageUrl = data.publicUrl;

          const { error: insertError } = await supabase.from('banners').insert([{
              image_url: imageUrl,
              active: true
          }]);

          if (insertError) throw insertError;

          setBannerFile(null);
          fetchBanners();
          alert("Banner uploaded successfully!");

      } catch (err: any) {
          alert("Banner upload failed: " + err.message);
      } finally {
          setBannerUploadLoading(false);
      }
  };

  const handleToggleBannerStatus = async (banner: Banner) => {
      const newStatus = !banner.active;
      const { error } = await supabase
          .from('banners')
          .update({ active: newStatus })
          .eq('id', banner.id);

      if (!error) {
          setBanners(prev => prev.map(b => b.id === banner.id ? { ...b, active: newStatus } : b));
      } else {
          alert('Failed to update banner status');
      }
  };

  const handleDeleteBanner = async (id: string) => {
      if(!confirm("Delete this banner?")) return;
      await supabase.from('banners').delete().eq('id', id);
      fetchBanners();
  };

  const handleToggleStatus = async (e: React.MouseEvent | null, item: Item, forcedStatus?: boolean) => {
      if(e) {
        e.preventDefault();
        e.stopPropagation();
      }
      
      const newStatus = forcedStatus !== undefined ? forcedStatus : !item.isActive;
      
      const { error } = await supabase
          .from('items')
          .update({ is_active: newStatus })
          .eq('id', item.id);
      
      if (!error) {
          setItems(prev => prev.map(i => i.id === item.id ? { ...i, isActive: newStatus } : i));
          if (editingItem && editingItem.id === item.id) {
              setEditForm(prev => ({...prev, isActive: newStatus}));
          }
      } else {
          alert('Failed to update status');
      }
  };

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    e.stopPropagation();

    if (!window.confirm('Are you sure you want to permanently delete this listing?')) {
        return;
    }

    setDeletingId(id);

    try {
        const { error: standardError, data } = await supabase
            .from('items')
            .delete()
            .eq('id', id)
            .select();

        if (standardError) throw standardError;
        
        if (!data || data.length === 0) {
            throw new Error("Permission denied. You may not have access to delete this item.");
        }
        
        setItems(prevItems => prevItems.filter(item => item.id !== id));
        
        if (editingItem && editingItem.id === id) {
            setEditingItem(null);
        }
        
    } catch (error: any) {
        console.error("Delete failed:", error);
        alert(`Delete failed: ${error.message}`);
    } finally {
        setDeletingId(null);
    }
  };

  const openEditModal = (e: React.MouseEvent, item: Item) => {
      e.preventDefault();
      e.stopPropagation();
      setEditingItem(item);
      setEditForm({
          title: item.title,
          description: item.description,
          price: item.price,
          originalPrice: item.originalPrice, 
          category: item.category,
          condition: item.condition,
          type: item.type,
          isActive: item.isActive,
          externalLink: item.externalLink || '',
          year: item.year || '1st Year',
          subject: item.subject || '',
          deliveryDuration: item.deliveryDuration,
          gender: item.gender || 'Unisex',
          isPremium: item.isPremium || false // Populate Premium Status
      });
      
      const dur = item.deliveryDuration || '';
      if (dur === 'Same Day Delivery' || dur === '10 Minutes Delivery') {
          setEditDeliveryType(dur);
          setEditCustomDelivery('');
      } else if (dur) {
          setEditDeliveryType('Custom');
          setEditCustomDelivery(dur);
      } else {
          setEditDeliveryType('Same Day Delivery');
      }

      setEditImagePreview(item.image);
      setEditImageFile(null);
      
      if (item.category.includes('B.Tech')) setAcademicCourse('B.Tech');
      else if (item.category.includes('BCA')) setAcademicCourse('BCA');
      
      if (item.category.includes('Notes')) setResourceType('Notes');
      else if (item.category.includes('PYQ')) setResourceType('PYQ');
  };

  const handleEditImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          setEditImageFile(file);
          setEditImagePreview(URL.createObjectURL(file));
      }
  };

  const safeParseFloat = (val: string | number | undefined): number => {
      if (val === undefined || val === null || val === '') return 0;
      const num = Number(val);
      return isNaN(num) ? 0 : num;
  };

  const safeParseFloatNullable = (val: string | number | undefined | null): number | null => {
      if (val === undefined || val === null || val === '') return null;
      const num = Number(val);
      return isNaN(num) ? null : num;
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;
    setSaveLoading(true);

    try {
        let imageUrl = editingItem.images?.[0] || editingItem.image;

        if (!editImagePreview && !editImageFile) {
            imageUrl = 'https://via.placeholder.com/400?text=No+Image';
        }

        if (editImageFile) {
            const fileExt = editImageFile.name.split('.').pop();
            const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
            const filePath = `admin-uploads/${fileName}`;

            const { error: uploadError } = await supabase.storage
                .from('item-images')
                .upload(filePath, editImageFile);

            if (uploadError) throw uploadError;

            const { data } = supabase.storage
                .from('item-images')
                .getPublicUrl(filePath);
            
            imageUrl = data.publicUrl;
        }

        let finalCategory = editForm.category;
        
        if (editForm.type === 'learn') {
            finalCategory = `${academicCourse} ${resourceType}` as Category;
        }

        const isAcademic = ['B.Tech Notes', 'B.Tech PYQ', 'BCA Notes', 'BCA PYQ'].includes(finalCategory || '');

        let finalDeliveryDuration = null;
        if (editForm.type === 'store') {
            finalDeliveryDuration = editDeliveryType === 'Custom' ? editCustomDelivery : editDeliveryType;
        }

        const safePrice = safeParseFloat(editForm.price);
        const safeOriginalPrice = safeParseFloatNullable(editForm.originalPrice);

        const { data, error } = await supabase
            .from('items')
            .update({
                title: editForm.title,
                description: editForm.description,
                price: safePrice,
                original_price: safeOriginalPrice, 
                category: finalCategory,
                condition: editForm.condition,
                type: editForm.type,
                is_active: editForm.isActive,
                is_premium: editForm.isPremium, // Save Premium status
                external_link: editForm.externalLink,
                year: isAcademic ? editForm.year : null,
                subject: isAcademic ? editForm.subject : null,
                images: [imageUrl],
                delivery_duration: finalDeliveryDuration,
                gender: editForm.type === 'store' ? editForm.gender : null
            })
            .eq('id', editingItem.id)
            .select();
    
        if (error) throw error;

        if (!data || data.length === 0) {
            throw new Error("Update ignored by database. You may not have permission to edit this item.");
        }

        setItems(prev => prev.map(i => i.id === editingItem.id ? { 
            ...i, 
            ...editForm,
            price: safePrice,
            originalPrice: safeOriginalPrice || undefined,
            category: finalCategory as Category,
            image: imageUrl, 
            images: [imageUrl],
            deliveryDuration: finalDeliveryDuration || undefined,
            gender: editForm.type === 'store' ? editForm.gender : undefined,
            isPremium: editForm.isPremium // Update local state
        } : i));
        setEditingItem(null);
        alert('Item updated successfully!');

    } catch (error: any) {
        console.error("Save Error:", error);
        alert('Failed to update item: ' + error.message);
    } finally {
        setSaveLoading(false);
    }
  };

  // --- ADD ITEM LOGIC ---
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          setAddImageFile(file);
          setAddImagePreview(URL.createObjectURL(file));
      }
  };

  const calculatePercentage = (original: number, offer: number) => {
      if (!original || original <= offer) return 0;
      return Math.round(((original - offer) / original) * 100);
  };

  const handleAddItem = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!user) return;
      if (!addForm.title || !addForm.description) {
          alert("Please fill in title and description.");
          return;
      }

      if (addForm.type === 'learn' && resourceType === 'PYQ' && !pyqSession) {
          alert("Please select an Exam Session for PYQ.");
          return;
      }
      
      setSaveLoading(true);
      try {
          let imageUrl = 'https://via.placeholder.com/400?text=No+Image';

          if (addImageFile) {
              const fileExt = addImageFile.name.split('.').pop();
              const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
              const filePath = `admin-uploads/${fileName}`;

              const { error: uploadError } = await supabase.storage
                  .from('item-images')
                  .upload(filePath, addImageFile);

              if (uploadError) throw uploadError;

              const { data } = supabase.storage
                  .from('item-images')
                  .getPublicUrl(filePath);
              
              imageUrl = data.publicUrl;
          }

          const price = safeParseFloat(addForm.price);
          const originalPrice = safeParseFloatNullable(addForm.originalPrice);
          
          let finalCategory = addForm.category;
          let finalTitle = addForm.title;

          if (addForm.type === 'learn') {
              finalCategory = `${academicCourse} ${resourceType}` as Category;
              if (resourceType === 'PYQ' && pyqSession) {
                  if (!finalTitle.includes(pyqSession)) {
                      finalTitle = `${finalTitle} (${pyqSession})`;
                  }
              }
          }

          const isAcademic = ['B.Tech Notes', 'B.Tech PYQ', 'BCA Notes', 'BCA PYQ'].includes(finalCategory);

          let finalDeliveryDuration = null;
          if (addForm.type === 'store') {
              finalDeliveryDuration = addDeliveryType === 'Custom' ? addCustomDelivery : addDeliveryType;
          }

          const { data, error } = await supabase.from('items').insert([{
              title: finalTitle,
              description: addForm.description,
              price: price,
              original_price: originalPrice,
              category: finalCategory,
              condition: addForm.condition,
              type: addForm.type,
              seller_id: user.id,
              images: [imageUrl],
              is_active: true,
              is_premium: addForm.isPremium, // Save Premium Status
              external_link: (addForm.type === 'learn' && addForm.externalLink) ? addForm.externalLink : null,
              year: isAcademic ? addForm.year : null,
              subject: isAcademic ? addForm.subject : null,
              delivery_duration: finalDeliveryDuration,
              gender: addForm.type === 'store' ? addForm.gender : null
          }]).select();

          if (error) {
              console.error("Supabase Error Details:", error);
              throw error;
          }

          alert("Item created successfully!");
          setShowAddModal(false);
          setAddForm({
            title: '', description: '', price: '', originalPrice: '', category: 'Gadgets', condition: 'New', type: 'store', externalLink: '', year: '1st Year', subject: '', gender: 'Unisex', isPremium: false
          });
          setAddImageFile(null);
          setAddImagePreview(null);
          setPyqSession('');
          setAddDeliveryType('Same Day Delivery');
          setAddCustomDelivery('');
          
          fetchItems(); 

      } catch (err: any) {
          console.error("Add item failed:", err);
          if (err.message?.includes('delivery_duration')) {
              alert("Database Error: The 'delivery_duration' column is missing.");
          } else {
              alert("Error creating item: " + err.message);
          }
      } finally {
          setSaveLoading(false);
      }
  };

  const DeliverySelection = ({ selected, customValue, onSelect, onCustomChange }: any) => (
      <div className="md:col-span-2 bg-purple-50 p-4 rounded-xl border border-purple-100">
          <label className="block text-sm font-bold text-purple-900 mb-2 flex items-center gap-2">
              <Truck size={16} /> Delivery Duration
          </label>
          <div className="flex flex-wrap gap-2 mb-2">
              <button type="button" onClick={() => onSelect('Same Day Delivery')} className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition ${selected === 'Same Day Delivery' ? 'bg-purple-600 text-white border-purple-600' : 'bg-white text-gray-600 border-gray-200 hover:border-purple-300'}`}>Same Day</button>
              <button type="button" onClick={() => onSelect('10 Minutes Delivery')} className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition flex items-center gap-1 ${selected === '10 Minutes Delivery' ? 'bg-yellow-400 text-black border-yellow-500' : 'bg-white text-gray-600 border-gray-200 hover:border-yellow-300'}`}><Zap size={12}/> 10 Mins</button>
              <button type="button" onClick={() => onSelect('Custom')} className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition ${selected === 'Custom' ? 'bg-purple-600 text-white border-purple-600' : 'bg-white text-gray-600 border-gray-200 hover:border-purple-300'}`}>Custom</button>
          </div>
          {selected === 'Custom' && (
              <div className="flex items-center gap-2">
                  <input type="number" min="1" value={customValue} onChange={(e: any) => onCustomChange(e.target.value)} placeholder="e.g. 3" className="w-full border border-purple-200 rounded-lg px-3 py-2 text-sm focus:ring-purple-500 outline-none" />
                  <span className="text-sm font-medium text-gray-500 whitespace-nowrap">Days later</span>
              </div>
          )}
      </div>
  );

  const GenderSelection = ({ selected, onSelect }: { selected: any, onSelect: (val: any) => void }) => (
      <div className="md:col-span-2 bg-indigo-50 p-4 rounded-xl border border-indigo-100">
          <label className="block text-sm font-bold text-indigo-900 mb-2 flex items-center gap-2">
              <Users size={16} /> Target Audience
          </label>
          <div className="flex gap-2">
              <button type="button" onClick={() => onSelect('Men')} className={`flex-1 py-2 rounded-lg text-sm font-medium border transition ${selected === 'Men' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-600 border-gray-200 hover:border-indigo-300'}`}>Male</button>
              <button type="button" onClick={() => onSelect('Women')} className={`flex-1 py-2 rounded-lg text-sm font-medium border transition ${selected === 'Women' ? 'bg-pink-600 text-white border-pink-600' : 'bg-white text-gray-600 border-gray-200 hover:border-pink-300'}`}>Female</button>
              <button type="button" onClick={() => onSelect('Unisex')} className={`flex-1 py-2 rounded-lg text-sm font-medium border transition ${selected === 'Unisex' ? 'bg-yellow-500 text-white border-yellow-500' : 'bg-white text-gray-600 border-gray-200 hover:border-yellow-300'}`}>Both</button>
          </div>
      </div>
  );

  const PremiumToggle = ({ isActive, onChange }: { isActive: boolean, onChange: () => void }) => (
      <div className="md:col-span-2 bg-gradient-to-r from-gray-900 to-gray-800 p-4 rounded-xl border border-gray-700 flex items-center justify-between shadow-md">
          <div>
              <label className="block text-sm font-bold text-white mb-1 flex items-center gap-2">
                  <Crown size={16} className="text-yellow-400" /> Premium Badge
              </label>
              <p className="text-xs text-gray-400">Show this item in the specific "Premium Collection"</p>
          </div>
          <button 
            type="button" 
            onClick={onChange} 
            className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${isActive ? 'bg-purple-600' : 'bg-gray-600'}`}
          >
              <span className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${isActive ? 'translate-x-5' : 'translate-x-0'}`} />
          </button>
      </div>
  );

  const filteredItems = items.filter(item => 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      item.seller.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  if (authLoading) return <div className="p-20 text-center"><Loader2 className="animate-spin mx-auto text-forest"/></div>;
  if (!isAdmin) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* ... (Header Remains Same) ... */}
      
      {/* Content Rendering */}
      {loading ? (
        <div className="text-center py-20 text-gray-500">Loading dashboard...</div>
      ) : activeTab === 'banners' ? (
          /* BANNER UI - REMAIN SAME */
          <div className="space-y-6">
              {/* ... Banner content ... */}
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                  <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2"><Layout size={20}/> Upload Banner</h2>
                  <div className="flex gap-4 items-center">
                      <input type="file" accept="image/*" onChange={(e) => setBannerFile(e.target.files?.[0] || null)} className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-green-50 file:text-green-700 hover:file:bg-green-100" />
                      <button onClick={handleUploadBanner} disabled={!bannerFile || bannerUploadLoading} className="bg-forest text-white px-6 py-2 rounded-lg font-bold disabled:opacity-50">
                          {bannerUploadLoading ? <Loader2 className="animate-spin"/> : 'Upload'}
                      </button>
                  </div>
              </div>
              {/* ... Banners list code ... */}
          </div>
      ) : (
        /* ITEMS TABLE */
        <div className="bg-white shadow-sm border border-gray-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Details</th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                {filteredItems.map((item) => (
                    <tr key={item.id} className="hover:bg-gray-50 transition relative">
                    <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                            <img className="h-10 w-10 rounded-md object-cover border border-gray-200" src={item.image} alt="" />
                            <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900 truncate max-w-[200px]">{item.title}</div>
                                <div className="flex gap-1 mt-0.5">
                                    {item.isPremium && (
                                        <span className="text-[9px] bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded font-bold uppercase flex items-center gap-0.5">
                                            <Crown size={8} /> Premium
                                        </span>
                                    )}
                                    {item.type === 'store' && item.gender && (
                                        <span className="text-[9px] bg-indigo-50 text-indigo-600 px-1.5 py-0.5 rounded font-bold uppercase">{item.gender}</span>
                                    )}
                                </div>
                            </div>
                        </div>
                    </td>
                    {/* ... Rest of Table Rows ... */}
                    <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-bold rounded-full uppercase
                            ${item.type === 'store' ? 'bg-indigo-100 text-indigo-800' : 
                              item.type === 'learn' ? 'bg-cyan-100 text-cyan-800' : 
                              item.type === 'sell' ? 'bg-green-100 text-green-800' : 
                              'bg-gray-100 text-gray-800'}`}>
                            {item.type}
                        </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {item.type === 'donate' ? 'Free' : `₹${item.price}`}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center relative">
                        <button onClick={(e) => handleToggleStatus(e, item)} className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium transition relative z-10 ${item.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                            {item.isActive ? 'Active' : 'Hidden'}
                        </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center justify-end gap-3 relative z-10">
                            <button onClick={(e) => openEditModal(e, item)} className="text-indigo-600 hover:bg-indigo-50 p-1 rounded"><Edit size={18} /></button>
                            <button onClick={(e) => handleDelete(e, item.id)} className="text-red-600 hover:bg-red-50 p-1 rounded"><Trash2 size={18} /></button>
                        </div>
                    </td>
                    </tr>
                ))}
                </tbody>
            </table>
          </div>
        </div>
      )}

      {/* --- ADD ITEM MODAL --- */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95">
                <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 sticky top-0 z-10">
                    <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2"><Plus size={24} className="text-forest"/> Add New Listing</h2>
                    <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-red-500 p-1 rounded-full hover:bg-gray-200 transition"><X size={24} /></button>
                </div>
                
                <form onSubmit={handleAddItem} className="p-6 space-y-5">
                    {/* ... (Type selection remains same) ... */}
                    <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Listing Type</label>
                        <div className="flex gap-3">
                            <button type="button" onClick={() => setAddForm({...addForm, type: 'store', category: 'Gadgets'})} className={`flex-1 py-2 rounded-lg border font-medium text-sm transition ${addForm.type === 'store' ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'border-gray-200 hover:bg-gray-50 text-gray-600'}`}>EcoStore Product</button>
                            <button type="button" onClick={() => setAddForm({...addForm, type: 'learn', category: 'B.Tech Notes'})} className={`flex-1 py-2 rounded-lg border font-medium text-sm transition ${addForm.type === 'learn' ? 'bg-cyan-50 border-cyan-500 text-cyan-700' : 'border-gray-200 hover:bg-gray-50 text-gray-600'}`}>EcoLearn Resource</button>
                            <button type="button" onClick={() => setAddForm({...addForm, type: 'sell', category: 'Other'})} className={`flex-1 py-2 rounded-lg border font-medium text-sm transition ${addForm.type === 'sell' ? 'bg-green-50 border-green-500 text-green-700' : 'border-gray-200 hover:bg-gray-50 text-gray-600'}`}>Regular Sell</button>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div className="md:col-span-2">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Title / Name</label>
                            <input type="text" required value={addForm.title} onChange={e => setAddForm({...addForm, title: e.target.value})} className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-forest focus:border-forest outline-none bg-white text-gray-900" placeholder="e.g. Spiral Notebook" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Offer Price ₹</label>
                            <input type="number" required value={addForm.price} onChange={e => setAddForm({...addForm, price: e.target.value})} className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-forest focus:border-forest outline-none bg-white text-gray-900" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Original Price ₹</label>
                            <input type="number" value={addForm.originalPrice} onChange={e => setAddForm({...addForm, originalPrice: e.target.value})} className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-forest focus:border-forest outline-none bg-white text-gray-900" />
                        </div>
                        
                        {/* --- STORE SPECIFIC: DELIVERY, GENDER & PREMIUM --- */}
                        {addForm.type === 'store' && (
                            <>
                                <DeliverySelection selected={addDeliveryType} customValue={addCustomDelivery} onSelect={setAddDeliveryType} onCustomChange={setAddCustomDelivery} />
                                <GenderSelection selected={addForm.gender} onSelect={(val) => setAddForm({...addForm, gender: val})} />
                                <PremiumToggle isActive={addForm.isPremium} onChange={() => setAddForm({...addForm, isPremium: !addForm.isPremium})} />
                            </>
                        )}

                        {/* ... (Existing Category Logic for Learn/Sell) ... */}
                        {addForm.type === 'learn' ? (
                            <>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Course</label>
                                    <select value={academicCourse} onChange={e => setAcademicCourse(e.target.value)} className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-900"><option>B.Tech</option><option>BCA</option></select>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Resource Type</label>
                                    <select value={resourceType} onChange={e => setResourceType(e.target.value)} className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-900"><option>Notes</option><option>PYQ</option></select>
                                </div>
                                <div className="md:col-span-2">
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Year</label>
                                    <select value={addForm.year} onChange={e => setAddForm({...addForm, year: e.target.value})} className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-900"><option>1st Year</option><option>2nd Year</option><option>3rd Year</option><option>4th Year</option></select>
                                </div>
                                {academicCourse === 'B.Tech' && addForm.year === '1st Year' && (
                                    <div className="md:col-span-2">
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                                        <select value={addForm.subject} onChange={e => setAddForm({...addForm, subject: e.target.value})} className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-900">
                                            <option value="">Select Subject</option>
                                            {BTECH_1ST_YEAR_SUBJECTS.map(sub => <option key={sub} value={sub}>{sub}</option>)}
                                        </select>
                                    </div>
                                )}
                                {resourceType === 'PYQ' && (
                                    <div className="md:col-span-2">
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Session Year</label>
                                        <select value={pyqSession} onChange={e => setPyqSession(e.target.value)} className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-900">
                                            <option value="">Select Session</option>
                                            {PYQ_YEARS.map(yr => <option key={yr} value={yr}>{yr}</option>)}
                                        </select>
                                    </div>
                                )}
                                <div className="md:col-span-2">
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Drive/PDF Link</label>
                                    <div className="flex gap-2">
                                        <input type="url" value={addForm.externalLink} onChange={e => setAddForm({...addForm, externalLink: e.target.value})} className="flex-1 border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-900" placeholder="https://drive.google.com/..." />
                                        <a href={addForm.externalLink} target="_blank" rel="noopener noreferrer" className={`p-2 rounded-lg border ${addForm.externalLink ? 'text-blue-600 border-blue-200 bg-blue-50' : 'text-gray-300 border-gray-200'}`}><LinkIcon size={20}/></a>
                                    </div>
                                </div>
                            </>
                        ) : (
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                                <select value={addForm.category} onChange={e => setAddForm({...addForm, category: e.target.value as Category})} className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-900">
                                    {addForm.type === 'store' ? STORE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>) : GENERAL_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                                </select>
                            </div>
                        )}
                    </div>

                    {/* ... (Image & Description & Submit remains same) ... */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Display Image</label>
                        <div className="flex items-center gap-4">
                            <div className="h-24 w-24 bg-gray-100 rounded-lg border border-dashed border-gray-300 flex items-center justify-center overflow-hidden relative">
                                {addImagePreview ? <img src={addImagePreview} className="h-full w-full object-cover" /> : <ImageIcon className="text-gray-400" />}
                            </div>
                            <label className="cursor-pointer bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition text-sm font-medium shadow-sm">
                                <input type="file" className="hidden" accept="image/*" onChange={handleImageSelect} />
                                <Upload size={16} className="inline mr-2" /> Choose Image
                            </label>
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                        <textarea required rows={3} value={addForm.description} onChange={e => setAddForm({...addForm, description: e.target.value})} className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none bg-white text-gray-900" />
                    </div>

                    <div className="pt-2 flex justify-end gap-3">
                        <button type="button" onClick={() => setShowAddModal(false)} className="px-5 py-2.5 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200">Cancel</button>
                        <button type="submit" disabled={saveLoading} className="px-6 py-2.5 bg-forest text-white rounded-lg font-bold hover:bg-green-700 shadow-lg shadow-green-900/10 flex items-center">
                            {saveLoading ? <Loader2 className="animate-spin" /> : 'Create Listing'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
      )}

      {/* Edit Modal */}
      {editingItem && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center sticky top-0 bg-white z-10">
                    <h2 className="text-xl font-bold text-gray-900">Edit Listing</h2>
                    <button onClick={() => setEditingItem(null)} className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100">
                        <X size={24} />
                    </button>
                </div>
                
                <form onSubmit={handleSaveEdit} className="p-6 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Status Toggle */}
                        <div className="col-span-2 bg-gray-50 p-3 rounded-lg border border-gray-200 flex items-center justify-between">
                            <span className="text-sm font-bold text-gray-900">Status: {editForm.isActive ? 'Active' : 'Hidden'}</span>
                            <button type="button" onClick={() => setEditForm({ ...editForm, isActive: !editForm.isActive })} className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${editForm.isActive ? 'bg-green-600' : 'bg-gray-300'}`}>
                                <span className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${editForm.isActive ? 'translate-x-5' : 'translate-x-0'}`} />
                            </button>
                        </div>

                        {/* Title & Price */}
                        <div className="col-span-1 md:col-span-2">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                            <input type="text" required value={editForm.title} onChange={(e) => setEditForm({...editForm, title: e.target.value})} className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-900" />
                        </div>
                        <div className="col-span-1">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Offer Price</label>
                            <input type="number" required value={editForm.price} onChange={(e) => setEditForm({...editForm, price: parseFloat(e.target.value)})} className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-900" />
                        </div>
                        <div className="col-span-1">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Original Price</label>
                            <input type="number" value={editForm.originalPrice !== undefined ? editForm.originalPrice : ''} onChange={(e) => setEditForm({...editForm, originalPrice: e.target.value ? parseFloat(e.target.value) : undefined})} className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-900" />
                        </div>

                        {/* Store Specifics in Edit */}
                        {editForm.type === 'store' && (
                            <>
                                <DeliverySelection selected={editDeliveryType} customValue={editCustomDelivery} onSelect={setEditDeliveryType} onCustomChange={setEditCustomDelivery} />
                                <GenderSelection selected={editForm.gender} onSelect={(val) => setEditForm({...editForm, gender: val})} />
                                <PremiumToggle isActive={!!editForm.isPremium} onChange={() => setEditForm({...editForm, isPremium: !editForm.isPremium})} />
                            </>
                        )}

                        <div className="col-span-2">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                            <textarea rows={4} required value={editForm.description} onChange={(e) => setEditForm({...editForm, description: e.target.value})} className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-900" />
                        </div>
                    </div>
                    
                    <div className="pt-4 flex justify-between border-t border-gray-100 items-center">
                        <button type="button" onClick={(e) => handleDelete(e, editingItem.id)} className="px-4 py-2 bg-red-50 text-red-600 rounded-lg font-medium hover:bg-red-100 flex items-center transition">
                            <Trash2 size={18} className="mr-2"/> Delete Item
                        </button>
                        <div className="flex gap-3">
                            <button type="button" onClick={() => setEditingItem(null)} className="px-5 py-2.5 bg-white border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">Cancel</button>
                            <button type="submit" disabled={saveLoading} className="px-5 py-2.5 bg-forest text-white rounded-lg font-medium hover:bg-green-700 flex items-center transition shadow-lg shadow-green-900/10">
                                {saveLoading ? <Loader2 className="animate-spin mr-2" /> : <Save size={18} className="mr-2"/>} Save Changes
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
      )}
    </div>
  );
};

export default Admin;
