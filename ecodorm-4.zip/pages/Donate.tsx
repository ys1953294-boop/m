
import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import ItemCard from '../components/ItemCard';
import { Heart, Gift, Smile, Users, Box, ArrowLeft } from 'lucide-react';
import { Item } from '../types';
import { Link } from 'react-router-dom';

const Donate: React.FC = () => {
  const [donationItems, setDonationItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDonations();
  }, []);

  const fetchDonations = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('items')
        .select('*, seller:users(*)')
        .eq('type', 'donate')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (data) {
        const mapped: Item[] = data.map((d: any) => ({
            id: d.id,
            title: d.title,
            description: d.description,
            price: 0,
            image: d.images?.[0] || 'https://via.placeholder.com/400',
            images: d.images,
            category: d.category,
            condition: d.condition,
            type: d.type,
            seller: {
              id: d.seller?.id,
              name: d.seller?.name || 'Unknown',
              campus: d.seller?.campus,
              verified: d.seller?.verified,
              avatar: d.seller?.avatar,
              sustainabilityScore: d.seller?.sustainability_score
            },
            postedAt: d.created_at,
            isActive: d.is_active
        }));
        setDonationItems(mapped);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <div className="bg-purple-600 text-white py-12 relative overflow-hidden">
        <div className="absolute top-4 left-4 z-20">
             <Link to="/" className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition flex items-center justify-center backdrop-blur-sm">
                 <ArrowLeft size={20} />
             </Link>
        </div>
        <div className="absolute top-0 right-0 -mr-20 -mt-20 opacity-10">
            <Heart size={400} />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <h1 className="text-4xl font-extrabold mb-4">The Donation Corner</h1>
            <p className="text-xl text-purple-100 max-w-2xl mx-auto mb-8">
                One student's trash is another student's treasure. Give back to your campus community.
            </p>
            <button className="bg-white text-purple-600 font-bold py-3 px-8 rounded-full shadow-lg hover:bg-gray-50 transition transform hover:-translate-y-1">
                Post a Free Item
            </button>
        </div>
      </div>

      {/* Impact Stories / Wall */}
      <div className="bg-purple-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
                 <h2 className="text-xl font-bold text-gray-900">Community Kindness Wall</h2>
                 <span className="text-sm text-purple-700 font-medium">Over 500 items gifted this semester!</span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-purple-100 relative">
                    <div className="absolute top-0 left-0 w-1 h-full bg-purple-400 rounded-l-xl"></div>
                    <div className="flex items-start">
                        <div className="flex-shrink-0">
                            <Gift className="text-purple-500" size={24} />
                        </div>
                        <div className="ml-4">
                            <p className="text-sm text-gray-600 italic">"Thanks to the senior who gave away their chem lab coat. Saved me $40!"</p>
                            <p className="text-xs text-gray-500 font-bold mt-2">- Sophomore, Bio Major</p>
                        </div>
                    </div>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-purple-100 relative">
                     <div className="absolute top-0 left-0 w-1 h-full bg-purple-400 rounded-l-xl"></div>
                     <div className="flex items-start">
                        <div className="flex-shrink-0">
                            <Smile className="text-purple-500" size={24} />
                        </div>
                        <div className="ml-4">
                            <p className="text-sm text-gray-600 italic">"I'm glad my old desk lamp found a new home instead of the dumpster."</p>
                            <p className="text-xs text-gray-500 font-bold mt-2">- Alex, Graduating Senior</p>
                        </div>
                    </div>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-purple-100 relative">
                    <div className="absolute top-0 left-0 w-1 h-full bg-purple-400 rounded-l-xl"></div>
                    <div className="flex items-start">
                        <div className="flex-shrink-0">
                            <Users className="text-purple-500" size={24} />
                        </div>
                        <div className="ml-4">
                            <p className="text-sm text-gray-600 italic">"The textbook exchange helped me afford my groceries this month. Thank you!"</p>
                            <p className="text-xs text-gray-500 font-bold mt-2">- First Year Student</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>

      {/* Available Items */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-grow">
         <h2 className="text-2xl font-bold text-gray-900 mb-6">Free for Pickup</h2>
         {loading ? (
             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[1,2,3,4].map(i => <div key={i} className="h-80 bg-gray-100 rounded-2xl animate-pulse"></div>)}
             </div>
         ) : donationItems.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {donationItems.map(item => (
                    <ItemCard key={item.id} item={item} />
                ))}
            </div>
        ) : (
            <div className="text-center py-20 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                <Box className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                <p className="text-gray-500">No free items currently available. Check back later!</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default Donate;
