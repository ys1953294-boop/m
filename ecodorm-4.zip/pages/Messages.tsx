
import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Search, Send, Paperclip, Phone, Video, User as UserIcon, ArrowLeft, Check, CheckCheck, ShoppingBag } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';

interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  item_id: string | null;
  message: string;
  created_at: string;
  is_read: boolean;
}

interface Conversation {
  id: string; // Composite key: partnerId-itemId
  partnerId: string;
  partnerName: string;
  partnerAvatar: string;
  itemId: string | null;
  itemTitle?: string;
  itemPrice?: number;
  lastMessage: Message;
  unreadCount: number;
}

const Messages: React.FC = () => {
  const { user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Refs for realtime access inside closures
  const userRef = useRef(user);
  const activeIdRef = useRef<string | null>(null);

  const [loading, setLoading] = useState(true);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [sending, setSending] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Pending chat (for "Contact Seller" before first message is sent)
  const [pendingConversation, setPendingConversation] = useState<Conversation | null>(null);

  useEffect(() => {
    userRef.current = user;
  }, [user]);

  useEffect(() => {
    activeIdRef.current = activeConversationId;
    // Scroll to bottom when active chat changes or messages update
    if (scrollRef.current) {
        setTimeout(() => {
            if (scrollRef.current) {
                scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
            }
        }, 100);
    }
  }, [messages, activeConversationId]);

  // 1. Initial Fetch & Subscription
  useEffect(() => {
    if (user) {
      fetchConversations();
      const unsubscribe = subscribeToMessages();
      return () => { unsubscribe(); };
    }
  }, [user]);

  // 2. Handle "Contact Seller" Navigation
  useEffect(() => {
    if (location.state?.initiateChat && !loading && user) {
      const { sellerId, itemId, sellerName, sellerAvatar, itemTitle } = location.state.initiateChat;
      
      // Construct the expected ID for this context
      // Note: We group chats by Partner + Item to keep transactions separate
      const targetId = `${sellerId}-${itemId || 'general'}`;
      
      const existing = conversations.find(c => c.id === targetId);
      
      if (existing) {
        setActiveConversationId(existing.id);
      } else {
        // Prepare a pending conversation
        const tempId = targetId; // Use same format so it transitions smoothly
        const newConv: Conversation = {
          id: tempId,
          partnerId: sellerId,
          partnerName: sellerName || 'Seller',
          partnerAvatar: sellerAvatar || '',
          itemId: itemId,
          itemTitle: itemTitle,
          unreadCount: 0,
          lastMessage: {
            id: 'temp-init',
            sender_id: user.id,
            receiver_id: sellerId,
            item_id: itemId,
            message: '', 
            created_at: new Date().toISOString(),
            is_read: true
          }
        };
        setPendingConversation(newConv);
        setActiveConversationId(tempId);
      }
      // Clear state to prevent loop
      window.history.replaceState({}, document.title);
    }
  }, [location.state, conversations, loading, user]);

  // 3. Fetch All Conversations
  const fetchConversations = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('messages')
        .select(`
          *,
          sender:users!sender_id(id, name, avatar),
          receiver:users!receiver_id(id, name, avatar),
          item:items(id, title, price)
        `)
        .or(`sender_id.eq.${user?.id},receiver_id.eq.${user?.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      if (data) {
        const groupedMap = new Map<string, Conversation>();

        data.forEach((msg: any) => {
          const isMe = msg.sender_id === user?.id;
          const partner = isMe ? msg.receiver : msg.sender;
          
          if (!partner) return; // Skip if partner deleted

          const itemId = msg.item_id || null;
          // Grouping Key: PartnerID + ItemID (or 'general')
          const conversationKey = `${partner.id}-${itemId || 'general'}`;
          
          if (!groupedMap.has(conversationKey)) {
            groupedMap.set(conversationKey, {
              id: conversationKey,
              partnerId: partner.id,
              partnerName: partner.name || 'Unknown',
              partnerAvatar: partner.avatar,
              itemId: itemId,
              itemTitle: msg.item?.title,
              itemPrice: msg.item?.price,
              lastMessage: msg,
              unreadCount: (!isMe && !msg.is_read) ? 1 : 0
            });
          } else {
             const existing = groupedMap.get(conversationKey)!;
             // Since data is ordered by created_at DESC, the first one seen is the latest.
             // We accumulate unread counts.
             if (!isMe && !msg.is_read) {
                 existing.unreadCount += 1;
             }
          }
        });

        setConversations(Array.from(groupedMap.values()));
      }
    } catch (err) {
      console.error('Error fetching conversations:', err);
    } finally {
      setLoading(false);
    }
  };

  // 4. Real-time Subscription
  const subscribeToMessages = () => {
    const sub = supabase
      .channel('public:messages')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages' },
        async (payload) => {
           const newMsg = payload.new as Message;
           const currentUser = userRef.current;
           if (!currentUser) return;

           // Only process if involved
           if (newMsg.sender_id === currentUser.id || newMsg.receiver_id === currentUser.id) {
               
               const partnerId = newMsg.sender_id === currentUser.id ? newMsg.receiver_id : newMsg.sender_id;
               const itemId = newMsg.item_id || 'general';
               const conversationId = `${partnerId}-${itemId}`;
               
               // A. Update Messages View (if active)
               if (activeIdRef.current === conversationId) {
                   setMessages(prev => [...prev, newMsg]);
                   
                   // Mark as read immediately if I am receiving and viewing
                   if (newMsg.receiver_id === currentUser.id) {
                       await supabase.from('messages').update({ is_read: true }).eq('id', newMsg.id);
                   }
               }

               // B. Update Conversation List (Move to top, update preview)
               setConversations(prev => {
                   const idx = prev.findIndex(c => c.id === conversationId);
                   const isViewing = activeIdRef.current === conversationId;
                   const incrementUnread = (newMsg.receiver_id === currentUser.id && !isViewing);

                   if (idx > -1) {
                       // Update existing
                       const updated = {
                           ...prev[idx],
                           lastMessage: newMsg,
                           unreadCount: incrementUnread ? prev[idx].unreadCount + 1 : 0 // Reset if viewing
                       };
                       // Remove old, add new to top
                       const newList = [...prev];
                       newList.splice(idx, 1);
                       return [updated, ...newList];
                   } else {
                       // New conversation - fetch details to be safe or construct
                       // For instant feedback we construct (names might be missing if we don't fetch)
                       // Simple trigger refresh for new contacts
                       fetchConversations();
                       return prev;
                   }
               });
           }
        }
      )
      .subscribe();
      
    return () => { supabase.removeChannel(sub); };
  };

  // 5. Load Messages for Active Chat
  useEffect(() => {
     if (activeConversationId) {
         // Check if it's the pending one
         if (pendingConversation && activeConversationId === pendingConversation.id) {
             setMessages([]); // It's new, no messages
             return;
         }

         const loadMsgs = async () => {
            const conv = conversations.find(c => c.id === activeConversationId);
            if (!conv) return;

            // Fetch messages for this specific Item Context between these two users
            let query = supabase
                .from('messages')
                .select('*')
                .or(`and(sender_id.eq.${user?.id},receiver_id.eq.${conv.partnerId}),and(sender_id.eq.${conv.partnerId},receiver_id.eq.${user?.id})`)
                .order('created_at', { ascending: true });

            if (conv.itemId) {
                query = query.eq('item_id', conv.itemId);
            } else {
                query = query.is('item_id', null);
            }

            const { data } = await query;
            if (data) {
                setMessages(data);
                
                // Mark unread as read
                const unreadIds = data.filter((m: Message) => m.receiver_id === user?.id && !m.is_read).map((m: any) => m.id);
                if (unreadIds.length > 0) {
                    await supabase.from('messages').update({ is_read: true }).in('id', unreadIds);
                    // Update local unread count
                    setConversations(prev => prev.map(c => c.id === activeConversationId ? { ...c, unreadCount: 0 } : c));
                }
            }
         };
         loadMsgs();
     }
  }, [activeConversationId, user, conversations]); // Intentionally removed pendingConversation from deps to avoid flickers

  // 6. Send Message Logic
  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || !user || !activeConversationId || sending) return;

    const activeConv = conversations.find(c => c.id === activeConversationId) || pendingConversation;
    if (!activeConv) return;

    const text = inputText;
    setInputText('');
    setSending(true);

    try {
        const payload = {
            sender_id: user.id,
            receiver_id: activeConv.partnerId,
            item_id: activeConv.itemId || null,
            message: text,
            is_read: false
        };

        const { data, error } = await supabase
            .from('messages')
            .insert([payload])
            .select()
            .single();

        if (error) throw error;
        
        // If this was pending, it's now real.
        if (pendingConversation && activeConversationId === pendingConversation.id) {
            setPendingConversation(null);
            // The subscription will handle adding it to the list, 
            // but we need to ensure the ID matches perfectly in state
            // (it should, as we used the deterministic ID format)
        }

    } catch (err) {
        console.error('Send error:', err);
        alert('Failed to send message');
        setInputText(text); // Restore text
    } finally {
        setSending(false);
    }
  };

  // Group messages by date
  const groupedMessages = messages.reduce((groups: Record<string, Message[]>, message) => {
      const date = new Date(message.created_at).toDateString();
      if (!groups[date]) groups[date] = [];
      groups[date].push(message);
      return groups;
  }, {} as Record<string, Message[]>);

  const formatDateHeader = (dateString: string) => {
      const date = new Date(dateString);
      const now = new Date();
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      
      if (date.toDateString() === now.toDateString()) return 'Today';
      if (date.toDateString() === yesterday.toDateString()) return 'Yesterday';
      return date.toLocaleDateString();
  };

  // Resolve active conversation object
  const activeConvData = conversations.find(c => c.id === activeConversationId) || pendingConversation;

  // Search Filter & Order Request Hiding
  const filteredConversations = conversations.filter(c => {
     // Hide Order Requests sent by me that haven't been replied to yet (effectively)
     // Actually, we just check if the *last* message is an order request sent by me.
     // If the admin replied, the last message would be from the admin (partner).
     const isMyOrderRequest = c.lastMessage.message.includes("🛍️ NEW STORE ORDER REQUEST") && c.lastMessage.sender_id === user?.id;
     
     if (isMyOrderRequest) return false;

     return c.partnerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
     (c.itemTitle && c.itemTitle.toLowerCase().includes(searchTerm.toLowerCase()));
  });
  
  // Login Check
  if (!user) {
      return (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-4">
              <div className="bg-green-100 p-6 rounded-full mb-4">
                 <UserIcon size={32} className="text-forest" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Please Log In</h2>
              <p className="text-gray-500 mt-2 mb-6 max-w-sm">Connect with buyers and sellers on EcoDorm by logging into your account.</p>
              <button onClick={() => navigate('/login')} className="bg-forest text-white px-8 py-3 rounded-xl font-bold hover:bg-green-700 transition">Log In Now</button>
          </div>
      );
  }

  // Adjusted Height calculation: 100vh - (Navbar 64px + BottomNav 64px) = 100vh - 8rem
  return (
    <div className="max-w-7xl mx-auto px-0 md:px-4 sm:px-6 lg:px-8 md:py-6 h-[calc(100vh-8rem)] md:h-[calc(100vh-140px)]">
      <div className="bg-white md:rounded-2xl shadow-sm border border-gray-200 overflow-hidden h-full flex flex-col md:flex-row">
        
        {/* SIDEBAR: Conversation List */}
        {/* Mobile: Hidden if chat is active. Desktop: Always visible */}
        <div className={`w-full md:w-80 border-r border-gray-200 flex-col h-full bg-white z-10 ${activeConversationId ? 'hidden md:flex' : 'flex'}`}>
          <div className="p-4 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900 mb-4 px-1">Messages</h2>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={16} className="text-gray-400" />
              </div>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search chats..."
                className="pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-forest focus:border-transparent w-full text-gray-900 transition"
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {loading ? (
                <div className="p-8 text-center text-gray-400 text-sm flex flex-col items-center">
                    <span className="animate-pulse">Loading conversations...</span>
                </div>
            ) : filteredConversations.length === 0 && !pendingConversation ? (
                <div className="p-8 text-center text-gray-400 text-sm">
                    <p>No messages yet.</p>
                    <p className="mt-2 text-xs">Browse items and contact sellers to start chatting!</p>
                </div>
            ) : (
                <>
                {/* Pending (New) Chat if exists and matches search */}
                {pendingConversation && (
                    <div 
                        onClick={() => setActiveConversationId(pendingConversation.id)}
                        className={`p-4 border-b border-gray-50 cursor-pointer bg-green-50/50 relative`}
                    >
                         <div className="flex items-center opacity-70">
                            <div className="h-12 w-12 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden border border-gray-100">
                                <span className="text-lg font-bold text-gray-600">{pendingConversation.partnerName?.charAt(0).toUpperCase()}</span>
                            </div>
                            <div className="ml-3 flex-1 overflow-hidden min-w-0">
                                <h3 className="text-sm font-semibold text-gray-900 truncate">{pendingConversation.partnerName}</h3>
                                <p className="text-xs text-forest font-medium truncate">New Inquiry: {pendingConversation.itemTitle}</p>
                            </div>
                         </div>
                    </div>
                )}
                
                {filteredConversations.map((conversation) => (
                <div
                    key={conversation.id}
                    onClick={() => setActiveConversationId(conversation.id)}
                    className={`p-4 border-b border-gray-50 cursor-pointer hover:bg-gray-50 transition relative ${
                    activeConversationId === conversation.id ? 'bg-green-50/50' : ''
                    }`}
                >
                    <div className="flex items-center">
                        <div className="relative flex-shrink-0">
                            <div className="h-12 w-12 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden border border-gray-100">
                                <span className="text-lg font-bold text-gray-600">{conversation.partnerName?.charAt(0).toUpperCase()}</span>
                            </div>
                        </div>
                        <div className="ml-3 flex-1 overflow-hidden min-w-0">
                            <div className="flex justify-between items-baseline mb-0.5">
                                <h3 className={`text-sm font-semibold truncate ${conversation.unreadCount > 0 ? 'text-gray-900' : 'text-gray-700'}`}>
                                    {conversation.partnerName}
                                </h3>
                                {conversation.lastMessage.created_at && (
                                    <span className={`text-[10px] ${conversation.unreadCount > 0 ? 'text-forest font-bold' : 'text-gray-400'}`}>
                                        {formatDateHeader(conversation.lastMessage.created_at) === 'Today' 
                                            ? new Date(conversation.lastMessage.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                                            : formatDateHeader(conversation.lastMessage.created_at)}
                                    </span>
                                )}
                            </div>
                            
                            {/* Item Context Label */}
                            {conversation.itemTitle && (
                                <p className="text-[10px] text-gray-500 bg-gray-100 inline-block px-1.5 py-0.5 rounded mb-1 truncate max-w-full">
                                    <ShoppingBag size={8} className="inline mr-1"/> {conversation.itemTitle}
                                </p>
                            )}

                            <div className="flex justify-between items-center mt-0.5">
                                <p className={`text-sm truncate pr-2 ${conversation.unreadCount > 0 ? 'font-medium text-gray-900' : 'text-gray-500'}`}>
                                    {conversation.lastMessage.sender_id === user.id ? 'You: ' : ''}
                                    {conversation.lastMessage.message || 'Sent an attachment'}
                                </p>
                                {conversation.unreadCount > 0 && (
                                    <div className="bg-forest text-white text-[10px] font-bold h-5 min-w-[1.25rem] px-1 flex items-center justify-center rounded-full shadow-sm">
                                        {conversation.unreadCount}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
                ))}
                </>
            )}
          </div>
        </div>

        {/* MAIN CHAT AREA */}
        {/* Mobile: Use fixed positioning with dynamic bottom padding for safe areas */}
        <div 
            className={`flex-1 flex flex-col h-full bg-[#f0f2f5] ${activeConversationId 
                ? 'flex fixed inset-x-0 top-16 bottom-0 z-30 pb-[calc(6.5rem+env(safe-area-inset-bottom))] md:static md:z-auto md:pb-0' 
                : 'hidden md:flex'
            }`}
        >
          {activeConvData ? (
            <>
              {/* Chat Header */}
              <div className="px-4 py-3 bg-white border-b border-gray-200 flex justify-between items-center shadow-sm z-10 sticky top-0">
                <div className="flex items-center gap-3">
                   {/* Mobile Back Button */}
                   <button 
                        onClick={() => setActiveConversationId(null)} 
                        className="md:hidden text-gray-500 p-2 -ml-2 hover:bg-gray-100 rounded-full active:bg-gray-200 transition"
                   >
                       <ArrowLeft size={20} />
                   </button>
                   
                  <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden border border-gray-100">
                      <span className="text-base font-bold text-gray-600">{activeConvData.partnerName?.charAt(0).toUpperCase()}</span>
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-gray-900 leading-tight">{activeConvData.partnerName}</h3>
                    {activeConvData.itemTitle ? (
                        <p className="text-xs text-forest font-medium flex items-center gap-1">
                            Regarding: {activeConvData.itemTitle}
                            {activeConvData.itemPrice && <span className="text-gray-400">| ₹{activeConvData.itemPrice}</span>}
                        </p>
                    ) : (
                        <p className="text-xs text-gray-500">General Inquiry</p>
                    )}
                  </div>
                </div>
                <div className="flex space-x-1 text-gray-500">
                  <button className="hover:bg-gray-100 p-2 rounded-full transition"><Phone size={18} /></button>
                  <button className="hover:bg-gray-100 p-2 rounded-full transition"><Video size={18} /></button>
                </div>
              </div>

              {/* Chat Feed */}
              <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-[#efeae2]" ref={scrollRef}>
                {Object.entries(groupedMessages).map(([date, msgs]) => {
                    const messagesOfDay = msgs as Message[];
                    return (
                        <div key={date}>
                            <div className="flex justify-center mb-4 sticky top-0 z-0">
                                <span className="bg-gray-200/80 backdrop-blur-sm text-gray-600 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-sm">
                                    {formatDateHeader(date)}
                                </span>
                            </div>
                            <div className="space-y-1">
                                {messagesOfDay.map((message, index) => {
                                    const isMe = message.sender_id === user.id;
                                    const isLastInGroup = index === messagesOfDay.length - 1 || messagesOfDay[index + 1].sender_id !== message.sender_id;

                                    return (
                                        <div key={message.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'} mb-1 group`}>
                                            <div className={`max-w-[85%] md:max-w-[70%] relative ${
                                                isMe 
                                                ? 'bg-forest text-white rounded-2xl rounded-tr-sm shadow-sm' 
                                                : 'bg-white text-gray-900 rounded-2xl rounded-tl-sm border border-gray-100 shadow-sm'
                                            } px-4 py-2 text-sm`}>
                                                <p className="break-words leading-relaxed whitespace-pre-wrap">{message.message}</p>
                                                <div className={`flex items-center justify-end gap-1 mt-1 ${isMe ? 'text-green-100' : 'text-gray-400'}`}>
                                                    <span className="text-[10px]">
                                                        {new Date(message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                                    </span>
                                                    {isMe && (
                                                        <span className="flex items-center ml-0.5">
                                                            {message.is_read ? (
                                                                // Read: Double Blue Tick
                                                                <CheckCheck size={16} className="text-blue-300" strokeWidth={2.5} />
                                                            ) : (
                                                                // Unread: Double Gray Tick (Delivered)
                                                                <CheckCheck size={16} className="text-gray-300 opacity-75" strokeWidth={2} />
                                                            )}
                                                        </span>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    );
                })}
                
                {messages.length === 0 && (
                    <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 py-10 opacity-60">
                         <div className="bg-white p-4 rounded-full mb-4 shadow-sm flex items-center justify-center h-24 w-24">
                             <span className="text-4xl font-bold text-gray-400">{activeConvData.partnerName?.charAt(0).toUpperCase()}</span>
                         </div>
                        <p className="text-sm">Start your conversation with <span className="font-bold text-gray-900">{activeConvData.partnerName}</span></p>
                        <p className="text-xs mt-1">
                             {activeConvData.itemTitle ? `Discussing: ${activeConvData.itemTitle}` : 'Say hello!'}
                        </p>
                    </div>
                )}
              </div>

              {/* Message Input */}
              <div className="p-3 md:p-4 bg-white border-t border-gray-200">
                <form 
                    onSubmit={handleSend}
                    className="flex items-end gap-2 bg-gray-50 p-1.5 rounded-3xl border border-gray-200 focus-within:ring-2 focus-within:ring-forest/20 focus-within:border-forest transition"
                >
                  <button type="button" className="p-2 text-gray-400 hover:text-forest hover:bg-white rounded-full transition flex-shrink-0" title="Attach file">
                    <Paperclip size={20} />
                  </button>
                  <textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSend();
                        }
                    }}
                    placeholder="Type a message..."
                    rows={1}
                    className="flex-1 bg-transparent border-none focus:ring-0 text-gray-900 text-sm py-2.5 px-2 max-h-32 min-h-[44px] resize-none"
                    style={{ height: 'auto', minHeight: '44px' }}
                  />
                  <button 
                    type="submit" 
                    className={`p-2.5 rounded-full transition flex-shrink-0 ${
                        inputText.trim() 
                        ? 'bg-forest text-white hover:bg-green-700 shadow-md transform active:scale-95' 
                        : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    }`}
                    disabled={!inputText.trim() || sending}
                  >
                    <Send size={18} className={inputText.trim() ? "ml-0.5" : ""} />
                  </button>
                </form>
              </div>
            </>
          ) : (
            // Empty State (No Chat Selected)
            <div className="flex-1 flex flex-col items-center justify-center text-gray-400 bg-gray-50/50">
              <div className="h-24 w-24 bg-white rounded-full flex items-center justify-center mb-6 shadow-sm border border-gray-100">
                 <div className="bg-green-50 p-4 rounded-full">
                    <Send size={32} className="text-forest ml-1 mt-1"/>
                 </div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Your Messages</h3>
              <p className="text-sm max-w-xs text-center mt-2">Select a conversation from the sidebar to start chatting or check your inbox.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Messages;
