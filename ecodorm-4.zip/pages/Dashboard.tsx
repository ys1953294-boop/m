
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import { Settings, Package, MessageSquare, Leaf, User as UserIcon, LogOut, Edit, Trash2, Eye, EyeOff, Loader2, Plus, X, Save, RefreshCw } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';
import { supabase } from '../lib/supabase';
import { Item } from '../types';
import { CAMPUS_OPTIONS } from '../constants';

const impactData = [
  { name: 'Reused', value: 400 },
  { name: 'Donated', value: 300 },
  { name: 'Recycled', value: 100 },
];

const COLORS = ['#228B22', '#FFC107', '#0088FE'];

const Dashboard: React.FC = () => {
  const { user, signOut, loading, updateUserProfile } = useAuth();
  const navigate = useNavigate();
  const [showSettings, setShowSettings] = useState(false);
  const [activeTab, setActiveTab] = useState<'listings' | 'overview'>('listings');
  
  // Profile Edit State
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [editName, setEditName] = useState('');
  const [editCampus, setEditCampus] = useState('');
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
  
  // Listings State
  const [myItems, setMyItems] = useState<Item[]>([]);
  const [loadingItems, setLoadingItems] = useState(false);
  // Track which specific item is being acted upon (for spinners)
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  // Redirect if not logged in
  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user && activeTab === 'listings') {
        fetchMyItems();
    }
  }, [user, activeTab]);

  const fetchMyItems = async () => {
    if (!user) return;
    setLoadingItems(true);
    // Fetch ALL items (active and inactive) belonging to the user
    const { data, error } = await supabase
        .from('items')
        .select('*')
        .eq('seller_id', user.id)
        .order('created_at', { ascending: false });

    if (data) {
        const mapped: Item[] = data.map((d: any) => ({
            id: d.id,
            title: d.title,
            description: d.description,
            price: d.price,
            originalPrice: d.original_price,
            image: d.images?.[0] || 'https://via.placeholder.com/400',
            images: d.images,
            category: d.category,
            condition: d.condition,
            type: d.type,
            seller: user!, 
            postedAt: d.created_at,
            isActive: d.is_active
        }));
        setMyItems(mapped);
    } else if (error) {
        console.error("Error fetching items:", error);
    }
    setLoadingItems(false);
  };

  const handleOpenEditProfile = () => {
      if (user) {
          setEditName(user.name);
          setEditCampus(user.campus || CAMPUS_OPTIONS[0]);
          setShowEditProfile(true);
          setShowSettings(false);
      }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
      e.preventDefault();
      setIsUpdatingProfile(true);
      try {
          await updateUserProfile(editName, editCampus);
          setShowEditProfile(false);
      } catch (err: any) {
          alert("Failed to update profile: " + err.message);
      } finally {
          setIsUpdatingProfile(false);
      }
  };

  // --- FUNCTION: Delete Listing ---
  const handleDelete = async (e: React.MouseEvent, item: Item) => {
      e.preventDefault();
      e.stopPropagation();
      
      if(!window.confirm("Are you sure you want to permanently delete this listing? This action cannot be undone.")) return;

      setActionLoadingId(item.id);

      try {
          // STEP 1: Delete from Database FIRST
          const { error } = await supabase
            .from('items')
            .delete()
            .eq('id', item.id)
            .eq('seller_id', user?.id); // Double check ownership

          if (error) throw error;

          // STEP 2: UI Update (Remove from list immediately)
          setMyItems(prev => prev.filter(i => i.id !== item.id));

          // STEP 3: Clean up Images in background (Best Effort)
          if (item.images && item.images.length > 0) {
              const pathsToDelete = item.images.map(url => {
                  try {
                      // Extract path after '/item-images/'
                      const parts = url.split('/item-images/');
                      if (parts.length > 1) {
                          return decodeURIComponent(parts[1]);
                      }
                      return null;
                  } catch (e) {
                      return null;
                  }
              }).filter(path => path !== null) as string[];

              if (pathsToDelete.length > 0) {
                  // Fire and forget image cleanup
                  supabase.storage.from('item-images').remove(pathsToDelete).then(({ error }) => {
                      if (error) console.warn("Background image cleanup warning:", error);
                  });
              }
          }

      } catch (error: any) {
          console.error("Delete failed:", error);
          alert(`Failed to delete: ${error.message}`);
          fetchMyItems();
      } finally {
          setActionLoadingId(null);
      }
  };

  // --- FUNCTION: Hide/Unhide Listing ---
  const handleToggleStatus = async (e: React.MouseEvent, item: Item) => {
    e.preventDefault();
    e.stopPropagation();
    
    const newStatus = !item.isActive;
    setActionLoadingId(item.id);

    try {
        const { error } = await supabase
            .from('items')
            .update({ is_active: newStatus })
            .eq('id', item.id)
            .eq('seller_id', user?.id);
        
        if (error) throw error;

        // Optimistic UI Update
        setMyItems(prev => prev.map(i => i.id === item.id ? { ...i, isActive: newStatus } : i));
        
    } catch (error: any) {
        console.error("Update failed:", error);
        alert("Failed to update status. " + error.message);
    } finally {
        setActionLoadingId(null);
    }
  };

  const handleEdit = (e: React.MouseEvent, itemId: string) => {
      e.preventDefault();
      e.stopPropagation();
      navigate(`/edit-item/${itemId}`);
  };

  const handleLogout = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out', error);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <Loader2 className="animate-spin h-8 w-8 mx-auto text-forest mb-4" />
        <h2 className="text-xl font-bold text-gray-900">Loading your profile...</h2>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <Loader2 className="animate-spin h-8 w-8 mx-auto text-forest mb-4" />
        <h2 className="text-xl font-bold text-gray-900">Redirecting to login...</h2>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 md:py-8">
      {/* Profile Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 mb-6 md:mb-8 flex flex-col md:flex-row items-center gap-4 md:gap-6 relative">
        <div className="h-16 w-16 md:h-24 md:w-24 rounded-full bg-forest text-white flex items-center justify-center text-3xl md:text-5xl font-bold ring-4 ring-green-50">
           {user.name?.charAt(0).toUpperCase()}
        </div>
        <div className="flex-1 text-center md:text-left">
          <h1 className="text-xl md:text-2xl font-bold text-gray-900 flex items-center justify-center md:justify-start gap-2">
            {user.name} 
            {user.verified && <span className="bg-blue-100 text-blue-800 text-[10px] md:text-xs px-2 py-0.5 rounded-full font-medium">Verified</span>}
          </h1>
          <p className="text-sm text-gray-500">{user.email}</p>
          <p className="text-gray-400 text-xs md:text-sm font-medium mt-1 text-forest">{user.campus}</p>
          <div className="mt-3 md:mt-4 flex flex-wrap justify-center md:justify-start gap-3 md:gap-4">
             <div className="bg-green-50 px-3 py-1.5 md:px-4 md:py-2 rounded-lg border border-green-100">
                <p className="text-[10px] md:text-xs text-green-600 font-semibold uppercase">Sustainability Score</p>
                <p className="text-lg md:text-xl font-bold text-forest">{user.sustainabilityScore} pts</p>
             </div>
             <div className="bg-amber-50 px-3 py-1.5 md:px-4 md:py-2 rounded-lg border border-amber-100">
                <p className="text-[10px] md:text-xs text-amber-700 font-semibold uppercase">Waste Diverted</p>
                <p className="text-lg md:text-xl font-bold text-amber-600">12.5 kg</p>
             </div>
          </div>
        </div>
        
        {/* Settings Dropdown */}
        <div className="absolute top-2 right-2 md:top-6 md:right-6 md:static md:flex md:gap-3 z-20">
          <div className="relative">
            <button 
                onClick={() => setShowSettings(!showSettings)}
                className="p-1.5 md:p-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-600 transition"
            >
                <Settings size={18} className="md:w-5 md:h-5" />
            </button>
            
            {showSettings && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-100 py-1 z-50">
                    <button 
                        onClick={handleOpenEditProfile}
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
                    >
                        Edit Profile
                    </button>
                    <button 
                        onClick={handleLogout}
                        className="flex items-center w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 font-medium"
                    >
                        <LogOut size={16} className="mr-2" /> Log Out
                    </button>
                </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        
        {/* Left Column: Content */}
        <div className="lg:col-span-2 space-y-6 md:space-y-8 order-2 lg:order-1">
           
           {activeTab === 'overview' && (
               <>
                <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100">
                    <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                        <Leaf className="mr-2 text-forest" size={20} /> 
                        Your Impact Breakdown
                    </h3>
                    <div className="h-64 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                            <Pie
                                data={impactData}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={80}
                                fill="#8884d8"
                                paddingAngle={5}
                                dataKey="value"
                            >
                                {impactData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <RechartsTooltip />
                            <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </div>
               </>
           )}

           {activeTab === 'listings' && (
               <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100">
                   <div className="flex justify-between items-center mb-4 md:mb-6">
                       <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                           <Package size={20} className="text-forest"/> My Listings
                       </h3>
                       <div className="flex gap-2">
                            <button 
                                onClick={fetchMyItems}
                                title="Refresh Listings"
                                className="flex items-center justify-center p-2 text-gray-500 hover:text-forest bg-gray-50 rounded-lg hover:bg-green-50 transition"
                            >
                                <RefreshCw size={18} className={loadingItems ? "animate-spin" : ""} />
                            </button>
                            <Link to="/sell" className="flex items-center text-sm bg-forest text-white px-3 py-1.5 md:px-4 md:py-2 rounded-lg hover:bg-green-700 transition shadow-sm hover:shadow">
                                <Plus size={16} className="mr-1"/> <span className="hidden md:inline">Add New Listing</span><span className="md:hidden">Add</span>
                            </Link>
                       </div>
                   </div>
                   
                   {loadingItems ? (
                       <div className="text-center py-12 text-gray-500 flex flex-col items-center">
                           <Loader2 size={30} className="animate-spin text-forest mb-2"/>
                           Loading your items...
                       </div>
                   ) : myItems.length === 0 ? (
                       <div className="text-center py-12 text-gray-500 border border-dashed border-gray-200 rounded-lg">
                           <Package size={40} className="mx-auto text-gray-300 mb-3" />
                           <p className="font-medium">You haven't listed any items yet.</p>
                           <p className="text-sm mt-1 mb-4">Time to declutter your dorm!</p>
                           <Link to="/sell" className="text-forest hover:underline font-medium text-sm">Create your first listing</Link>
                       </div>
                   ) : (
                       <div className="space-y-4">
                           {myItems.map(item => (
                               <div 
                                    key={item.id} 
                                    onClick={() => navigate(`/item/${item.id}`)}
                                    className={`flex flex-col sm:flex-row gap-4 border rounded-xl p-3 md:p-4 transition bg-white relative cursor-pointer ${item.isActive ? 'border-gray-100 hover:shadow-md' : 'border-gray-200 bg-gray-50 opacity-90'}`}
                               >
                                   
                                   {/* Image */}
                                   <div className="h-20 w-20 md:h-24 md:w-24 flex-shrink-0 bg-gray-100 rounded-lg overflow-hidden border border-gray-100 relative">
                                       <img src={item.image} alt={item.title} className={`h-full w-full object-cover ${!item.isActive && 'grayscale'}`} />
                                       {!item.isActive && (
                                           <div className="absolute inset-0 bg-black/10 flex items-center justify-center">
                                                <EyeOff className="text-white drop-shadow-md" />
                                           </div>
                                       )}
                                   </div>

                                   {/* Content */}
                                   <div className="flex-1 min-w-0">
                                       <div className="flex justify-between items-start">
                                            <div>
                                                <h4 className="font-bold text-gray-900 truncate text-base md:text-lg">{item.title}</h4>
                                                <div className="flex items-center gap-2 mt-1">
                                                    <span className="text-forest font-bold">₹{item.price.toLocaleString()}</span>
                                                    <span className="text-gray-300">|</span>
                                                    <span className="text-xs text-gray-500">{item.category}</span>
                                                </div>
                                            </div>
                                            {/* Status Badge */}
                                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wide border ${
                                                item.isActive 
                                                    ? 'bg-green-50 text-green-700 border-green-100' 
                                                    : 'bg-gray-100 text-gray-500 border-gray-200'
                                            }`}>
                                                {item.isActive ? 'Active' : 'Hidden'}
                                            </span>
                                       </div>
                                       
                                       <div className="flex items-center gap-2 md:gap-4 mt-2 md:mt-3 text-[10px] md:text-xs text-gray-400">
                                           <span>Posted: {new Date(item.postedAt).toLocaleDateString()}</span>
                                       </div>
                                   </div>
                                   
                                   {/* Action Buttons Toolbar */}
                                   <div className="flex sm:flex-col justify-end gap-2 mt-2 sm:mt-0 pt-2 sm:pt-0 sm:pl-4 border-t sm:border-t-0 sm:border-l border-gray-100 min-w-[100px]">
                                       
                                       {/* Toggle Visibility */}
                                       <button 
                                            type="button"
                                            onClick={(e) => handleToggleStatus(e, item)}
                                            disabled={actionLoadingId === item.id}
                                            className="flex-1 flex items-center justify-center sm:justify-start px-2 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100 rounded transition"
                                       >
                                           {item.isActive ? <EyeOff size={14} className="mr-1 md:mr-2" /> : <Eye size={14} className="mr-1 md:mr-2" />}
                                           {item.isActive ? 'Hide' : 'Show'}
                                       </button>
                                       
                                       {/* Edit */}
                                       <button
                                            type="button"
                                            onClick={(e) => handleEdit(e, item.id)}
                                            disabled={actionLoadingId === item.id}
                                            className="flex-1 flex items-center justify-center sm:justify-start px-2 py-1.5 text-xs font-medium text-blue-600 hover:bg-blue-50 rounded transition"
                                       >
                                           <Edit size={14} className="mr-1 md:mr-2" /> Edit
                                       </button>
                                       
                                       {/* Delete */}
                                       <button 
                                            type="button"
                                            onClick={(e) => handleDelete(e, item)}
                                            disabled={actionLoadingId === item.id}
                                            className="flex-1 flex items-center justify-center sm:justify-start px-2 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 rounded transition"
                                       >
                                           {actionLoadingId === item.id ? <Loader2 size={14} className="animate-spin mr-1 md:mr-2" /> : <Trash2 size={14} className="mr-1 md:mr-2" />}
                                           Del
                                       </button>
                                   </div>
                               </div>
                           ))}
                       </div>
                   )}
               </div>
           )}
        </div>

        {/* Right Column: Menu */}
        <div className="space-y-6 order-1 lg:order-2">
            <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100 sticky top-20 md:top-24">
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Dashboard Menu</h3>
                <nav className="flex lg:block gap-2 overflow-x-auto pb-2 lg:pb-0 lg:space-y-2 no-scrollbar">
                    <button 
                        onClick={() => setActiveTab('listings')}
                        className={`flex-shrink-0 lg:w-full flex items-center justify-between p-3 rounded-lg text-left transition ${
                            activeTab === 'listings' 
                            ? 'bg-forest/10 text-forest font-semibold' 
                            : 'text-gray-600 hover:bg-gray-50'
                        }`}
                    >
                        <span className="flex items-center">
                            <Package size={18} className={`mr-2 lg:mr-3 ${activeTab === 'listings' ? 'text-forest' : 'text-gray-400'}`} /> 
                            <span className="whitespace-nowrap">My Listings</span>
                        </span>
                    </button>

                    <button 
                        onClick={() => setActiveTab('overview')}
                        className={`flex-shrink-0 lg:w-full flex items-center justify-between p-3 rounded-lg text-left transition ${
                            activeTab === 'overview' 
                            ? 'bg-forest/10 text-forest font-semibold' 
                            : 'text-gray-600 hover:bg-gray-50'
                        }`}
                    >
                        <span className="flex items-center">
                            <Leaf size={18} className={`mr-2 lg:mr-3 ${activeTab === 'overview' ? 'text-forest' : 'text-gray-400'}`} /> 
                            <span className="whitespace-nowrap">Impact Overview</span>
                        </span>
                    </button>
                    
                    <Link to="/messages" className="flex-shrink-0 lg:w-full flex items-center justify-between p-3 rounded-lg text-left text-gray-600 hover:bg-gray-50 transition">
                        <span className="flex items-center">
                            <MessageSquare size={18} className="mr-2 lg:mr-3 text-gray-400" /> 
                            <span className="whitespace-nowrap">Messages</span>
                        </span>
                    </Link>

                    <div className="hidden lg:block pt-4 mt-4 border-t border-gray-100">
                        <Link to="/sell" className="w-full flex items-center justify-center p-3 rounded-lg bg-forest text-white font-semibold hover:bg-green-700 transition shadow-md shadow-green-900/10">
                            <Plus size={18} className="mr-2" /> List New Item
                        </Link>
                    </div>
                </nav>
            </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      {showEditProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden relative">
                <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                    <h2 className="text-xl font-bold text-gray-900">Edit Profile</h2>
                    <button onClick={() => setShowEditProfile(false)} className="text-gray-400 hover:text-gray-600">
                        <X size={24} />
                    </button>
                </div>
                <form onSubmit={handleSaveProfile} className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                        <input 
                            type="text" 
                            required
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-forest focus:border-forest outline-none"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Campus</label>
                        <select 
                            value={editCampus}
                            onChange={(e) => setEditCampus(e.target.value)}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-forest focus:border-forest outline-none"
                        >
                            {CAMPUS_OPTIONS.map((c, i) => (
                                <option key={i} value={c}>{c}</option>
                            ))}
                        </select>
                    </div>
                    <div className="pt-4 flex justify-end gap-3">
                        <button 
                            type="button" 
                            onClick={() => setShowEditProfile(false)}
                            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
                        >
                            Cancel
                        </button>
                        <button 
                            type="submit" 
                            disabled={isUpdatingProfile}
                            className="px-4 py-2 bg-forest text-white rounded-lg hover:bg-green-700 flex items-center"
                        >
                            {isUpdatingProfile ? <Loader2 size={16} className="animate-spin mr-2"/> : <Save size={16} className="mr-2"/>}
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
