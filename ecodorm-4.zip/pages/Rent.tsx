
import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import ItemCard from '../components/ItemCard';
import { Calendar, Search, ShieldCheck, Clock, Layers, ArrowLeft } from 'lucide-react';
import { Item } from '../types';
import { Link } from 'react-router-dom';

const Rent: React.FC = () => {
  const [rentalItems, setRentalItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('');
  
  // New State for Frequency Filter
  const [frequencyFilter, setFrequencyFilter] = useState<'all' | 'day' | 'month'>('all');

  useEffect(() => {
    fetchRentals();
  }, []);

  const fetchRentals = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('items')
        .select('*, seller:users(*)')
        .eq('type', 'rent')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (data) {
        const mapped: Item[] = data.map((d: any) => ({
            id: d.id,
            title: d.title,
            description: d.description,
            price: d.price,
            image: d.images?.[0] || 'https://via.placeholder.com/400',
            images: d.images,
            category: d.category,
            condition: d.condition,
            type: d.type,
            rentalPeriod: d.rental_period,
            seller: {
              id: d.seller?.id,
              name: d.seller?.name || 'Unknown',
              campus: d.seller?.campus,
              verified: d.seller?.verified,
              avatar: d.seller?.avatar,
              sustainabilityScore: d.seller?.sustainability_score
            },
            postedAt: d.created_at,
            isActive: d.is_active
        }));
        setRentalItems(mapped);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filteredItems = rentalItems.filter(item => {
      if (frequencyFilter === 'all') return true;
      // If item.rentalPeriod is undefined, assume 'day' for backward compatibility
      const period = item.rentalPeriod || 'day';
      return period === frequencyFilter;
  });

  return (
    <div className="flex flex-col min-h-screen">
      {/* Search Header */}
      <div className="bg-blue-600 py-12 text-white relative">
        <div className="absolute top-4 left-4 sm:top-8 sm:left-8">
             <Link to="/" className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition flex items-center justify-center backdrop-blur-sm">
                 <ArrowLeft size={20} />
             </Link>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-extrabold mb-4 text-center">Rent What You Need, When You Need It</h1>
            <p className="text-center text-blue-100 mb-8 max-w-2xl mx-auto">
                Don't buy it if you only need it for a week. Save money and space by renting from other students.
            </p>
            
            <div className="max-w-3xl mx-auto bg-white rounded-lg p-2 flex flex-col md:flex-row gap-2 shadow-lg">
                <div className="flex-1 flex items-center border-b md:border-b-0 md:border-r border-gray-200 px-4 py-2">
                    <Search className="text-gray-400 mr-2" size={20} />
                    <input 
                        type="text" 
                        placeholder="What do you need?" 
                        className="w-full bg-transparent text-gray-900 outline-none"
                    />
                </div>
                <div className="flex-1 flex items-center px-4 py-2">
                    <Calendar className="text-gray-400 mr-2" size={20} />
                    <input 
                        type="text" 
                        placeholder="Select dates" 
                        className="w-full bg-transparent text-gray-900 outline-none"
                        value={dateRange}
                        onChange={(e) => setDateRange(e.target.value)}
                        onFocus={(e) => e.target.type = 'date'}
                        onBlur={(e) => e.target.type = 'text'}
                    />
                </div>
                <button className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-8 rounded-md transition">
                    Find Items
                </button>
            </div>
        </div>
      </div>

      {/* How it works */}
      <div className="bg-white py-12 border-b border-gray-200">
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-center text-lg font-bold text-gray-900 uppercase tracking-wide mb-8">How it works</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div className="p-4">
                    <div className="mx-auto h-12 w-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-4">
                        <Calendar size={24} />
                    </div>
                    <h3 className="font-semibold text-gray-900">1. Book Dates</h3>
                    <p className="text-sm text-gray-500 mt-2">Select the days you need the item. Pay only for the time you use.</p>
                </div>
                <div className="p-4">
                    <div className="mx-auto h-12 w-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-4">
                        <ShieldCheck size={24} />
                    </div>
                    <h3 className="font-semibold text-gray-900">2. Secure Deposit</h3>
                    <p className="text-sm text-gray-500 mt-2">We hold a refundable deposit to keep everyone's items safe.</p>
                </div>
                <div className="p-4">
                    <div className="mx-auto h-12 w-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-4">
                        <Clock size={24} />
                    </div>
                    <h3 className="font-semibold text-gray-900">3. Return & Refund</h3>
                    <p className="text-sm text-gray-500 mt-2">Return the item in good condition and get your deposit back instantly.</p>
                </div>
            </div>
         </div>
      </div>

      {/* Items Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-grow">
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Available for Rent</h2>
            
            {/* Rent Period Toggle */}
            <div className="flex bg-gray-100 p-1 rounded-lg">
                <button 
                    onClick={() => setFrequencyFilter('all')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-md transition ${frequencyFilter === 'all' ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    All
                </button>
                <button 
                    onClick={() => setFrequencyFilter('day')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-md transition ${frequencyFilter === 'day' ? 'bg-white shadow text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    Per Day
                </button>
                <button 
                    onClick={() => setFrequencyFilter('month')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-md transition ${frequencyFilter === 'month' ? 'bg-white shadow text-green-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    Per Month
                </button>
            </div>
        </div>

        {loading ? (
             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[1,2,3,4].map(i => <div key={i} className="h-80 bg-gray-100 rounded-2xl animate-pulse"></div>)}
             </div>
        ) : filteredItems.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {filteredItems.map(item => (
                    <ItemCard key={item.id} item={item} />
                ))}
            </div>
        ) : (
            <div className="text-center py-20 bg-gray-50 rounded-lg">
                <Layers className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                <p className="text-gray-500">No rental items found for this selection.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default Rent;
