
import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, Upload, FileText, Send, Loader2, 
  BrainCircuit, List, HelpCircle, FileCheck, X,
  ChevronRight, Sparkles, MessageSquare, Plus, File
} from 'lucide-react';
import { GoogleGenAI, Chat } from "@google/genai";
import { Link } from 'react-router-dom';

interface Message {
  role: 'user' | 'model';
  text: string;
}

const EcoLearnAI: React.FC = () => {
  // File State
  const [file, setFile] = useState<File | null>(null);
  const [pdfBase64, setPdfBase64] = useState<string | null>(null);
  const [isProcessingFile, setIsProcessingFile] = useState(false);

  // Chat State
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chatSession, setChatSession] = useState<Chat | null>(null);

  // UI State
  const [activeTab, setActiveTab] = useState<'chat' | 'mindmap'>('chat');
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Auto scroll chat
    if (chatContainerRef.current) {
        chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  // --- FILE HANDLING ---
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      if (selectedFile.type !== 'application/pdf') {
        alert('Please upload a PDF file.');
        return;
      }
      setFile(selectedFile);
      setIsProcessingFile(true);
      
      try {
        const base64 = await fileToBase64(selectedFile);
        // Remove data URI prefix for API
        const cleanBase64 = base64.split(',')[1];
        setPdfBase64(cleanBase64);
        
        // Initialize Chat with File Context
        await initializeChat(cleanBase64);
        
        setMessages([{
            role: 'model',
            text: `I've analyzed **${selectedFile.name}**. \n\nI'm ready! You can ask me to **Summarize**, generate **Questions**, create a **Mind Map**, or just chat about the content.`
        }]);
      } catch (err) {
        console.error("File processing error:", err);
        alert("Failed to process PDF.");
        setFile(null);
      } finally {
        setIsProcessingFile(false);
      }
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const clearFile = () => {
      setFile(null);
      setPdfBase64(null);
      setMessages([]);
      setChatSession(null);
      setActiveTab('chat');
  };

  // --- AI INTEGRATION ---
  const initializeChat = async (base64Data: string) => {
      try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          const chat = ai.chats.create({
              model: 'gemini-2.0-flash-exp', // Using Flash for large context window
              config: {
                  systemInstruction: "You are an expert academic tutor. You help students understand PDF documents. Always answer based on the provided document context. If asked for a Mind Map, use Markdown indentation (bulley points) to represent hierarchy clearly."
              }
          });
          
          setChatSession(chat);
      } catch (err) {
          console.error("AI Init Error:", err);
      }
  };

  const generateResponse = async (prompt: string, displayPrompt?: string) => {
      if (!chatSession || !pdfBase64) return;

      // 1. Add User Message
      setMessages(prev => [...prev, { role: 'user', text: displayPrompt || prompt }]);
      setIsTyping(true);
      setInputText('');

      try {
          // Send message WITH the PDF data as inline part
          // Fix: Use 'message' instead of 'contents'
          const result = await chatSession.sendMessage({
              message: {
                  role: 'user',
                  parts: [
                      { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
                      { text: prompt }
                  ]
              }
          });

          // Fix: Access .text property directly
          const responseText = result.text;
          if (responseText) {
              setMessages(prev => [...prev, { role: 'model', text: responseText }]);
          } else {
              setMessages(prev => [...prev, { role: 'model', text: "No response generated." }]);
          }

      } catch (err) {
          console.error("Generation Error:", err);
          setMessages(prev => [...prev, { role: 'model', text: "Sorry, I encountered an error processing that request." }]);
      } finally {
          setIsTyping(false);
      }
  };

  // --- QUICK ACTIONS ---
  const handleSummarize = () => {
      generateResponse("Provide a detailed summary of this document. Break it down into key concepts and takeaways.", "Summarize this document");
  };

  const handleQuestions = () => {
      generateResponse("Generate 5-10 most important exam-style questions based on this document, along with brief answers.", "Generate important questions");
  };

  const handleMindMap = () => {
      generateResponse("Create a structured text-based Mind Map / Hierarchical Outline of the main concepts in this document. Use bullet points with indentation to show relationships.", "Create a Mind Map");
      setActiveTab('chat'); // View it in chat for now, could act as a separate tab if we parsed it
  };

  const handleShortNotes = () => {
      generateResponse("Create a 'Cheat Sheet' of short notes from this document. Focus on definitions, formulas, and key dates/facts.", "Generate Short Notes");
  };

  const handleSendMessage = (e: React.FormEvent) => {
      e.preventDefault();
      if (!inputText.trim() || !chatSession) return;
      
      setMessages(prev => [...prev, { role: 'user', text: inputText }]);
      setIsTyping(true);
      const text = inputText;
      setInputText('');

      // Fix: Use 'message' instead of 'contents'
      chatSession.sendMessage({
          message: text
      }).then(result => {
          // Fix: Access .text property directly
          const responseText = result.text;
          if (responseText) {
              setMessages(prev => [...prev, { role: 'model', text: responseText }]);
          }
          setIsTyping(false);
      }).catch(err => {
          console.error("Chat Error:", err);
          setMessages(prev => [...prev, { role: 'model', text: "Error sending message." }]);
          setIsTyping(false);
      });
  };

  // Helper to format AI response (Basic Markdown)
  const formatText = (text: string) => {
      // Split by newlines
      return text.split('\n').map((line, i) => {
          // Bold
          const bolded = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
          // Bullet points logic handled by CSS usually, but simple check:
          const isBullet = line.trim().startsWith('* ') || line.trim().startsWith('- ');
          
          return (
              <p 
                key={i} 
                className={`mb-1 ${isBullet ? 'pl-4 relative' : ''} text-sm md:text-base leading-relaxed`}
                dangerouslySetInnerHTML={{ __html: isBullet ? `• ${bolded.substring(2)}` : bolded }}
              />
          );
      });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-16 md:top-20 z-20">
            <div className="flex items-center gap-3">
                <Link to="/learn" className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition">
                    <ArrowLeft size={20} />
                </Link>
                <div>
                    <h1 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                        <BrainCircuit className="text-cyan-600" size={24} /> 
                        AI Study Companion
                    </h1>
                    <p className="text-xs text-gray-500 hidden md:block">Powered by Gemini 2.0</p>
                </div>
            </div>
            {file && (
                <button onClick={clearFile} className="text-xs font-bold text-red-500 hover:bg-red-50 px-3 py-1.5 rounded-lg transition">
                    Change PDF
                </button>
            )}
        </div>

        <div className="flex-grow flex flex-col md:flex-row h-[calc(100vh-8rem)] overflow-hidden">
            
            {/* LEFT PANEL: Upload & Controls */}
            <div className={`w-full md:w-80 bg-white border-r border-gray-200 flex flex-col ${file ? 'hidden md:flex' : 'flex'}`}>
                
                {/* Upload Area */}
                {!file ? (
                    <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-gray-50/50 m-4 rounded-3xl border-2 border-dashed border-gray-300 hover:border-cyan-500 transition-colors cursor-pointer relative group">
                        <input 
                            type="file" 
                            accept="application/pdf" 
                            onChange={handleFileUpload}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                        />
                        <div className="bg-cyan-100 p-4 rounded-full text-cyan-600 mb-4 group-hover:scale-110 transition-transform">
                            <Upload size={32} />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 mb-1">Upload PDF</h3>
                        <p className="text-sm text-gray-500 mb-4">Drag & drop notes or PYQs here</p>
                        <span className="text-xs text-cyan-600 font-bold bg-cyan-50 px-3 py-1 rounded-full">PDF Only</span>
                    </div>
                ) : (
                    <div className="p-6">
                        <div className="bg-cyan-50 border border-cyan-100 rounded-xl p-4 mb-6 flex items-start gap-3">
                            <FileText size={24} className="text-cyan-600 flex-shrink-0 mt-1" />
                            <div className="overflow-hidden">
                                <h3 className="font-bold text-gray-900 truncate text-sm" title={file.name}>{file.name}</h3>
                                <p className="text-xs text-gray-500 mt-0.5">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                            </div>
                        </div>

                        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Quick Actions</h3>
                        
                        <div className="space-y-3">
                            <button onClick={handleSummarize} disabled={isTyping} className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-gray-200 hover:border-cyan-300 hover:bg-cyan-50 rounded-xl transition text-left group disabled:opacity-50">
                                <FileCheck size={18} className="text-gray-400 group-hover:text-cyan-600" />
                                <span className="text-sm font-semibold text-gray-700 group-hover:text-cyan-800">Summarize</span>
                            </button>
                            
                            <button onClick={handleQuestions} disabled={isTyping} className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-gray-200 hover:border-orange-300 hover:bg-orange-50 rounded-xl transition text-left group disabled:opacity-50">
                                <HelpCircle size={18} className="text-gray-400 group-hover:text-orange-600" />
                                <span className="text-sm font-semibold text-gray-700 group-hover:text-orange-800">Important Questions</span>
                            </button>
                            
                            <button onClick={handleMindMap} disabled={isTyping} className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-gray-200 hover:border-purple-300 hover:bg-purple-50 rounded-xl transition text-left group disabled:opacity-50">
                                <BrainCircuit size={18} className="text-gray-400 group-hover:text-purple-600" />
                                <span className="text-sm font-semibold text-gray-700 group-hover:text-purple-800">Mind Map</span>
                            </button>
                            
                            <button onClick={handleShortNotes} disabled={isTyping} className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-gray-200 hover:border-emerald-300 hover:bg-emerald-50 rounded-xl transition text-left group disabled:opacity-50">
                                <List size={18} className="text-gray-400 group-hover:text-emerald-600" />
                                <span className="text-sm font-semibold text-gray-700 group-hover:text-emerald-800">Short Notes</span>
                            </button>
                        </div>
                    </div>
                )}
            </div>

            {/* RIGHT PANEL: Chat Area */}
            {file ? (
                <div className="flex-1 flex flex-col bg-[#f8fafc] relative">
                    {/* Chat Feed */}
                    <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
                        {messages.length === 0 && !isProcessingFile && (
                            <div className="h-full flex flex-col items-center justify-center text-gray-400">
                                <Sparkles size={40} className="mb-4 text-cyan-200" />
                                <p>Select an action or ask a question to start.</p>
                            </div>
                        )}

                        {isProcessingFile && (
                            <div className="flex flex-col items-center justify-center h-full animate-pulse">
                                <div className="h-12 w-12 bg-cyan-100 rounded-full flex items-center justify-center mb-4">
                                    <Loader2 className="animate-spin text-cyan-600" size={24} />
                                </div>
                                <p className="text-gray-500 font-medium">Reading Document...</p>
                            </div>
                        )}

                        {messages.map((msg, idx) => (
                            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-[90%] md:max-w-[80%] rounded-2xl p-4 md:p-5 shadow-sm ${
                                    msg.role === 'user' 
                                    ? 'bg-cyan-600 text-white rounded-tr-none' 
                                    : 'bg-white border border-gray-200 text-gray-800 rounded-tl-none'
                                }`}>
                                    {msg.role === 'model' ? (
                                        <div className="prose prose-sm max-w-none prose-p:my-1 prose-headings:text-cyan-800 prose-strong:text-cyan-700 prose-ul:list-disc prose-li:ml-4">
                                            {formatText(msg.text)}
                                        </div>
                                    ) : (
                                        <p className="text-sm md:text-base">{msg.text}</p>
                                    )}
                                </div>
                            </div>
                        ))}

                        {isTyping && (
                            <div className="flex justify-start">
                                <div className="bg-white border border-gray-200 px-4 py-3 rounded-2xl rounded-tl-none flex gap-1 items-center shadow-sm">
                                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
                                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce delay-75"></div>
                                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce delay-150"></div>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Input Area */}
                    <div className="p-4 bg-white border-t border-gray-200 sticky bottom-0">
                        <form onSubmit={handleSendMessage} className="flex gap-2 max-w-3xl mx-auto relative">
                            <input 
                                type="text" 
                                value={inputText}
                                onChange={(e) => setInputText(e.target.value)}
                                placeholder="Ask a follow-up question..."
                                className="flex-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-xl focus:ring-cyan-500 focus:border-cyan-500 block w-full p-3 md:p-4 outline-none transition shadow-inner"
                                disabled={isTyping}
                            />
                            <button 
                                type="submit" 
                                disabled={!inputText.trim() || isTyping}
                                className="bg-cyan-600 hover:bg-cyan-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 md:px-6 rounded-xl transition shadow-lg shadow-cyan-200"
                            >
                                <Send size={20} />
                            </button>
                        </form>
                    </div>
                </div>
            ) : (
                // Empty Right Panel Placeholder (Desktop)
                <div className="hidden md:flex flex-1 items-center justify-center bg-gray-50 text-center p-8">
                    <div className="max-w-md">
                        <div className="w-20 h-20 bg-white rounded-3xl shadow-sm flex items-center justify-center mx-auto mb-6">
                            <File size={32} className="text-cyan-200" />
                        </div>
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">Ready to Learn?</h2>
                        <p className="text-gray-500">Upload a document on the left to start your AI-powered study session.</p>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default EcoLearnAI;
