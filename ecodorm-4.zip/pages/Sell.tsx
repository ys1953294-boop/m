
import React, { useState, useEffect } from 'react';
import { Camera, AlertCircle, X, Star, Plus, ArrowLeft, Trash2, Loader2, ShoppingBag, Calendar, Users } from 'lucide-react';
import { CATEGORIES } from '../constants';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { useNavigate, useParams, Link, useSearchParams } from 'react-router-dom';

const Sell: React.FC = () => {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { id } = useParams<{ id: string }>(); // Check for Edit Mode
  const isEditing = !!id;

  const initialType = searchParams.get('type') === 'roommate' ? 'roommate' : 'sell';
  const [listingType, setListingType] = useState(initialType);
  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  
  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(listingType === 'roommate' ? 'Roommates' : CATEGORIES[0]);
  const [condition, setCondition] = useState(listingType === 'roommate' ? 'Available' : 'Good');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [rentalPeriod, setRentalPeriod] = useState(listingType === 'roommate' ? 'month' : 'day');
  
  // Multiple Images State
  const [imageFiles, setImageFiles] = useState<File[]>([]); 
  const [previews, setPreviews] = useState<string[]>([]);
  const [primaryIndex, setPrimaryIndex] = useState(0);

  // Sync state if type param changes
  useEffect(() => {
      const type = searchParams.get('type');
      if (type === 'roommate') {
          setListingType('roommate');
          setCategory('Roommates');
          setRentalPeriod('month');
          setCondition('Available');
      }
  }, [searchParams]);

  // Fetch item details if editing
  useEffect(() => {
    if (isEditing && id && user) {
        setFetchLoading(true);
        const fetchItem = async () => {
            const { data, error } = await supabase
                .from('items')
                .select('*')
                .eq('id', id)
                .single();

            if (data) {
                if (data.seller_id !== user.id) {
                    alert("You don't have permission to edit this item.");
                    navigate('/dashboard');
                    return;
                }
                setTitle(data.title);
                setCategory(data.category);
                setCondition(data.condition);
                setDescription(data.description);
                setPrice(data.price ? data.price.toString() : '');
                setListingType(data.type);
                setRentalPeriod(data.rental_period || 'day');
                if (data.images && Array.isArray(data.images) && data.images.length > 0) {
                    setPreviews(data.images);
                } else if (data.image) {
                     setPreviews([data.image]);
                }
            } else {
                console.error("Fetch error:", error);
                alert("Item not found");
                navigate('/dashboard');
            }
            setFetchLoading(false);
        };
        fetchItem();
    }
  }, [id, isEditing, user, navigate]);

  useEffect(() => {
    return () => {
      previews.forEach(url => {
          if (url.startsWith('blob:')) URL.revokeObjectURL(url);
      });
    };
  }, []); 

  const compressImage = async (file: File): Promise<Blob> => {
    return new Promise((resolve) => {
        if (file.size < 500 * 1024) {
             resolve(file);
             return;
        }
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                const MAX_SIZE = 1024;
                if (width > height) {
                    if (width > MAX_SIZE) {
                        height *= MAX_SIZE / width;
                        width = MAX_SIZE;
                    }
                } else {
                    if (height > MAX_SIZE) {
                        width *= MAX_SIZE / height;
                        height = MAX_SIZE;
                    }
                }
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if(!ctx) { resolve(file); return; }
                ctx.drawImage(img, 0, 0, width, height);
                canvas.toBlob((blob) => {
                    if (blob) resolve(blob);
                    else resolve(file);
                }, 'image/jpeg', 0.8);
            };
            img.onerror = () => resolve(file);
        };
        reader.onerror = () => resolve(file);
    });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles: File[] = Array.from(e.target.files);
      if (previews.length + newFiles.length > 5) {
        alert("You can only have up to 5 photos.");
        return;
      }
      const newPreviews = newFiles.map(file => URL.createObjectURL(file));
      setImageFiles(prev => [...prev, ...newFiles]);
      setPreviews(prev => [...prev, ...newPreviews]);
    }
  };

  const removeImage = (index: number) => {
    const urlToRemove = previews[index];
    if (urlToRemove.startsWith('blob:')) {
        URL.revokeObjectURL(urlToRemove);
        const remoteCount = previews.filter((u, i) => i < index && !u.startsWith('blob:')).length;
        const localIndex = index - remoteCount;
        const newFiles = imageFiles.filter((_, i) => i !== localIndex);
        setImageFiles(newFiles);
    }
    const newPreviews = previews.filter((_, i) => i !== index);
    setPreviews(newPreviews);
    if (index === primaryIndex) {
      setPrimaryIndex(0);
    } else if (index < primaryIndex) {
      setPrimaryIndex(prev => prev - 1);
    }
  };

  const handleDelete = async () => {
    if (!id || !user) return;
    if (!window.confirm("Are you sure you want to permanently delete this listing?")) return;
    setDeleteLoading(true);
    try {
        const { error } = await supabase
            .from('items')
            .delete()
            .eq('id', id)
            .eq('seller_id', user.id);
        if (error) throw error;
        navigate('/dashboard');
    } catch (err: any) {
        alert("Failed to delete item: " + err.message);
        setDeleteLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) { alert('Please log in.'); return; }
    if (previews.length === 0) { alert('Please have at least one image for your listing.'); return; }
    
    setLoading(true);
    try {
      // 1. Ensure user exists in public.users table (Use maybeSingle to prevent catch-block jump)
      const { data: userData, error: userFetchError } = await supabase
        .from('users')
        .select('id')
        .eq('id', user.id)
        .maybeSingle();
      
      if (!userData) {
           await supabase.from('users').insert([{
               id: user.id, 
               email: user.email, 
               name: user.name || 'User',
               campus: user.campus || 'Not specified', 
               avatar: user.avatar, 
               role: 'user'
           }]);
      }

      // 2. Handle Image Uploads
      let finalImageUrls: string[] = [];
      const existingRemoteUrls = previews.filter(url => !url.startsWith('blob:'));
      const newUploadedUrls: string[] = [];
      
      if (imageFiles.length > 0) {
        const uploadPromises = imageFiles.map(async (file) => {
            const compressedBlob = await compressImage(file);
            const fileExt = file.name.split('.').pop() || 'jpg';
            const sanitizedName = Math.random().toString(36).substring(2) + Date.now();
            const fileName = `${sanitizedName}.${fileExt}`;
            const filePath = `${user.id}/${fileName}`;
            const { error: uploadError } = await supabase.storage.from('item-images').upload(filePath, compressedBlob);
            if (uploadError) throw uploadError;
            const { data } = supabase.storage.from('item-images').getPublicUrl(filePath);
            return data.publicUrl;
        });
        const uploaded = await Promise.all(uploadPromises);
        newUploadedUrls.push(...uploaded);
      }
      
      let combinedUrls = [...existingRemoteUrls, ...newUploadedUrls];
      if (combinedUrls.length > 0 && primaryIndex > 0 && primaryIndex < combinedUrls.length) {
          const primary = combinedUrls[primaryIndex];
          const others = combinedUrls.filter((_, i) => i !== primaryIndex);
          combinedUrls = [primary, ...others];
      }

      // 3. Prepare Item Data
      let itemPrice = 0;
      if (listingType !== 'donate') {
         itemPrice = price === '' ? 0 : parseFloat(price);
         if (isNaN(itemPrice)) itemPrice = 0;
      }

      const itemData = {
          title, 
          category: listingType === 'roommate' ? 'Roommates' : category, 
          condition, 
          description, 
          price: itemPrice,
          type: listingType, 
          seller_id: user.id, 
          images: combinedUrls, 
          is_active: true,
          rental_period: (listingType === 'rent' || listingType === 'roommate') ? rentalPeriod : null
      };

      // 4. Save to Database
      if (isEditing) {
          const { error: updateError } = await supabase.from('items').update(itemData).eq('id', id);
          if (updateError) throw updateError;
      } else {
          const { error: insertError } = await supabase.from('items').insert([{ ...itemData, created_at: new Date().toISOString() }]);
          if (insertError) throw insertError;
      }

      navigate('/dashboard');
    } catch (error: any) {
      console.error("Submission error:", error);
      alert(`Error: ${error.message || 'Something went wrong. Please try again.'}`);
    } finally {
      setLoading(false);
    }
  };

  if (fetchLoading) return <div className="min-h-screen flex items-center justify-center"><Loader2 size={40} className="animate-spin text-forest mx-auto mb-4"/></div>;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 bg-white border border-gray-200 rounded-full text-gray-500 hover:bg-gray-50 hover:text-forest transition shadow-sm"><ArrowLeft size={20} /></button>
        <div>
            <h1 className="text-2xl md:text-3xl font-extrabold text-gray-900">{isEditing ? 'Edit Listing' : (listingType === 'roommate' ? 'Find a Roommate' : 'Post a Listing')}</h1>
            <p className="text-sm md:text-base text-gray-600 mt-1">{listingType === 'roommate' ? 'List your flat or room to find perfect flatmates.' : 'Give your items a second life on campus.'}</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">Listing Type</label>
            <div className={`grid gap-4 ${isAdmin ? 'grid-cols-2 md:grid-cols-5' : 'grid-cols-2 md:grid-cols-4'}`}>
               {['sell', 'rent', 'donate', 'roommate'].map(type => (
                 <button
                    key={type} type="button" onClick={() => { setListingType(type); if(type === 'roommate') { setRentalPeriod('month'); setCategory('Roommates'); setCondition('Available'); } }}
                    className={`py-3 px-2 text-center rounded-lg border font-medium capitalize transition text-xs md:text-sm flex flex-col items-center justify-center gap-1 ${
                      listingType === type ? 'border-forest bg-green-50 text-forest ring-1 ring-forest' : 'border-gray-200 text-gray-600 hover:border-gray-300'
                    }`}
                 >
                   {type === 'roommate' && <Users size={16} />}
                   {type}
                 </button>
               ))}
               {isAdmin && (
                   <button type="button" onClick={() => setListingType('store')} className={`py-3 px-2 text-center rounded-lg border font-bold capitalize transition text-xs md:text-sm flex flex-col md:flex-row items-center justify-center gap-1 ${listingType === 'store' ? 'border-indigo-500 bg-indigo-50 text-indigo-700 ring-1 ring-indigo-500' : 'border-indigo-200 text-indigo-600 hover:bg-indigo-50'}`}><ShoppingBag size={16} /> store</button>
               )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">Photos <span className="text-gray-400 font-normal ml-1">(Up to 5)</span></label>
            {previews.length === 0 ? (
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg hover:bg-gray-50 transition cursor-pointer relative bg-white group">
                    <input type="file" accept="image/*" multiple onChange={handleImageChange} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                    <div className="space-y-1 text-center">
                        <Camera className="mx-auto h-12 w-12 text-gray-400 group-hover:text-forest transition" />
                        <div className="flex text-sm text-gray-600 justify-center"><span className="font-medium text-forest">Click to upload images</span></div>
                        <p className="text-xs text-gray-500">PNG, JPG up to 5MB</p>
                    </div>
                </div>
            ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
                    {previews.map((url, index) => (
                        <div key={index} className={`relative aspect-square rounded-lg overflow-hidden border-2 bg-gray-100 ${index === primaryIndex ? 'border-forest ring-2 ring-forest/20' : 'border-gray-200'}`}>
                            <img src={url} alt={`Preview ${index}`} className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/0 hover:bg-black/10 transition-colors">
                                <button type="button" onClick={() => removeImage(index)} className="absolute top-1 right-1 bg-white/90 p-1 rounded-full text-gray-500 hover:text-red-500 hover:bg-white shadow-sm transition z-10"><X size={14} /></button>
                                <button type="button" onClick={() => setPrimaryIndex(index)} className={`absolute bottom-2 left-2 right-2 py-1 px-2 rounded-md text-[10px] font-bold uppercase tracking-wider shadow-sm flex items-center justify-center gap-1 transition ${index === primaryIndex ? 'bg-forest text-white' : 'bg-white/90 text-gray-600 hover:bg-white'}`}>{index === primaryIndex ? <><Star size={10} fill="currentColor" /> Cover</> : 'Set Cover'}</button>
                            </div>
                        </div>
                    ))}
                    {previews.length < 5 && (
                         <div className="relative aspect-square rounded-lg border-2 border-dashed border-gray-300 hover:border-forest hover:bg-green-50 transition flex flex-col items-center justify-center cursor-pointer bg-white group">
                            <input type="file" accept="image/*" multiple onChange={handleImageChange} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                            <Plus className="text-gray-400 group-hover:text-forest transition" size={24} /><span className="text-xs text-gray-500 mt-1 font-medium">Add Photo</span>
                        </div>
                    )}
                </div>
            )}
          </div>

          <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
            <div className="sm:col-span-6">
              <label htmlFor="title" className="block text-sm font-medium text-gray-700">{listingType === 'roommate' ? 'Flat/Room Title' : 'Item Title'}</label>
              <div className="mt-1"><input required type="text" value={title} onChange={(e) => setTitle(e.target.value)} id="title" className="bg-white text-gray-900 shadow-sm focus:ring-forest focus:border-forest block w-full sm:text-sm border-gray-300 rounded-md p-2 border" placeholder={listingType === 'roommate' ? "e.g. Spacious 2BHK flat near Galgotias" : "e.g. Intro to Psychology Textbook"} /></div>
            </div>

            {listingType !== 'roommate' && (
              <div className="sm:col-span-3">
                <label htmlFor="category" className="block text-sm font-medium text-gray-700">Category</label>
                <div className="mt-1">
                  <select value={category} onChange={(e) => setCategory(e.target.value as any)} id="category" className="bg-white text-gray-900 shadow-sm focus:ring-forest focus:border-forest block w-full sm:text-sm border-gray-300 rounded-md p-2 border">
                    {CATEGORIES.filter(c => c !== 'Roommates').map(cat => <option key={cat} value={cat}>{cat}</option>)}
                  </select>
                </div>
              </div>
            )}

            <div className="sm:col-span-3">
              <label htmlFor="condition" className="block text-sm font-medium text-gray-700">{listingType === 'roommate' ? 'Occupancy Status' : 'Condition'}</label>
              <div className="mt-1">
                <select value={condition} onChange={(e) => setCondition(e.target.value)} id="condition" className="bg-white text-gray-900 shadow-sm focus:ring-forest focus:border-forest block w-full sm:text-sm border-gray-300 rounded-md p-2 border">
                  {listingType === 'roommate' ? (
                      <>
                        <option value="Available">Available Now</option>
                        <option value="Filling Fast">Filling Fast</option>
                        <option value="Reserved">Reserved</option>
                      </>
                  ) : (
                      <>
                        <option>New</option>
                        <option>Like New</option>
                        <option>Good</option>
                        <option>Fair</option>
                      </>
                  )}
                </select>
              </div>
            </div>

            <div className="sm:col-span-6">
              <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
              <div className="mt-1"><textarea required value={description} onChange={(e) => setDescription(e.target.value)} id="description" rows={3} className="bg-white text-gray-900 shadow-sm focus:ring-forest focus:border-forest block w-full sm:text-sm border-gray-300 rounded-md p-2 border" placeholder={listingType === 'roommate' ? "Describe the room, flat, amenities and preferences..." : "Describe the item condition, specs, etc."}></textarea></div>
            </div>

            {listingType !== 'donate' && (
                <>
                  <div className="sm:col-span-3">
                    <label htmlFor="price" className="block text-sm font-medium text-gray-700">{listingType === 'roommate' ? 'Rent Amount (₹)' : 'Price (₹)'}</label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><span className="text-gray-500 sm:text-sm">₹</span></div>
                        <input required type="number" value={price} onChange={(e) => setPrice(e.target.value)} id="price" className="bg-white text-gray-900 focus:ring-forest focus:border-forest block w-full pl-7 pr-12 sm:text-sm border-gray-300 rounded-md p-2 border" placeholder="0.00" />
                    </div>
                  </div>
                  {(listingType === 'rent' || listingType === 'roommate') && (
                      <div className="sm:col-span-3">
                        <label htmlFor="rentalPeriod" className="block text-sm font-medium text-gray-700">Frequency</label>
                        <div className="mt-1 relative rounded-md shadow-sm">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Calendar size={16} className="text-gray-400" /></div>
                            <select id="rentalPeriod" value={rentalPeriod} onChange={(e) => setRentalPeriod(e.target.value)} className="bg-white text-gray-900 focus:ring-forest focus:border-forest block w-full pl-10 sm:text-sm border-gray-300 rounded-md p-2 border">
                                <option value="day">Per Day</option>
                                <option value="month">Per Month</option>
                            </select>
                        </div>
                      </div>
                  )}
                </>
            )}
          </div>

          <div className="pt-5 border-t border-gray-200 flex justify-end gap-3">
            {isEditing && (
                <button type="button" onClick={handleDelete} disabled={deleteLoading} className="py-2 px-4 border border-red-200 shadow-sm text-sm font-medium rounded-md text-red-600 bg-red-50 hover:bg-red-100 mr-auto flex items-center">{deleteLoading ? <Loader2 size={16} className="animate-spin mr-2"/> : <Trash2 size={16} className="mr-2"/>} Delete</button>
            )}
            <button type="button" onClick={() => navigate('/dashboard')} className="py-2 px-4 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">Cancel</button>
            <button disabled={loading} type="submit" className={`inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white ${loading ? 'bg-gray-400 cursor-not-allowed' : 'bg-forest hover:bg-green-700'}`}>{loading ? <><Loader2 size={16} className="animate-spin mr-2"/> Processing...</> : (isEditing ? 'Save Changes' : 'Publish Listing')}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Sell;
