
import React, { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, Sparkles, BookOpen, Lightbulb, GraduationCap, 
  Video, ExternalLink, Download, Code, FileText, ChevronRight, 
  Calendar, Book, X, Clock, Layers, Calculator, FlaskConical, 
  Cpu, PenTool, Search, ChevronDown, Filter, Leaf, BrainCircuit,
  Upload, Send, Loader2, List, HelpCircle, FileCheck, MessageSquare, Trash2
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Item } from '../types';
import { BTECH_1ST_YEAR_SUBJECTS, PYQ_YEARS } from '../constants';
import { GoogleGenAI, Chat } from "@google/genai";

// --- TYPES ---
type CourseType = 'B.Tech' | 'BCA' | null;
type YearType = '1st Year' | '2nd Year' | '3rd Year' | '4th Year';
type ResourceType = 'Notes' | 'PYQ' | null;
type TabMode = 'library' | 'ai';

interface Message {
  role: 'user' | 'model';
  text: string;
}

const EcoLearn: React.FC = () => {
  // --- EXISTING ECOLEARN STATE ---
  const [learnItems, setLearnItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedResourceType, setSelectedResourceType] = useState<ResourceType>(null);
  const [selectedCourse, setSelectedCourse] = useState<CourseType>(null);
  const [selectedYear, setSelectedYear] = useState<YearType>('1st Year');
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [localSearch, setLocalSearch] = useState('');
  const [showYearDropdown, setShowYearDropdown] = useState(false);
  const [showSubjectDropdown, setShowSubjectDropdown] = useState(false);
  const [viewingResource, setViewingResource] = useState<Item | null>(null);

  // --- NEW AI STATE ---
  const [activeTab, setActiveTab] = useState<TabMode>('library');
  const [file, setFile] = useState<File | null>(null);
  const [pdfBase64, setPdfBase64] = useState<string | null>(null);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chatSession, setChatSession] = useState<Chat | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // --- INITIAL DATA FETCH ---
  useEffect(() => {
    fetchLearnItems();
  }, []);

  const fetchLearnItems = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('items')
        .select('*, seller:users(*)')
        .eq('type', 'learn')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (data) {
        const mapped: Item[] = data.map((d: any) => ({
            id: d.id,
            title: d.title,
            description: d.description,
            price: d.price,
            image: d.images?.[0] || 'https://via.placeholder.com/400',
            images: d.images,
            category: d.category,
            condition: d.condition,
            type: d.type,
            seller: {
              id: d.seller?.id,
              name: d.seller?.name || 'Unknown',
              campus: d.seller?.campus,
              verified: d.seller?.verified,
              avatar: d.seller?.avatar,
              sustainabilityScore: d.seller?.sustainability_score
            },
            postedAt: d.created_at,
            isActive: d.is_active,
            externalLink: d.external_link,
            year: d.year,
            subject: d.subject
        }));
        setLearnItems(mapped);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // --- AI LOGIC ---
  useEffect(() => {
    if (chatContainerRef.current) {
        chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isTyping, activeTab]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      if (selectedFile.type !== 'application/pdf') {
        alert('Please upload a PDF file.');
        return;
      }
      setFile(selectedFile);
      setIsProcessingFile(true);
      
      try {
        const base64 = await fileToBase64(selectedFile);
        const cleanBase64 = base64.split(',')[1];
        setPdfBase64(cleanBase64);
        
        await initializeChat(cleanBase64);
        
        setMessages([{
            role: 'model',
            text: `I've analyzed **${selectedFile.name}**. I'm ready to help you study!`
        }]);
      } catch (err) {
        console.error("File processing error:", err);
        alert("Failed to process PDF.");
        setFile(null);
      } finally {
        setIsProcessingFile(false);
      }
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const clearFile = () => {
      setFile(null);
      setPdfBase64(null);
      setMessages([]);
      setChatSession(null);
  };

  const initializeChat = async (base64Data: string) => {
      try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          const chat = ai.chats.create({
              model: 'gemini-2.0-flash-exp',
              config: {
                  systemInstruction: "You are a helpful academic tutor. You answer questions based on the provided PDF document. Keep answers concise and student-friendly. Use markdown for formatting."
              }
          });
          setChatSession(chat);
      } catch (err) {
          console.error("AI Init Error:", err);
      }
  };

  const generateResponse = async (prompt: string, displayPrompt?: string) => {
      if (!chatSession || !pdfBase64) return;

      setMessages(prev => [...prev, { role: 'user', text: displayPrompt || prompt }]);
      setIsTyping(true);
      setInputText('');

      try {
          const result = await chatSession.sendMessage({
              message: {
                  role: 'user',
                  parts: [
                      { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
                      { text: prompt }
                  ]
              }
          });

          const responseText = result.text;
          if (responseText) {
              setMessages(prev => [...prev, { role: 'model', text: responseText }]);
          } else {
              setMessages(prev => [...prev, { role: 'model', text: "I couldn't generate a response." }]);
          }
      } catch (err) {
          console.error("Generation Error:", err);
          setMessages(prev => [...prev, { role: 'model', text: "Sorry, I encountered an error." }]);
      } finally {
          setIsTyping(false);
      }
  };

  const handleSendMessage = (e: React.FormEvent) => {
      e.preventDefault();
      if (!inputText.trim() || !chatSession) return;
      
      setMessages(prev => [...prev, { role: 'user', text: inputText }]);
      setIsTyping(true);
      const text = inputText;
      setInputText('');

      chatSession.sendMessage({
          message: text
      }).then(result => {
          const responseText = result.text;
          if (responseText) {
              setMessages(prev => [...prev, { role: 'model', text: responseText }]);
          }
          setIsTyping(false);
      }).catch(err => {
          console.error("Chat Error:", err);
          setMessages(prev => [...prev, { role: 'model', text: "Error sending message." }]);
          setIsTyping(false);
      });
  };

  const formatText = (text: string) => {
      return text.split('\n').map((line, i) => {
          const bolded = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
          const isBullet = line.trim().startsWith('* ') || line.trim().startsWith('- ');
          return (
              <p 
                key={i} 
                className={`mb-1 ${isBullet ? 'pl-4 relative' : ''} text-sm leading-relaxed text-gray-700`}
                dangerouslySetInnerHTML={{ __html: isBullet ? `• ${bolded.substring(2)}` : bolded }}
              />
          );
      });
  };

  // --- LIBRARY FILTER LOGIC ---
  const shouldShowList = selectedResourceType && selectedCourse;
  
  const filteredResources = learnItems.filter(item => {
      if (selectedResourceType) {
          if (shouldShowList) {
               const targetCategory = `${selectedCourse} ${selectedResourceType}`;
               if (item.category !== targetCategory) return false;
               if (item.year !== selectedYear) return false;
               if (selectedSubject !== 'All' && item.subject !== selectedSubject) return false;
               if (localSearch) {
                   const query = localSearch.toLowerCase();
                   return item.title.toLowerCase().includes(query) || item.description.toLowerCase().includes(query);
               }
               return true;
          }
          return false;
      }
      const academicCategories = ['B.Tech Notes', 'B.Tech PYQ', 'BCA Notes', 'BCA PYQ'];
      return !academicCategories.includes(item.category);
  });

  let availableSubjects: string[] = [];
  if (selectedCourse === 'B.Tech' && selectedYear === '1st Year') {
      availableSubjects = BTECH_1ST_YEAR_SUBJECTS;
  } else if (selectedCourse && selectedYear) {
      availableSubjects = Array.from(new Set<string>(
          learnItems
          .filter(i => (i.category as string).includes(selectedCourse) && i.year === selectedYear && i.subject)
          .map(i => i.subject as string)
      )).sort();
  }

  const getSubjectIcon = (subjectName: string) => {
      const lower = subjectName.toLowerCase();
      if (lower.includes('math')) return Calculator;
      if (lower.includes('physics')) return Book; 
      if (lower.includes('chemistry')) return FlaskConical;
      if (lower.includes('code') || lower.includes('program')) return Code;
      if (lower.includes('electronic')) return Cpu;
      return BookOpen;
  };

  const resetSelection = () => {
      setSelectedResourceType(null);
      setSelectedCourse(null);
      setSelectedYear('1st Year');
      setSelectedSubject('All');
      setLocalSearch('');
  };

  const handleBack = () => {
      if (selectedCourse) {
          setSelectedCourse(null);
          setSelectedYear('1st Year');
          setSelectedSubject('All');
          setLocalSearch('');
      } else {
          setSelectedResourceType(null);
      }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
       {/* HERO HEADER */}
       <div className="relative bg-gradient-to-b from-cyan-900 to-sky-900 pt-10 pb-20 md:pb-24 px-4 overflow-hidden rounded-b-[40px] shadow-lg z-10">
         <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] pointer-events-none"></div>
         
         <div className="absolute top-4 left-4 z-20">
             <Link to="/" className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition flex items-center justify-center backdrop-blur-sm">
                 <ArrowLeft size={20} />
             </Link>
         </div>

         <div className="max-w-4xl mx-auto text-center relative z-10">
            <h1 className="text-4xl md:text-5xl font-black tracking-tight text-white mb-3">
                <span className="text-cyan-300">Eco</span>Learn
            </h1>
            <p className="text-cyan-100 text-sm md:text-base max-w-lg mx-auto mb-8 font-light">
               Your academic hub for Notes, PYQs, and AI-powered study assistance.
            </p>

            {/* TAB SWITCHER */}
            <div className="inline-flex bg-white/10 backdrop-blur-md p-1 rounded-full border border-white/20 shadow-xl">
                <button 
                    onClick={() => setActiveTab('library')}
                    className={`flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-bold transition-all duration-300 ${
                        activeTab === 'library' 
                        ? 'bg-white text-cyan-900 shadow-md transform scale-105' 
                        : 'text-cyan-100 hover:text-white hover:bg-white/5'
                    }`}
                >
                    <BookOpen size={16} /> Library
                </button>
                <button 
                    onClick={() => setActiveTab('ai')}
                    className={`flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-bold transition-all duration-300 ${
                        activeTab === 'ai' 
                        ? 'bg-gradient-to-r from-purple-500 to-indigo-500 text-white shadow-md shadow-purple-500/30 transform scale-105' 
                        : 'text-cyan-100 hover:text-white hover:bg-white/5'
                    }`}
                >
                    <BrainCircuit size={16} /> AI Tutor
                </button>
            </div>
         </div>
       </div>

       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 mb-12 relative z-20 w-full flex-grow">
           
           {/* === TAB 1: LIBRARY VIEW === */}
           {activeTab === 'library' && (
               <div className="animate-fade-in-up">
                   {/* ACADEMIC WIZARD CARD */}
                   <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-6 md:p-8 min-h-[400px] relative overflow-hidden">
                        
                        {!shouldShowList && <div className="absolute -top-20 -right-20 w-64 h-64 bg-cyan-50 rounded-full blur-3xl opacity-50 pointer-events-none"></div>}

                        {/* Breadcrumbs */}
                        {selectedResourceType && !shouldShowList && (
                             <div className="flex items-center gap-2 mb-6 text-sm">
                                 <button onClick={resetSelection} className="text-gray-400 hover:text-cyan-600 transition">Academics</button>
                                 <ChevronRight size={14} className="text-gray-300" />
                                 <span className="font-bold text-cyan-700">{selectedResourceType === 'PYQ' ? 'PYQs' : 'Notes'}</span>
                             </div>
                        )}

                        {/* STEP 1: SELECT RESOURCE */}
                        {!selectedResourceType && (
                            <div>
                                <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">Select Resource Type</h3>
                                <div className="grid grid-cols-2 gap-4 max-w-2xl mx-auto">
                                    <button onClick={() => setSelectedResourceType('PYQ')} className="group p-6 rounded-2xl border-2 border-gray-50 bg-gray-50 hover:bg-white hover:border-orange-200 hover:shadow-xl transition-all duration-300 text-left">
                                        <div className="h-12 w-12 bg-orange-100 text-orange-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                                            <Clock size={24} />
                                        </div>
                                        <h4 className="text-lg font-bold text-gray-900">PYQ</h4>
                                        <p className="text-xs text-gray-500 mt-1">Previous Year Questions</p>
                                    </button>
                                    <button onClick={() => setSelectedResourceType('Notes')} className="group p-6 rounded-2xl border-2 border-gray-50 bg-gray-50 hover:bg-white hover:border-emerald-200 hover:shadow-xl transition-all duration-300 text-left">
                                        <div className="h-12 w-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                                            <BookOpen size={24} />
                                        </div>
                                        <h4 className="text-lg font-bold text-gray-900">Notes</h4>
                                        <p className="text-xs text-gray-500 mt-1">Lecture Notes & Slides</p>
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* STEP 2: SELECT COURSE */}
                        {selectedResourceType && !selectedCourse && (
                            <div className="animate-fade-in-up">
                                <div className="text-center mb-6">
                                    <h3 className="text-xl font-bold text-gray-900">Select Course</h3>
                                </div>
                                <div className="grid grid-cols-2 gap-4 max-w-2xl mx-auto">
                                    <button onClick={() => setSelectedCourse('B.Tech')} className="group p-6 rounded-2xl border-2 border-gray-50 bg-gray-50 hover:bg-white hover:border-blue-200 hover:shadow-xl transition-all duration-300 text-left">
                                        <div className="h-12 w-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                                            <Cpu size={24} />
                                        </div>
                                        <h4 className="text-lg font-bold text-gray-900">B.Tech</h4>
                                        <p className="text-xs text-gray-500 mt-1">Bachelor of Technology</p>
                                    </button>
                                    <button onClick={() => setSelectedCourse('BCA')} className="group p-6 rounded-2xl border-2 border-gray-50 bg-gray-50 hover:bg-white hover:border-purple-200 hover:shadow-xl transition-all duration-300 text-left">
                                        <div className="h-12 w-12 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                                            <Code size={24} />
                                        </div>
                                        <h4 className="text-lg font-bold text-gray-900">BCA</h4>
                                        <p className="text-xs text-gray-500 mt-1">Computer Applications</p>
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* STEP 3: RESULTS & FILTERS */}
                        {shouldShowList && (
                            <div className="animate-fade-in-up">
                                <div className="flex items-center gap-2 mb-6">
                                    <button onClick={handleBack} className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition"><ArrowLeft size={20}/></button>
                                    <h3 className="text-xl font-bold text-gray-900">{selectedCourse} {selectedResourceType === 'PYQ' ? 'PYQs' : 'Notes'}</h3>
                                </div>

                                {/* Filters */}
                                <div className="flex flex-col md:flex-row gap-3 mb-6 bg-gray-50 p-3 rounded-2xl border border-gray-100">
                                     <div className="relative">
                                         <button 
                                            onClick={() => setShowYearDropdown(!showYearDropdown)}
                                            className="w-full md:w-40 bg-white border border-gray-200 text-gray-700 px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm flex justify-between items-center"
                                         >
                                             {selectedYear} <ChevronDown size={14} className="text-gray-400" />
                                         </button>
                                         {showYearDropdown && (
                                             <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 z-50 overflow-hidden">
                                                 {['1st Year', '2nd Year', '3rd Year', '4th Year'].map(y => (
                                                     <button key={y} onClick={() => { setSelectedYear(y as YearType); setShowYearDropdown(false); setSelectedSubject('All'); }} className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50">{y}</button>
                                                 ))}
                                             </div>
                                         )}
                                     </div>
                                     <div className="relative flex-1">
                                         <input type="text" value={localSearch} onChange={e => setLocalSearch(e.target.value)} placeholder="Search subjects..." className="w-full pl-4 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm outline-none focus:border-cyan-500 transition" />
                                         <Search size={16} className="absolute right-3 top-3 text-gray-400 pointer-events-none" />
                                     </div>
                                </div>

                                {/* List */}
                                {loading ? (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        {[1,2,3,4].map(i => <div key={i} className="h-24 bg-gray-100 rounded-xl animate-pulse"></div>)}
                                    </div>
                                ) : filteredResources.length > 0 ? (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        {filteredResources.map(item => (
                                            <div key={item.id} onClick={() => setViewingResource(item)} className="bg-white border border-gray-100 hover:border-cyan-200 p-4 rounded-xl shadow-sm hover:shadow-md transition cursor-pointer flex items-center gap-4 group">
                                                <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${selectedResourceType === 'PYQ' ? 'bg-orange-50 text-orange-600' : 'bg-emerald-50 text-emerald-600'}`}>
                                                    {item.subject ? React.createElement(getSubjectIcon(item.subject), { size: 20 }) : <FileText size={20} />}
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <h4 className="font-bold text-gray-900 truncate group-hover:text-cyan-700 transition">{item.title}</h4>
                                                    <p className="text-xs text-gray-500">{item.subject || 'General'}</p>
                                                </div>
                                                <ChevronRight size={16} className="text-gray-300 group-hover:text-cyan-500" />
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="text-center py-12 text-gray-400">No resources found matching filters.</div>
                                )}
                            </div>
                        )}
                   </div>
               </div>
           )}

           {/* === TAB 2: AI TUTOR VIEW === */}
           {activeTab === 'ai' && (
               <div className="animate-fade-in-up">
                   <div className="bg-white rounded-3xl shadow-2xl border border-white/20 overflow-hidden flex flex-col md:flex-row min-h-[500px] max-h-[700px]">
                       
                       {/* LEFT: CONTROL PANEL */}
                       <div className={`w-full md:w-80 bg-gray-50 border-r border-gray-100 p-5 flex flex-col ${file ? 'hidden md:flex' : 'flex'}`}>
                           
                           {/* Upload Box */}
                           {!file ? (
                               <div className="flex-1 flex flex-col items-center justify-center text-center border-2 border-dashed border-gray-200 rounded-2xl hover:border-cyan-400 hover:bg-cyan-50/30 transition-all cursor-pointer relative group p-6">
                                   <input type="file" accept="application/pdf" onChange={handleFileUpload} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"/>
                                   <div className="bg-white p-3 rounded-full shadow-sm mb-3 group-hover:scale-110 transition">
                                       <Upload size={24} className="text-cyan-600" />
                                   </div>
                                   <h3 className="font-bold text-gray-900 mb-1">Upload PDF</h3>
                                   <p className="text-xs text-gray-500">Analyze notes instantly</p>
                               </div>
                           ) : (
                               <div className="space-y-4">
                                   <div className="bg-white p-3 rounded-xl border border-gray-100 shadow-sm flex items-center justify-between">
                                       <div className="flex items-center gap-3 overflow-hidden">
                                           <div className="bg-red-50 p-2 rounded-lg text-red-500"><FileText size={18}/></div>
                                           <div className="truncate">
                                               <p className="text-sm font-bold text-gray-900 truncate max-w-[120px]">{file.name}</p>
                                               <p className="text-[10px] text-gray-400">{(file.size/1024/1024).toFixed(2)} MB</p>
                                           </div>
                                       </div>
                                       <button onClick={clearFile} className="text-gray-400 hover:text-red-500 p-1"><Trash2 size={16}/></button>
                                   </div>

                                   <div className="space-y-2">
                                       <p className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Quick Tools</p>
                                       <button onClick={() => generateResponse("Summarize this document in simple terms.", "Summarize")} disabled={isTyping} className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-gray-100 hover:border-cyan-200 hover:bg-cyan-50 rounded-xl transition text-sm font-medium text-gray-700 text-left">
                                           <FileCheck size={16} className="text-cyan-600"/> Summarize
                                       </button>
                                       <button onClick={() => generateResponse("List 5 potential exam questions from this text.", "Generate Questions")} disabled={isTyping} className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-gray-100 hover:border-orange-200 hover:bg-orange-50 rounded-xl transition text-sm font-medium text-gray-700 text-left">
                                           <HelpCircle size={16} className="text-orange-600"/> Exam Questions
                                       </button>
                                       <button onClick={() => generateResponse("Create a structured bullet-point outline (Mind Map) of the key concepts.", "Create Mind Map")} disabled={isTyping} className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-gray-100 hover:border-purple-200 hover:bg-purple-50 rounded-xl transition text-sm font-medium text-gray-700 text-left">
                                           <BrainCircuit size={16} className="text-purple-600"/> Mind Map
                                       </button>
                                       <button onClick={() => generateResponse("Create concise cheat-sheet notes for quick revision.", "Short Notes")} disabled={isTyping} className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-gray-100 hover:border-emerald-200 hover:bg-emerald-50 rounded-xl transition text-sm font-medium text-gray-700 text-left">
                                           <List size={16} className="text-emerald-600"/> Cheat Sheet
                                       </button>
                                   </div>
                               </div>
                           )}
                       </div>

                       {/* RIGHT: CHAT INTERFACE */}
                       {file ? (
                           <div className="flex-1 flex flex-col bg-white relative">
                               <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-5 space-y-4 bg-white/50">
                                   {messages.map((msg, i) => (
                                       <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                           <div className={`max-w-[85%] rounded-2xl p-4 text-sm ${
                                               msg.role === 'user' 
                                               ? 'bg-gray-900 text-white rounded-tr-sm' 
                                               : 'bg-gray-100 text-gray-800 rounded-tl-sm'
                                           }`}>
                                               {msg.role === 'model' ? (
                                                   <div className="prose prose-sm max-w-none">{formatText(msg.text)}</div>
                                               ) : (
                                                   msg.text
                                               )}
                                           </div>
                                       </div>
                                   ))}
                                   {isTyping && (
                                       <div className="flex items-center gap-1 ml-2">
                                           <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce"></div>
                                           <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce delay-100"></div>
                                           <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce delay-200"></div>
                                       </div>
                                   )}
                               </div>
                               
                               <div className="p-4 border-t border-gray-100">
                                   <form onSubmit={handleSendMessage} className="flex gap-2">
                                       <input 
                                           type="text" 
                                           value={inputText}
                                           onChange={e => setInputText(e.target.value)}
                                           placeholder="Ask anything about the document..."
                                           className="flex-1 bg-gray-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-cyan-100 outline-none"
                                           disabled={isTyping}
                                       />
                                       <button type="submit" disabled={!inputText.trim() || isTyping} className="bg-gray-900 text-white p-3 rounded-xl hover:bg-black transition disabled:opacity-50">
                                           <Send size={18} />
                                       </button>
                                   </form>
                               </div>
                           </div>
                       ) : (
                           <div className="flex-1 flex flex-col items-center justify-center p-8 bg-white text-center">
                               <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-cyan-100 rounded-full flex items-center justify-center mb-6 animate-pulse">
                                   <Sparkles className="text-cyan-600 w-8 h-8" />
                               </div>
                               <h2 className="text-2xl font-bold text-gray-900 mb-2">AI Study Companion</h2>
                               <p className="text-gray-500 max-w-xs mx-auto">Upload a document on the left to start summarizing, asking questions, and creating study guides.</p>
                           </div>
                       )}
                   </div>
               </div>
           )}
       </div>

       {/* RESOURCE DETAIL MODAL */}
       {viewingResource && (
           <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
               <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[80vh]">
                   <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 sticky top-0 z-10">
                       <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                           <BookOpen size={20} className="text-cyan-600"/> Resource Details
                       </h2>
                       <button onClick={() => setViewingResource(null)} className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-200 transition">
                           <X size={24} />
                       </button>
                   </div>
                   <div className="p-6 overflow-y-auto">
                       <div className="flex flex-col gap-6">
                           <div className="w-full aspect-[2/1] rounded-2xl bg-gradient-to-br from-cyan-600 to-blue-700 flex flex-col items-center justify-center text-white p-6 text-center shadow-inner relative overflow-hidden">
                               <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
                               <h3 className="text-2xl font-black tracking-tight relative z-10">{viewingResource.subject || viewingResource.title}</h3>
                               <div className="mt-3 flex items-center gap-2 relative z-10">
                                   <span className="bg-white/20 backdrop-blur-md px-3 py-1 rounded-lg text-sm font-bold text-cyan-50">{viewingResource.year}</span>
                                   <span className="bg-white/20 backdrop-blur-md px-3 py-1 rounded-lg text-sm font-bold text-cyan-50">{viewingResource.category}</span>
                               </div>
                           </div>
                           <div className="flex-1 text-center">
                               <h1 className="text-xl font-bold text-gray-900 mb-1">{viewingResource.title}</h1>
                               <p className="text-sm text-gray-500 mb-6">{new Date(viewingResource.postedAt).toLocaleDateString()}</p>
                               <div className="flex flex-col gap-3">
                                   {viewingResource.externalLink ? (
                                       <a href={viewingResource.externalLink} target="_blank" rel="noopener noreferrer" className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3.5 px-6 rounded-xl shadow-lg shadow-cyan-200 transition flex items-center justify-center gap-2 text-lg transform hover:-translate-y-0.5">
                                           <Download size={20} /> Access Resource
                                       </a>
                                   ) : (
                                       <Link to={`/item/${viewingResource.id}?type=learn`} className="w-full bg-gray-900 hover:bg-gray-800 text-white font-bold py-3.5 px-6 rounded-xl shadow-lg transition flex items-center justify-center gap-2 text-lg">
                                           View Full Details <ChevronRight size={20} />
                                       </Link>
                                   )}
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       )}
    </div>
  );
};

export default EcoLearn;
