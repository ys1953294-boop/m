
import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Item } from '../types';
import ItemCard from '../components/ItemCard';
import { Share2, Heart, Flag, Shield, User as UserIcon, CheckCircle, Edit, Trash2, Loader2, ArrowLeft, ShoppingBag, Send, ExternalLink, Crown, Zap, Truck, Bike, Package, MapPin, MessageCircle, X, ShoppingCart, Check, Users } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useStore } from '../contexts/StoreContext';

const ItemDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { addToCart, toggleWishlist, isInWishlist, isInCart } = useStore();
  const navigate = useNavigate();
  const [item, setItem] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);
  const [relatedItems, setRelatedItems] = useState<Item[]>([]);
  const [error, setError] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  
  // Store Order Modal State
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [orderName, setOrderName] = useState('');
  const [orderRoom, setOrderRoom] = useState('');
  const [orderHostel, setOrderHostel] = useState('');
  const [orderPhone, setOrderPhone] = useState('');
  const [orderLoading, setOrderLoading] = useState(false);

  // Add to Cart Button Animation State
  const [isAdded, setIsAdded] = useState(false);

  useEffect(() => {
    const fetchItem = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('items')
          .select(`
            *,
            seller:users(*)
          `)
          .eq('id', id)
          .single();

        if (error) throw error;

        if (data) {
          const mappedItem: Item = {
            id: data.id,
            title: data.title,
            description: data.description,
            price: data.price,
            originalPrice: data.original_price,
            image: data.images ? data.images[0] : 'https://via.placeholder.com/400',
            images: data.images,
            category: data.category,
            condition: data.condition,
            type: data.type,
            rentalPeriod: data.rental_period,
            externalLink: data.external_link,
            deliveryDuration: data.delivery_duration, 
            seller: {
              id: data.seller?.id || 'unknown',
              name: data.seller?.name || 'Unknown Seller',
              campus: data.seller?.campus || 'Unknown Campus',
              verified: data.seller?.verified || false,
              avatar: data.seller?.avatar || '',
              sustainabilityScore: data.seller?.sustainability_score || 0,
            },
            postedAt: data.created_at,
          };
          setItem(mappedItem);
          fetchRelated(mappedItem.category, mappedItem.id);
          
          try {
              const currentInterests = JSON.parse(localStorage.getItem('eco_user_interests') || '[]');
              const newInterests = [mappedItem.category, ...currentInterests.filter((c: string) => c !== mappedItem.category)].slice(0, 5);
              localStorage.setItem('eco_user_interests', JSON.stringify(newInterests));
          } catch (e) {
              console.error("Failed to save interest", e);
          }
          
          if (user) {
              setOrderName(user.name || '');
          }
        }
      } catch (err) {
        console.error(err);
        setError('Item not found or error loading data.');
      } finally {
        setLoading(false);
      }
    };

    fetchItem();
  }, [id, user]);

  const fetchRelated = async (category: string, currentId: string) => {
    const { data } = await supabase
      .from('items')
      .select('*, seller:users(*)')
      .eq('category', category)
      .neq('id', currentId)
      .limit(4);

    if (data) {
      const mapped = data.map((d: any) => ({
        id: d.id,
        title: d.title,
        description: d.description,
        price: d.price,
        image: d.images?.[0] || 'https://via.placeholder.com/400',
        category: d.category,
        condition: d.condition,
        type: d.type,
        rentalPeriod: d.rental_period,
        deliveryDuration: d.delivery_duration,
        seller: {
          id: d.seller?.id,
          name: d.seller?.name,
          campus: d.seller?.campus,
          verified: d.seller?.verified,
          avatar: d.seller?.avatar,
          sustainabilityScore: d.seller?.sustainability_score
        },
        postedAt: d.created_at
      }));
      setRelatedItems(mapped);
    }
  };

  const handleContactSeller = () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!item) return;

    if (user.id === item.seller.id) return;

    navigate('/messages', { 
      state: { 
        initiateChat: {
          sellerId: item.seller.id,
          itemId: item.id,
          sellerName: item.seller.name,
          sellerAvatar: item.seller.avatar,
          itemTitle: item.title
        }
      } 
    });
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!user || !item) return;
      
      setOrderLoading(true);
      try {
          const messageText = `🛍️ NEW STORE ORDER REQUEST
          
Item: ${item.title}
Price: ₹${item.price}

DETAILS:
Name: ${orderName}
Hostel/Block: ${orderHostel}
Room No: ${orderRoom}
Phone: ${orderPhone}

Please confirm availability and delivery time.`;

          const { error } = await supabase.from('messages').insert([{
              sender_id: user.id,
              receiver_id: item.seller.id,
              item_id: item.id,
              message: messageText,
              is_read: false
          }]);

          if (error) throw error;

          alert("Order request sent successfully! The store manager has received your order.");
          setShowOrderModal(false);
          
      } catch (err: any) {
          alert("Failed to place order: " + err.message);
      } finally {
          setOrderLoading(false);
      }
  };

  const handleDelete = async () => {
    if (!item || !user) return;
    if (!window.confirm("Are you sure you want to permanently delete this listing? This action cannot be undone.")) return;

    setIsDeleting(true);
    try {
        const { error } = await supabase
            .from('items')
            .delete()
            .eq('id', item.id)
            .eq('seller_id', user.id);

        if (error) throw error;

        if (item.images && item.images.length > 0) {
            const paths = item.images.map(url => {
                 try {
                     const parts = url.split('/item-images/');
                     return parts.length > 1 ? decodeURIComponent(parts[1]) : null;
                 } catch { return null; }
            }).filter(p => p) as string[];
            if (paths.length > 0) {
                supabase.storage.from('item-images').remove(paths);
            }
        }

        navigate('/dashboard'); 
    } catch (err: any) {
        console.error("Error deleting item: ", err);
        alert("Error deleting item: " + err.message);
        setIsDeleting(false);
    }
  };

  const handleAddToCart = () => {
      if (item) {
          addToCart(item);
          setIsAdded(true);
          setTimeout(() => setIsAdded(false), 2000);
      }
  };

  if (loading) return (
      <div className="flex flex-col items-center justify-center min-h-[50vh]">
          <Loader2 className="animate-spin text-forest mb-4" size={32} />
          <p className="text-gray-500 font-medium">Loading details...</p>
      </div>
  );
  
  if (error || !item) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-gray-900">{error || 'Item not found'}</h2>
        <Link to="/browse" className="text-forest hover:underline mt-4 inline-block">Return to Browse</Link>
      </div>
    );
  }

  const isOwner = user && user.id === item.seller.id;
  const isStoreItem = item.type === 'store';
  const isLearnItem = item.type === 'learn';
  const isRoommate = item.type === 'roommate';
  const inWishlist = isInWishlist(item.id);

  return (
    <div className="min-h-screen bg-gray-50 pb-24 md:pb-12">
      
      {/* MOBILE: Sticky Header */}
      <div className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-gray-100 px-4 py-3 flex items-center justify-between md:hidden">
         <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-full transition active:scale-95">
            <ArrowLeft size={22} />
         </button>
         <div className="flex gap-2">
            <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition active:scale-95">
                <Share2 size={20} />
            </button>
            <button 
                onClick={() => toggleWishlist(item)}
                className={`p-2 rounded-full transition active:scale-95 ${inWishlist ? 'text-red-500 bg-red-50' : 'text-gray-500 hover:bg-gray-100'}`}
            >
                <Heart size={20} fill={inWishlist ? "currentColor" : "none"} />
            </button>
         </div>
      </div>

      <div className="max-w-7xl mx-auto px-0 md:px-6 lg:px-8 py-0 md:py-8">
        
        {/* DESKTOP: Breadcrumbs */}
        <div className="hidden md:flex items-center gap-3 mb-6 text-sm text-gray-500">
            <Link to="/" className="hover:text-forest">Home</Link>
            <span className="text-gray-300">/</span>
            <Link 
                to={isStoreItem ? "/?section=ecostore" : isLearnItem ? "/?section=ecolearn" : isRoommate ? "/browse?type=roommate" : "/browse"} 
                className="hover:text-forest"
            >
                {isStoreItem ? "EcoStore" : isLearnItem ? "EcoLearn" : isRoommate ? "Roommates" : "Browse"}
            </Link>
            <span className="text-gray-300">/</span>
            <span className="text-gray-900 font-medium truncate max-w-[200px]">{item.title}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-0 md:gap-10">
          
          {/* LEFT COLUMN: Image Gallery */}
          <div className="space-y-4">
            <div className="relative bg-white md:rounded-2xl overflow-hidden shadow-sm border-b md:border border-gray-100 group">
                
                <div className="aspect-[4/3] md:aspect-square w-full relative bg-gray-100 overflow-hidden max-h-[50vh] md:max-h-[600px]">
                    <img 
                        src={item.image} 
                        alt={item.title} 
                        className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500" 
                    />
                    
                    <div className="absolute top-4 left-4 flex flex-wrap gap-2 pointer-events-none">
                        {item.type === 'flash' && <span className="bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">Flash Sale</span>}
                        {item.type === 'rent' && <span className="bg-blue-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">Rent</span>}
                        {item.type === 'donate' && <span className="bg-purple-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">Free</span>}
                        {isRoommate && <span className="bg-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg flex items-center gap-1"><Users size={12}/> Roommate</span>}
                        {isStoreItem && <span className="bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg flex items-center gap-1"><Crown size={12}/> Official</span>}
                    </div>
                </div>
            </div>
            
            {item.images && item.images.length > 1 && (
               <div className="flex gap-3 px-4 md:px-0 overflow-x-auto pb-4 md:pb-0 scrollbar-hide snap-x">
                   {item.images.map((img, i) => (
                      <div key={i} className="snap-start flex-shrink-0 w-20 h-20 rounded-xl overflow-hidden border-2 border-transparent hover:border-forest cursor-pointer bg-gray-100">
                          <img src={img} className="w-full h-full object-cover" />
                      </div>
                   ))}
               </div>
            )}
          </div>

          {/* RIGHT COLUMN: Info & Details */}
          <div className="p-5 md:p-0 space-y-6 bg-white md:bg-transparent">
            
            <div>
              <div className="hidden md:flex justify-between items-start mb-2">
                <span className={`text-sm font-bold uppercase tracking-wider px-2 py-1 rounded border ${isRoommate ? 'bg-indigo-50 text-indigo-700 border-indigo-100' : 'bg-green-50 text-forest border-green-100'}`}>{item.category}</span>
                <div className="flex gap-2">
                   <button className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition"><Share2 size={20} /></button>
                   <button 
                        onClick={() => toggleWishlist(item)} 
                        className={`p-2 rounded-full hover:bg-gray-100 transition ${inWishlist ? 'text-red-500 bg-red-50' : 'text-gray-400 hover:text-red-500'}`}
                   >
                       <Heart size={20} fill={inWishlist ? "currentColor" : "none"} />
                   </button>
                </div>
              </div>
              
              <h1 className="text-2xl md:text-4xl font-black text-gray-900 leading-snug mb-3">{item.title}</h1>
              
              <div className="flex items-center gap-2 mb-5 text-sm text-gray-500">
                  {isStoreItem ? (
                      <span className="inline-flex items-center gap-1.5 bg-gradient-to-r from-violet-50 to-purple-50 text-purple-700 px-3 py-1 rounded-full text-xs font-bold border border-purple-100">
                          <Crown size={12} className="fill-current"/> Premium Store
                      </span>
                  ) : (
                      <span className="flex items-center gap-1 bg-gray-100 px-2 py-1 rounded-md text-xs font-medium text-gray-600">
                          <MapPin size={12}/> {item.seller?.campus || "Campus"}
                      </span>
                  )}
                  <span className="text-gray-300">|</span>
                  <span className="text-xs">Listed {new Date(item.postedAt).toLocaleDateString()}</span>
              </div>

              <div className="bg-gray-50 p-4 md:p-5 rounded-xl border border-gray-100 flex items-center justify-between shadow-sm">
                 <div>
                    <p className="text-[10px] md:text-xs text-gray-500 font-bold uppercase mb-1">{isRoommate ? 'Monthly Rent' : 'Asking Price'}</p>
                    <div className="flex items-baseline gap-2 md:gap-3">
                        <span className="text-3xl md:text-4xl font-black text-gray-900">
                            {item.price === 0 ? 'Free' : `₹${item.price.toLocaleString()}`}
                        </span>
                        {(item.type === 'rent' || isRoommate) && <span className="text-sm font-medium text-gray-500">/{item.rentalPeriod || 'month'}</span>}
                    </div>
                 </div>
                 <div className={`px-3 py-1.5 rounded-lg text-xs font-bold border shadow-sm ${isRoommate ? 'bg-indigo-100 text-indigo-700 border-indigo-200' : (item.condition === 'New' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-white text-gray-700 border-gray-200')}`}>
                     {item.condition}
                 </div>
              </div>
            </div>

            {/* Seller Profile Card */}
            <div className="bg-white border border-gray-200 rounded-xl p-4 flex items-center gap-4 shadow-sm">
                <div className={`h-12 w-12 rounded-full ${isStoreItem ? 'bg-purple-600' : isRoommate ? 'bg-indigo-600' : isLearnItem ? 'bg-cyan-600' : 'bg-forest'} text-white flex items-center justify-center font-bold text-xl shadow-md border-2 border-white`}>
                    {isStoreItem ? <ShoppingBag size={20} /> : item.seller?.name?.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-bold text-gray-900 truncate">
                        {isStoreItem ? "Official EcoStore" : (item.seller?.name || 'Anonymous')}
                    </h3>
                    <div className="flex items-center text-xs text-gray-500 mt-0.5">
                        {isStoreItem ? "Verified Campus Partner" : item.seller?.campus}
                        {(item.seller?.verified || isStoreItem) && (
                            <CheckCircle size={12} className="ml-1 text-blue-500 fill-blue-50" />
                        )}
                    </div>
                </div>
            </div>

            {/* Description */}
            <div className="pt-2">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">{isRoommate ? 'Room/Flat Details' : 'Item Details'}</h3>
              <p className="text-gray-700 text-sm md:text-base leading-relaxed whitespace-pre-wrap">
                {item.description}
              </p>
            </div>

            {/* Action Buttons (Desktop) */}
            <div className="hidden md:flex gap-4 pt-6 border-t border-gray-100">
               {isOwner ? (
                  <>
                    <Link to={`/edit-item/${item.id}`} className="flex-1 bg-white border border-gray-300 text-gray-700 py-3 px-4 rounded-xl font-bold hover:bg-gray-50 transition text-center shadow-sm">
                        Edit Listing
                    </Link>
                    <button onClick={handleDelete} disabled={isDeleting} className="flex-1 bg-red-50 text-red-600 py-3 px-4 rounded-xl font-bold hover:bg-red-100 transition shadow-sm">
                        {isDeleting ? 'Deleting...' : 'Delete Listing'}
                    </button>
                  </>
               ) : (
                  <>
                    {isStoreItem ? (
                        <div className="flex gap-3 flex-1">
                            <button 
                                onClick={handleAddToCart}
                                disabled={isAdded}
                                className={`flex-1 border-2 font-bold py-3.5 px-4 rounded-xl shadow-sm transition transform hover:-translate-y-0.5 flex items-center justify-center gap-2 ${
                                    isAdded 
                                    ? 'bg-white text-green-600 border-green-600' 
                                    : 'bg-white text-purple-600 border-purple-600 hover:bg-purple-50'
                                }`}
                            >
                                {isAdded ? <Check size={20} /> : <ShoppingCart size={20} />} 
                                {isAdded ? 'Added' : 'Add to Cart'}
                            </button>
                            <button 
                                onClick={() => { if(!user) navigate('/login'); else setShowOrderModal(true); }}
                                className="flex-1 bg-purple-600 text-white font-bold py-3.5 px-6 rounded-xl shadow-lg hover:bg-purple-700 transition transform hover:-translate-y-0.5 flex items-center justify-center gap-2"
                            >
                                <ShoppingBag size={20} /> Buy Now
                            </button>
                        </div>
                    ) : (
                        <button 
                            onClick={handleContactSeller}
                            className={`flex-1 text-white font-bold py-3.5 px-6 rounded-xl shadow-lg transition transform hover:-translate-y-0.5 flex items-center justify-center gap-2 ${isRoommate ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-forest hover:bg-green-700'}`}
                        >
                            <MessageCircle size={20} /> {isRoommate ? 'Chat with Lister' : 'Chat with Seller'}
                        </button>
                    )}
                  </>
               )}
            </div>

          </div>
        </div>
      </div>

      {/* MOBILE ACTION BAR (Fixed Bottom) */}
      <div className="fixed bottom-0 left-0 w-full bg-white border-t border-gray-200 p-3 pb-safe z-40 md:hidden flex gap-3 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
          {isOwner ? (
              <Link to={`/edit-item/${item.id}`} className="flex-1 bg-gray-100 text-gray-900 font-bold py-3 rounded-xl flex items-center justify-center shadow-sm">
                  Edit Listing
              </Link>
          ) : (
              <>
                <div className="flex flex-col justify-center px-2">
                    <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">{isRoommate ? 'Monthly' : 'Total'}</span>
                    <span className="text-xl font-black text-gray-900 leading-none">
                        {item.price === 0 ? 'Free' : `₹${item.price.toLocaleString()}`}
                    </span>
                </div>
                
                {isStoreItem ? (
                    <div className="flex gap-2 flex-1">
                        <button 
                            onClick={handleAddToCart}
                            disabled={isAdded}
                            className={`p-3 rounded-xl flex items-center justify-center transition-all ${
                                isAdded 
                                ? 'bg-white text-green-600 border border-green-600' 
                                : 'bg-purple-100 text-purple-700'
                            }`}
                        >
                            {isAdded ? <Check size={20} /> : <ShoppingCart size={20} />}
                        </button>
                        <button 
                            onClick={() => { if(!user) navigate('/login'); else setShowOrderModal(true); }}
                            className="flex-1 bg-purple-600 text-white font-bold py-3 rounded-xl shadow-md flex items-center justify-center gap-2 active:scale-95 transition"
                        >
                            <ShoppingBag size={18} /> Buy Now
                        </button>
                    </div>
                ) : (
                    <button 
                        onClick={handleContactSeller}
                        className={`flex-1 text-white font-bold py-3 rounded-xl shadow-md flex items-center justify-center gap-2 active:scale-95 transition ${isRoommate ? 'bg-indigo-600' : 'bg-forest'}`}
                    >
                        <MessageCircle size={18} /> Chat
                    </button>
                )}
              </>
          )}
      </div>

      {/* STORE ORDER MODAL (Same as before) */}
      {showOrderModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in zoom-in-95">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh]">
                  <div className="px-5 py-4 bg-purple-600 text-white flex justify-between items-center">
                      <h3 className="text-lg font-bold flex items-center gap-2"><ShoppingBag size={20}/> Place Order</h3>
                      <button onClick={() => setShowOrderModal(false)} className="text-white/80 hover:text-white p-1 rounded-full">
                          <X size={24} />
                      </button>
                  </div>
                  
                  <form onSubmit={handlePlaceOrder} className="p-5 space-y-4 overflow-y-auto">
                      <div className="bg-purple-50 p-3 rounded-xl border border-purple-100">
                          <p className="text-sm text-purple-800 font-medium">Buying: {item.title}</p>
                          <p className="text-xl font-black text-purple-900 mt-1">₹{item.price}</p>
                      </div>
                      
                      <div className="space-y-3">
                          <div>
                              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Full Name</label>
                              <input required type="text" value={orderName} onChange={e => setOrderName(e.target.value)} className="w-full border border-gray-300 rounded-xl px-3 py-2.5 text-sm focus:ring-2 focus:ring-purple-500 outline-none" placeholder="e.g. Rahul Kumar"/>
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                              <div>
                                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Hostel / Block</label>
                                  <input required type="text" value={orderHostel} onChange={e => setOrderHostel(e.target.value)} className="w-full border border-gray-300 rounded-xl px-3 py-2.5 text-sm focus:ring-2 focus:ring-purple-500 outline-none" placeholder="e.g. BH-1"/>
                              </div>
                              <div>
                                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Room No</label>
                                  <input required type="text" value={orderRoom} onChange={e => setOrderRoom(e.target.value)} className="w-full border border-gray-300 rounded-xl px-3 py-2.5 text-sm focus:ring-2 focus:ring-purple-500 outline-none" placeholder="e.g. 304"/>
                              </div>
                          </div>
                          <div>
                              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Phone Number</label>
                              <input required type="tel" value={orderPhone} onChange={e => setOrderPhone(e.target.value)} className="w-full border border-gray-300 rounded-xl px-3 py-2.5 text-sm focus:ring-2 focus:ring-purple-500 outline-none" placeholder="e.g. 9876543210"/>
                          </div>
                      </div>

                      <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-100 flex gap-2">
                          <Zap size={16} className="text-yellow-600 flex-shrink-0 mt-0.5" />
                          <p className="text-xs text-yellow-800">Pay via Cash or UPI upon delivery. Your order details will be sent to the store manager instantly.</p>
                      </div>

                      <button 
                        type="submit" 
                        disabled={orderLoading}
                        className="w-full bg-purple-600 text-white font-bold py-3.5 rounded-xl shadow-lg hover:bg-purple-700 transition flex items-center justify-center gap-2"
                      >
                          {orderLoading ? <Loader2 size={20} className="animate-spin" /> : 'Confirm Order'}
                      </button>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
};

export default ItemDetails;
