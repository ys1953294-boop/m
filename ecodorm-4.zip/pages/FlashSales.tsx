
import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import ItemCard from '../components/ItemCard';
import { Clock, Zap, AlertCircle, ArrowLeft } from 'lucide-react';
import { Item } from '../types';
import { Link } from 'react-router-dom';

const FlashSales: React.FC = () => {
  const [flashItems, setFlashItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Simulated countdown for the "Event"
  const [timeLeft, setTimeLeft] = useState(24 * 60 * 60); // 24 hours in seconds

  useEffect(() => {
    fetchFlashItems();
    const timer = setInterval(() => {
      setTimeLeft(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const fetchFlashItems = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('items')
        .select('*, seller:users(*)')
        .eq('type', 'flash')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (data) {
        const mapped: Item[] = data.map((d: any) => ({
            id: d.id,
            title: d.title,
            description: d.description,
            price: d.price,
            originalPrice: d.original_price,
            image: d.images?.[0] || 'https://via.placeholder.com/400',
            images: d.images,
            category: d.category,
            condition: d.condition,
            type: d.type,
            seller: {
              id: d.seller?.id,
              name: d.seller?.name || 'Unknown',
              campus: d.seller?.campus,
              verified: d.seller?.verified,
              avatar: d.seller?.avatar,
              sustainabilityScore: d.seller?.sustainability_score
            },
            postedAt: d.created_at,
            isActive: d.is_active,
            flashSaleEndsAt: d.flash_sale_ends_at
        }));
        setFlashItems(mapped);
      }
    } catch (err) {
      console.error('Error fetching flash items:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div>
      {/* Banner */}
      <div className="bg-gradient-to-r from-red-600 to-amber-500 text-white py-12 relative">
        <div className="absolute top-4 left-4 z-20">
             <Link to="/" className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition flex items-center justify-center backdrop-blur-sm">
                 <ArrowLeft size={20} />
             </Link>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center justify-center p-2 bg-white/20 rounded-full mb-4 animate-pulse">
            <Zap className="mr-2" size={20} />
            <span className="font-bold tracking-wider uppercase text-sm">Semester End Clearance</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4">Everything Must Go!</h1>
          <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
            Grab amazing deals from students moving out. Prices drop every 12 hours.
          </p>
          
          <div className="inline-block bg-white text-red-600 rounded-xl px-6 py-3 shadow-lg">
             <div className="flex items-center gap-2">
                <Clock className="animate-spin-slow" />
                <span className="text-sm font-semibold uppercase tracking-wide text-gray-500">Event Ends In</span>
             </div>
             <div className="text-4xl font-mono font-bold mt-1 tracking-widest">
                {formatTime(timeLeft)}
             </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-[400px]">
        <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-gray-900">Live Deals</h2>
            <span className="bg-red-100 text-red-800 text-xs font-semibold px-2.5 py-0.5 rounded">High Demand</span>
        </div>

        {loading ? (
             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[1,2,3,4].map(i => <div key={i} className="h-80 bg-gray-100 rounded-2xl animate-pulse"></div>)}
             </div>
        ) : flashItems.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {flashItems.map(item => (
                <ItemCard key={item.id} item={item} />
              ))}
            </div>
        ) : (
            <div className="text-center py-20 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                <AlertCircle className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                <h3 className="text-lg font-medium text-gray-900">No Flash Sales Active</h3>
                <p className="text-gray-500 mb-4">Check back later or list your own item!</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default FlashSales;
