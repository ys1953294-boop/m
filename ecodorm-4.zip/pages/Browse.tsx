import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import ItemCard from '../components/ItemCard';
import { Filter, SlidersHorizontal, X, Check, Search, MapPin, ChevronDown, School, ArrowUpDown, LayoutGrid, ArrowLeft, Users } from 'lucide-react';
import { Category, ListingType, Item } from '../types';
import { CATEGORIES, KNOWLEDGE_PARK_COLLEGES, GREATER_NOIDA_COLLEGES } from '../constants';
import { useAuth } from '../contexts/AuthContext';
import { useSearchParams, useNavigate } from 'react-router-dom';

type LocationScope = 'my_campus' | 'nearby' | 'city' | 'all';
type SortOption = 'newest' | 'price_low' | 'price_high';

const STORE_CATEGORIES = ['Gadgets', 'Audio', 'Accessories', 'Decor', 'Setup', 'Merch', 'Limited'];
const LEARN_CATEGORIES = ['B.Tech Notes', 'B.Tech PYQ', 'BCA Notes', 'BCA PYQ'];
const GENERAL_CATEGORIES = ['Textbooks', 'Stationery', 'Electronics', 'Furniture', 'Clothing', 'Kitchen', 'Other', 'Roommates'];

const Browse: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [showLocationMenu, setShowLocationMenu] = useState(false);
  
  const typeParam = searchParams.get('type');
  const validTypes = ['sell', 'rent', 'donate', 'flash', 'store', 'learn', 'roommate'];
  const initialType = (typeParam && validTypes.includes(typeParam)) ? (typeParam as any) : 'all';

  const categoryParam = searchParams.get('category');
  const initialCategory = (categoryParam && CATEGORIES.includes(categoryParam as Category)) ? (categoryParam as Category) : 'All';

  const searchParam = searchParams.get('search');
  const premiumParam = searchParams.get('premium') === 'true';
  const genderParam = searchParams.get('gender');

  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>(initialCategory);
  const [listingType, setListingType] = useState<ListingType | 'all'>(initialType);
  const [maxPrice, setMaxPrice] = useState<number>(100000);
  const [searchQuery, setSearchQuery] = useState(searchParam || '');
  const [sortBy, setSortBy] = useState<SortOption>('newest');
  const [isPremiumFilter, setIsPremiumFilter] = useState(premiumParam);
  const [genderFilter, setGenderFilter] = useState<string | null>(genderParam);
  const [locationScope, setLocationScope] = useState<LocationScope>('all');

  useEffect(() => {
    const tParam = searchParams.get('type');
    if (tParam && validTypes.includes(tParam)) {
        setListingType(tParam as any);
    } else {
        setListingType('all');
    }
    const cParam = searchParams.get('category');
    if (cParam && CATEGORIES.includes(cParam as Category)) {
        setSelectedCategory(cParam as Category);
    } else {
        setSelectedCategory('All');
    }
    const sParam = searchParams.get('search');
    if (sParam !== null) setSearchQuery(sParam);
    const pParam = searchParams.get('premium') === 'true';
    setIsPremiumFilter(pParam);
    const gParam = searchParams.get('gender');
    setGenderFilter(gParam);
  }, [searchParams]);

  useEffect(() => {
    if (!user) setLocationScope('all');
  }, [user]);

  useEffect(() => {
    fetchItems();
  }, [selectedCategory, listingType, maxPrice, searchQuery, locationScope, user, sortBy, isPremiumFilter, genderFilter]);

  const fetchItems = async () => {
    setLoading(true);
    let query = supabase.from('items').select('*, seller:users(*)').eq('is_active', true);
    if (selectedCategory !== 'All') query = query.eq('category', selectedCategory);
    if (listingType !== 'all') query = query.eq('type', listingType);
    else query = query.neq('type', 'store').neq('type', 'learn').neq('type', 'roommate');
    if (isPremiumFilter) query = query.eq('is_premium', true);
    if (genderFilter) query = query.in('gender', [genderFilter, 'Unisex']);
    query = query.lte('price', maxPrice);
    if (searchQuery) query = query.ilike('title', `%${searchQuery}%`);
    if (sortBy === 'newest') query = query.order('created_at', { ascending: false });
    else if (sortBy === 'price_low') query = query.order('price', { ascending: true });
    else if (sortBy === 'price_high') query = query.order('price', { ascending: false });
    const { data } = await query.limit(200);
    if (data) {
      let mapped = data.map((d: any) => ({
        id: d.id, title: d.title, description: d.description, price: d.price, originalPrice: d.original_price, image: d.images?.[0] || 'https://via.placeholder.com/400', images: d.images, category: d.category, condition: d.condition, type: d.type, deliveryDuration: d.delivery_duration, isPremium: d.is_premium, rentalPeriod: d.rental_period, seller: { id: d.seller?.id, name: d.seller?.name || 'Unknown', campus: d.seller?.campus || 'Unknown', verified: d.seller?.verified, avatar: d.seller?.avatar, sustainabilityScore: d.seller?.sustainability_score }, postedAt: d.created_at
      }));
      if (user && user.campus && locationScope !== 'all') {
        const userCampus = user.campus;
        mapped = mapped.filter(item => {
            const itemCampus = item.seller.campus;
            if (!itemCampus || itemCampus === 'Unknown') return false; 
            if (locationScope === 'my_campus') return itemCampus === userCampus;
            if (locationScope === 'nearby') {
                const isUserInKP = KNOWLEDGE_PARK_COLLEGES.includes(userCampus);
                return isUserInKP ? KNOWLEDGE_PARK_COLLEGES.includes(itemCampus) : GREATER_NOIDA_COLLEGES.includes(itemCampus);
            }
            if (locationScope === 'city') return GREATER_NOIDA_COLLEGES.includes(itemCampus);
            return true;
        });
      }
      setItems(mapped);
    }
    setLoading(false);
  };

  const clearFilters = () => {
      if (listingType === 'store' || listingType === 'learn' || listingType === 'roommate') {
          setSearchQuery(''); setSelectedCategory('All'); setMaxPrice(100000); setSortBy('newest');
          navigate(`/browse?type=${listingType}`);
      } else {
          navigate('/browse');
      }
  };

  const handleCategoryClick = (cat: string) => {
      const newParams = new URLSearchParams(searchParams);
      if (cat === 'All') newParams.delete('category');
      else newParams.set('category', cat);
      if (!newParams.get('type')) {
          if (STORE_CATEGORIES.includes(cat)) newParams.set('type', 'store');
          else if (LEARN_CATEGORIES.includes(cat)) newParams.set('type', 'learn');
          else if (cat === 'Roommates') newParams.set('type', 'roommate');
      }
      setSearchParams(newParams);
  };

  const isStore = listingType === 'store';
  const isLearn = listingType === 'learn';
  const isMen = genderFilter === 'Men';
  const isWomen = genderFilter === 'Women';
  const isRoommate = listingType === 'roommate';
  const isDark = (isStore || isMen) && !isWomen;
  const showTypeSwitcher = !isStore && !isLearn && !isRoommate;

  const theme = {
      bg: isMen ? 'bg-[#0f172a]' : isWomen ? 'bg-[#FFF1F2]' : isStore ? 'bg-zinc-950' : 'bg-gray-50',
      text: isDark ? 'text-zinc-100' : isWomen ? 'text-rose-950' : 'text-gray-900',
      textSecondary: isMen ? 'text-slate-400' : (isStore ? 'text-zinc-400' : (isWomen ? 'text-rose-700/60' : 'text-gray-500')),
      border: isMen ? 'border-slate-800' : isWomen ? 'border-rose-200' : isStore ? 'border-zinc-800' : 'border-gray-200',
      panelBg: isMen ? 'bg-[#1e293b]' : isWomen ? 'bg-white/80' : isStore ? 'bg-zinc-900' : 'bg-white',
      accent: isRoommate ? 'text-indigo-600' : isMen ? 'text-blue-400' : isWomen ? 'text-rose-500' : isStore ? 'text-purple-400' : 'text-forest',
      accentBg: isRoommate ? 'bg-indigo-600' : isMen ? 'bg-blue-600' : isWomen ? 'bg-rose-500' : isStore ? 'bg-purple-600' : 'bg-forest',
      accentHover: isRoommate ? 'hover:bg-indigo-700' : isMen ? 'hover:bg-blue-500' : isWomen ? 'hover:bg-rose-600' : isStore ? 'hover:bg-purple-500' : 'hover:bg-green-700',
      accentLight: isRoommate ? 'bg-indigo-50 text-indigo-600' : isMen ? 'bg-blue-900/30 text-blue-300' : isWomen ? 'bg-rose-100 text-rose-600' : isStore ? 'bg-purple-500/10 text-purple-300' : 'bg-green-50 text-forest',
      ring: isRoommate ? 'focus:ring-indigo-500' : isMen ? 'focus:ring-blue-500' : isWomen ? 'focus:ring-rose-400' : isStore ? 'focus:ring-purple-500' : 'focus:ring-forest',
      stickyHeader: isMen ? 'bg-[#0f172a]/95' : isWomen ? 'bg-[#FFF1F2]/90' : isStore ? 'bg-zinc-950/95' : 'bg-warm/95',
      searchInput: isMen ? 'bg-[#1e293b]' : isWomen ? 'bg-white' : isStore ? 'bg-zinc-900' : 'bg-white',
      pillActive: isRoommate ? 'bg-indigo-600 text-white border-indigo-600' : isMen ? 'bg-blue-600 text-white' : isWomen ? 'bg-rose-500 text-white' : isStore ? 'bg-purple-600 text-white' : 'bg-forest text-white',
      pillInactive: isDark ? 'bg-zinc-900 text-zinc-400' : 'bg-white text-gray-600',
      selectBg: isDark ? 'bg-zinc-900 border-zinc-700 text-white' : 'bg-white border-gray-200 text-gray-700',
      skeleton: isDark ? 'bg-zinc-800' : 'bg-white',
      slider: isRoommate ? 'accent-indigo-600' : isMen ? 'accent-blue-500' : isWomen ? 'accent-rose-500' : 'accent-forest',
  };

  const currentCategories = listingType === 'store' ? STORE_CATEGORIES : listingType === 'learn' ? LEARN_CATEGORIES : GENERAL_CATEGORIES;

  return (
    <div className={`min-h-[calc(100vh-64px)] w-full transition-colors duration-300 ${theme.bg}`}>
    <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 ${isStore ? 'pt-2 pb-6' : 'py-6'}`}>
      <div className={`mb-6 sticky top-14 md:top-16 z-30 backdrop-blur py-3 -mx-4 px-4 border-b shadow-sm transition-all duration-200 ${theme.stickyHeader} ${theme.border}`}>
         {isStore && (
             <div className="mb-3 px-1">
                <h1 className="text-2xl md:text-3xl font-black tracking-tight flex items-center gap-2">
                    {genderFilter ? <span className={`text-transparent bg-clip-text bg-gradient-to-r ${genderFilter === 'Men' ? 'from-blue-400 to-cyan-300' : 'from-pink-400 to-rose-300'}`}>{genderFilter}'s Collection</span> : <span className="text-white">EcoStore</span>}
                </h1>
             </div>
         )}
         {isRoommate && (
             <div className="mb-3 px-1">
                <h1 className="text-2xl md:text-3xl font-black tracking-tight text-gray-900 flex items-center gap-2"><Users className="text-indigo-600"/> Roommates</h1>
                <p className="text-gray-500 text-xs mt-1">Find your perfect campus flatmate</p>
             </div>
         )}
         <div className="flex items-center gap-3">
             <button onClick={() => navigate(-1)} className={`p-2 -ml-2 rounded-full transition ${isDark ? 'text-zinc-400 hover:text-white' : 'text-gray-500 hover:text-gray-900'}`}><ArrowLeft size={20} /></button>
             <div className="relative flex-1 group">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Search size={18} className={`${isDark ? 'text-zinc-500 group-focus-within:text-purple-500' : 'text-gray-400 group-focus-within:text-forest'}`} /></div>
                <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder={isStore ? "Search EcoStore..." : isRoommate ? "Search flats..." : "Search items..."} className={`block w-full pl-10 pr-3 py-2.5 border rounded-xl leading-5 focus:outline-none focus:ring-2 sm:text-sm transition shadow-sm ${theme.searchInput} ${theme.border} ${theme.ring}`} />
             </div>
             <div className="relative flex-shrink-0">
                 <button onClick={() => setShowLocationMenu(!showLocationMenu)} className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-bold border shadow-sm transition active:scale-95 ${locationScope !== 'all' ? theme.pillActive : theme.pillInactive} ${theme.border}`}>
                    <MapPin size={18} />
                    <span className="hidden sm:inline max-w-[120px] truncate">{getScopeLabel(locationScope)}</span>
                    <ChevronDown size={14} className="ml-1" />
                 </button>
                 {showLocationMenu && (
                    <>
                        <div className="fixed inset-0 z-10" onClick={() => setShowLocationMenu(false)}></div>
                        <div className={`absolute right-0 top-full mt-2 w-60 rounded-xl shadow-xl border z-20 py-1 overflow-hidden ${theme.panelBg} ${theme.border}`}>
                            {['my_campus', 'nearby', 'city', 'all'].map((scope) => (
                                <button key={scope} onClick={() => { setLocationScope(scope as any); setShowLocationMenu(false); }} className={`w-full text-left px-4 py-3 text-sm flex items-center justify-between border-b ${theme.border} ${locationScope === scope ? `${theme.accentLight} font-bold` : `${theme.text} hover:bg-black/5`}`}><span>{getScopeLabel(scope as any)}</span>{locationScope === scope && <Check size={16}/>}</button>
                            ))}
                        </div>
                    </>
                 )}
             </div>
             <button onClick={() => setShowMobileFilters(true)} className={`md:hidden flex items-center justify-center h-11 w-11 border shadow-sm rounded-xl active:scale-95 transition flex-shrink-0 ${theme.pillInactive} ${theme.border}`}><Filter size={20} /></button>
         </div>
         <div className="flex overflow-x-auto gap-2 scrollbar-hide mt-3 pb-1 -mx-4 px-4 md:mx-0 md:px-0">
             <button onClick={() => handleCategoryClick('All')} className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-bold transition-all border flex items-center gap-1.5 ${selectedCategory === 'All' ? theme.pillActive : theme.pillInactive} ${theme.border}`}><LayoutGrid size={14} /> All</button>
             {currentCategories.map((cat) => (
                <button key={cat} onClick={() => handleCategoryClick(cat)} className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-bold transition-all border ${selectedCategory === cat ? theme.pillActive : theme.pillInactive} ${theme.border}`}>{cat}</button>
             ))}
         </div>
         {showTypeSwitcher && (
            <div className="flex overflow-x-auto gap-2 scrollbar-hide mt-2 pb-1 -mx-4 px-4 md:mx-0 md:px-0">
                {['all', 'sell', 'rent', 'donate', 'flash', 'store', 'learn', 'roommate'].map((type) => (
                    <button key={type} onClick={() => { setListingType(type as any); navigate(`/browse?type=${type}`, { replace: true }); }} className={`whitespace-nowrap px-3 py-1 rounded-md text-[10px] uppercase tracking-wider font-bold transition-all border ${listingType === type ? 'bg-gray-200 text-gray-800' : 'text-gray-400 border-transparent hover:bg-gray-100'}`}>{type}</button>
                ))}
            </div>
         )}
      </div>
      <div className="flex flex-col md:flex-row gap-8">
        <aside className="hidden md:block w-72 flex-shrink-0">
          <div className={`p-6 rounded-2xl shadow-sm border sticky top-40 ${theme.panelBg} ${theme.border}`}>
            <h2 className={`text-lg font-bold mb-6 flex items-center gap-2 ${theme.text}`}><SlidersHorizontal size={20} /> Filters</h2>
            <FilterContent />
          </div>
        </aside>
        {showMobileFilters && (
            <div className="fixed inset-0 z-50 md:hidden">
                <div className="absolute inset-0 bg-black/60" onClick={() => setShowMobileFilters(false)}></div>
                <div className={`absolute inset-x-0 bottom-0 rounded-t-2xl p-6 h-[85vh] overflow-y-auto ${theme.panelBg}`}>
                    <div className={`flex items-center justify-between mb-6 sticky top-0 z-10 pb-2 border-b ${theme.border}`}>
                        <h2 className={`text-xl font-bold flex items-center gap-2 ${theme.text}`}><SlidersHorizontal size={20} /> Filters</h2>
                        <button onClick={() => setShowMobileFilters(false)} className={`p-2 rounded-full ${theme.pillInactive}`}><X size={20} /></button>
                    </div>
                    <FilterContent />
                    <div className="sticky bottom-0 pt-4"><button onClick={() => setShowMobileFilters(false)} className={`w-full text-white font-bold py-3 rounded-xl shadow-lg transition ${theme.accentBg}`}>Show {items.length} Results</button></div>
                </div>
            </div>
        )}
        <main className="flex-1">
          <div className="flex flex-col md:flex-row justify-between md:items-center mb-4 md:mb-6 gap-2">
                <h1 className={`text-xl md:text-2xl font-bold ${theme.text}`}>{selectedCategory === 'All' ? (listingType === 'all' ? 'All Items' : listingType.charAt(0).toUpperCase() + listingType.slice(1)) : selectedCategory}</h1>
                <div className="flex items-center gap-4"><span className={`font-medium text-sm ${theme.textSecondary}`}>{items.length} results</span></div>
          </div>
          {loading ? (
             <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">{[1,2,3,4,5,6].map(i => <div key={i} className={`rounded-2xl h-64 animate-pulse border ${theme.skeleton} ${theme.border}`}></div>)}</div>
          ) : items.length > 0 ? (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 md:gap-6">{items.map(item => <ItemCard key={item.id} item={item} />)}</div>
          ) : (
            <div className={`flex flex-col items-center justify-center py-20 rounded-2xl border border-dashed ${theme.panelBg} ${theme.border}`}>
              <Filter className={`h-8 w-8 mb-4 ${theme.textSecondary}`} />
              <h3 className={`text-lg font-bold ${theme.text}`}>No items found</h3>
              <button onClick={clearFilters} className={`mt-6 px-6 py-2.5 text-white rounded-xl font-semibold transition ${theme.accentBg} ${theme.accentHover}`}>Clear all filters</button>
            </div>
          )}
        </main>
      </div>
    </div>
    </div>
  );

  function getScopeLabel(scope: LocationScope) {
      switch(scope) {
          case 'my_campus': return 'My Campus';
          case 'nearby': return 'Nearby';
          case 'city': return 'Greater Noida';
          case 'all': return 'All India';
          default: return 'Scope';
      }
  };

  function FilterContent() {
    return (
        <div className="space-y-8">
            <div><h3 className={`text-sm font-bold mb-3 uppercase tracking-wider ${theme.textSecondary}`}>Categories</h3><div className="space-y-1">
                {['All', ...currentCategories].map((cat) => (
                    <button key={cat} onClick={() => handleCategoryClick(cat)} className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors ${selectedCategory === cat ? `${theme.accentLight} font-semibold` : `${theme.textSecondary} hover:bg-opacity-10 ${isDark ? 'hover:bg-white' : 'hover:bg-gray-900'}`}`}><span>{cat === 'All' ? 'All Categories' : cat}</span>{selectedCategory === cat && <Check size={16} />}</button>
                ))}
            </div></div>
            <div><h3 className={`text-sm font-bold mb-3 uppercase tracking-wider ${theme.textSecondary}`}>Sort By</h3><select value={sortBy} onChange={(e) => setSortBy(e.target.value as any)} className={`w-full py-2 px-3 rounded-lg focus:outline-none focus:ring-2 border text-sm ${theme.selectBg} ${theme.border} ${theme.ring}`}><option value="newest">Newest Listed</option><option value="price_low">Price: Low to High</option><option value="price_high">Price: High to Low</option></select></div>
            <div><div className="flex items-center justify-between mb-3"><h3 className={`text-sm font-bold uppercase tracking-wider ${theme.textSecondary}`}>Max Price</h3><span className={`text-sm font-bold ${theme.accent}`}>₹{maxPrice.toLocaleString()}</span></div><input type="range" min="0" max="100000" step="500" value={maxPrice} onChange={(e) => setMaxPrice(Number(e.target.value))} className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${theme.slider} ${isDark ? 'bg-zinc-700' : 'bg-gray-200'}`} /><div className={`flex justify-between text-xs mt-2 font-medium ${theme.textSecondary}`}><span>₹0</span><span>₹1L+</span></div></div>
            <button onClick={clearFilters} className={`w-full py-2 text-sm transition border-t pt-4 ${theme.textSecondary} hover:text-red-500 ${theme.border}`}>Reset all filters</button>
        </div>
    );
  }
};

export default Browse;