export type ListingType = 'sell' | 'rent' | 'donate' | 'flash' | 'store' | 'learn' | 'roommate';

export type Category = 
  | 'Textbooks' 
  | 'Stationery' 
  | 'Electronics' 
  | 'Furniture' 
  | 'Clothing' 
  | 'Kitchen' 
  | 'Other' 
  | 'Notes' 
  | 'Course'
  | 'B.Tech Notes'
  | 'B.Tech PYQ'
  | 'BCA Notes'
  | 'BCA PYQ'
  | 'Gadgets'
  | 'Audio'
  | 'Accessories'
  | 'Decor'
  | 'Setup'
  | 'Merch'
  | 'Limited'
  | 'Roommates';

export interface User {
  id: string;
  name: string;
  email?: string;
  campus: string;
  verified: boolean;
  avatar: string;
  sustainabilityScore: number;
  role?: 'user' | 'admin';
}

export interface Item {
  id: string;
  title: string;
  description: string;
  price: number;
  originalPrice?: number; // For flash sales
  image: string; // Helper for display, mapped from images[0]
  images?: string[]; // Supabase array
  category: Category;
  condition: 'New' | 'Like New' | 'Good' | 'Fair';
  type: ListingType;
  seller: User;
  postedAt: string;
  rentalRate?: {
    daily: number;
    weekly: number;
  };
  rentalPeriod?: 'day' | 'month'; // Added for Rent frequency
  flashSaleEndsAt?: string;
  isActive?: boolean;
  isPremium?: boolean; // Added Premium Status
  externalLink?: string; // For EcoLearn Google Drive/Video links
  year?: string; // Academic Year (e.g., "1st Year")
  subject?: string; // Subject Name (e.g., "Mathematics")
  deliveryDuration?: string; // e.g., "Same Day Delivery", "10 Minutes", "2-3 Days"
  gender?: 'Men' | 'Women' | 'Unisex' | null; // Target audience for EcoStore items
}

export interface Banner {
  id: string;
  image_url: string;
  link?: string;
  active: boolean;
  created_at: string;
}

export interface SustainabilityMetric {
  name: string;
  value: number;
  unit: string;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  isRead: boolean;
}

export interface Conversation {
  id: string;
  otherUser: User;
  lastMessage: Message;
  unreadCount: number;
  messages: Message[];
}