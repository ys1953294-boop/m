
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { StoreProvider } from './contexts/StoreContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Browse from './pages/Browse';
import FlashSales from './pages/FlashSales';
import Dashboard from './pages/Dashboard';
import Sell from './pages/Sell';
import ItemDetails from './pages/ItemDetails';
import Messages from './pages/Messages';
import Rent from './pages/Rent';
import Donate from './pages/Donate';
import Login from './pages/Login';
import Admin from './pages/Admin';
import EcoLearnAI from './pages/EcoLearnAI';
import VoiceAssistant from './components/VoiceAssistant';
import CartToast from './components/CartToast';

// Secure wrapper for Admin routes
const AdminRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAdmin, loading } = useAuth();
  
  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  
  if (!user || !isAdmin) {
    return <Navigate to="/" replace />;
  }
  
  return <>{children}</>;
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <StoreProvider>
        <Router>
          <ScrollToTop />
          {/* Adjusted pt to match Navbar height exactly (pt-14 for mobile, pt-16 for desktop) to remove white gap */}
          <div className="min-h-screen bg-warm text-gray-800 font-sans flex flex-col pt-14 md:pt-16 pb-16 md:pb-0">
            <Navbar />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<Home />} />
                {/* Redirect legacy routes to Home sections */}
                <Route path="/ecostore" element={<Navigate to="/?section=ecostore" replace />} />
                <Route path="/learn" element={<Navigate to="/?section=ecolearn" replace />} />
                
                <Route path="/learn/ai-study" element={<EcoLearnAI />} />
                <Route path="/login" element={<Login />} />
                <Route path="/browse" element={<Browse />} />
                <Route path="/flash-sales" element={<FlashSales />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/sell" element={<Sell />} />
                <Route path="/edit-item/:id" element={<Sell />} />
                <Route path="/rent" element={<Rent />} />
                <Route path="/donate" element={<Donate />} />
                <Route path="/item/:id" element={<ItemDetails />} />
                <Route path="/messages" element={<Messages />} />
                
                {/* Protected Admin Route */}
                <Route path="/admin" element={
                  <AdminRoute>
                    <Admin />
                  </AdminRoute>
                } />
                
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>
            <VoiceAssistant />
            <CartToast />
            <Footer />
          </div>
        </Router>
      </StoreProvider>
    </AuthProvider>
  );
};

export default App;
