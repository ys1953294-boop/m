
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Item } from '../types';

export interface CartItem extends Item {
  quantity: number;
}

interface StoreContextType {
  cart: CartItem[];
  wishlist: Item[];
  isCartOpen: boolean;
  setIsCartOpen: (isOpen: boolean) => void;
  showCartToast: boolean;
  setShowCartToast: (show: boolean) => void;
  addToCart: (item: Item) => void;
  removeFromCart: (itemId: string) => void;
  updateQuantity: (itemId: string, delta: number) => void;
  toggleWishlist: (item: Item) => void;
  isInWishlist: (itemId: string) => boolean;
  isInCart: (itemId: string) => boolean;
  getItemQuantity: (itemId: string) => number;
  cartTotal: number;
}

const StoreContext = createContext<StoreContextType>({} as StoreContextType);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Item[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [showCartToast, setShowCartToast] = useState(false);

  // Load from LocalStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem('eco_cart');
    const savedWishlist = localStorage.getItem('eco_wishlist');
    if (savedCart) setCart(JSON.parse(savedCart));
    if (savedWishlist) setWishlist(JSON.parse(savedWishlist));
  }, []);

  // Save to LocalStorage on change
  useEffect(() => {
    localStorage.setItem('eco_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('eco_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  const addToCart = (item: Item) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
    // Trigger the bottom toast instead of opening the drawer directly
    setShowCartToast(true);
    // Auto hide after 4 seconds
    setTimeout(() => setShowCartToast(false), 4000);
  };

  const updateQuantity = (itemId: string, delta: number) => {
    setCart((prev) => {
        return prev.map(item => {
            if (item.id === itemId) {
                return { ...item, quantity: Math.max(0, item.quantity + delta) };
            }
            return item;
        }).filter(item => item.quantity > 0);
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart((prev) => prev.filter((i) => i.id !== itemId));
  };

  const toggleWishlist = (item: Item) => {
    setWishlist((prev) => {
      if (prev.some((i) => i.id === item.id)) {
        return prev.filter((i) => i.id !== item.id);
      } else {
        return [...prev, item];
      }
    });
  };

  const isInWishlist = (itemId: string) => wishlist.some((i) => i.id === itemId);
  const isInCart = (itemId: string) => cart.some((i) => i.id === itemId);
  const getItemQuantity = (itemId: string) => cart.find(i => i.id === itemId)?.quantity || 0;

  const cartTotal = cart.reduce((total, item) => total + ((item.price || 0) * item.quantity), 0);

  return (
    <StoreContext.Provider
      value={{
        cart,
        wishlist,
        isCartOpen,
        setIsCartOpen,
        showCartToast,
        setShowCartToast,
        addToCart,
        removeFromCart,
        updateQuantity,
        toggleWishlist,
        isInWishlist,
        isInCart,
        getItemQuantity,
        cartTotal,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => useContext(StoreContext);
