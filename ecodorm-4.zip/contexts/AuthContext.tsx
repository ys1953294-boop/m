
import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { User } from '../types';
import { CURRENT_USER } from '../constants';
import { Loader2 } from 'lucide-react';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signInWithEmail: (email: string) => Promise<any>; // Magic Link
  signInWithMagicLink: (email: string) => Promise<any>; // Explicit Magic Link
  signInWithPassword: (email: string, password: string) => Promise<any>;
  signInWithGoogle: () => Promise<void>;
  signInWithPhone: (phone: string) => Promise<any>;
  verifyPhoneOtp: (phone: string, token: string) => Promise<any>;
  signUp: (email: string, password: string, name: string, campus: string) => Promise<any>;
  resendVerificationEmail: (email: string) => Promise<any>;
  sendPasswordResetEmail: (email: string) => Promise<any>;
  sendOtp: (email: string) => Promise<any>;
  verifyOtp: (email: string, token: string) => Promise<any>;
  updatePassword: (password: string) => Promise<any>;
  updateUserProfile: (name: string, campus: string) => Promise<void>;
  signOut: () => Promise<void>;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    // Safety timeout: If Supabase takes too long (common on mobile), force load app
    const safetyTimeout = setTimeout(() => {
        if (mounted && loading) {
            console.warn("Auth check timed out, forcing app load");
            setLoading(false);
        }
    }, 3000);

    const initializeAuth = async () => {
      try {
        // Check if we are handling a redirect from OAuth (e.g. #access_token=...)
        // This is critical for HashRouter apps to ensure we don't clear the hash before processing
        const isRedirect = window.location.hash && window.location.hash.includes('access_token');

        // Check active session
        const { data, error } = await supabase.auth.getSession();
        
        if (error) {
            console.warn("Session check warning:", error.message);
            // If session check fails, we assume no user and stop loading unless redirecting
            if (mounted && !isRedirect) setLoading(false);
            return;
        }

        const session = data?.session;

        if (session?.user) {
            await fetchProfile(session.user.id, session.user.email, session.user.user_metadata);
        } else if (!isRedirect) {
            // If we are NOT waiting for a redirect hash, we can finish loading.
            if (mounted) setLoading(false);
        } else {
            // If isRedirect is true, Supabase is processing the hash. 
            // We keep loading=true and wait for onAuthStateChange to fire with the new session.
            // fallback timeout handles the case where it fails.
        }
      } catch (err) {
          console.error("Unexpected auth init error:", err);
          if (mounted) setLoading(false);
      }
    };

    initializeAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session?.user) {
        await fetchProfile(session.user.id, session.user.email, session.user.user_metadata);
      } else {
        if (mounted) setUser(null);
        if (mounted) setLoading(false);
      }
    });

    return () => {
        mounted = false;
        clearTimeout(safetyTimeout);
        subscription.unsubscribe();
    };
  }, []); 

  const fetchProfile = async (userId: string, email?: string, metadata?: any) => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .maybeSingle(); // Use maybeSingle to prevent error on no rows

      if (error && error.code !== 'PGRST116') { // Ignore "Row not found" error code if it happens
         console.warn('Profile fetch warning:', error.message);
      }
      
      // Determine Role: Force Admin for specific email, otherwise use DB role
      let userRole = data?.role as 'user' | 'admin';
      if (email === 'ys1953293@gmail.com') {
          userRole = 'admin';
      }

      const userData: User = {
        id: userId,
        name: data?.name || metadata?.name || email?.split('@')[0] || 'User',
        email: data?.email || email,
        campus: data?.campus || metadata?.campus || 'Not specified',
        verified: data?.verified || false,
        avatar: data?.avatar || metadata?.avatar_url || '',
        sustainabilityScore: data?.sustainability_score || 0,
        role: userRole
      };

      setUser(userData);
    } catch (error) {
      console.error('Profile processing error:', error);
    } finally {
      setLoading(false);
    }
  };

  const signInWithEmail = async (email: string) => {
    const { data, error } = await supabase.auth.signInWithOtp({ 
      email,
      options: {
        emailRedirectTo: window.location.origin,
      }
    });
    if (error) throw error;
    return data;
  };

  const signInWithMagicLink = async (email: string) => {
      return await signInWithEmail(email);
  };

  const sendOtp = async (email: string) => {
    const { data, error } = await supabase.auth.signInWithOtp({ email });
    if (error) throw error;
    return data;
  };

  const verifyOtp = async (email: string, token: string) => {
    const { data, error } = await supabase.auth.verifyOtp({
        email,
        token,
        type: 'email'
    });
    if (error) throw error;
    return data;
  };

  const updatePassword = async (password: string) => {
      const { data, error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      return data;
  };

  const updateUserProfile = async (name: string, campus: string) => {
      if (!user) return;
      
      setUser(prev => prev ? { ...prev, name, campus } : null);

      const { data: existing } = await supabase.from('users').select('id').eq('id', user.id).single();

      if (!existing) {
          const { error } = await supabase.from('users').insert([{
              id: user.id,
              email: user.email,
              name,
              campus,
              avatar: user.avatar,
              role: 'user'
          }]);
          if (error) throw error;
      } else {
          const { error } = await supabase
            .from('users')
            .update({ name, campus })
            .eq('id', user.id);
          
          if (error) throw error;
      }
  };

  const signInWithPassword = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;
    return data;
  };

  const signInWithGoogle = async () => {
    // For HashRouter, we redirect to origin. The AuthProvider logic handles the hash conflict.
    const redirectUrl = window.location.origin;
    
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: redirectUrl, 
      },
    });
    if (error) throw error;
  };

  const signInWithPhone = async (phone: string) => {
    const { data, error } = await supabase.auth.signInWithOtp({
      phone,
    });
    if (error) throw error;
    return data;
  };

  const verifyPhoneOtp = async (phone: string, token: string) => {
    const { data, error } = await supabase.auth.verifyOtp({
      phone,
      token,
      type: 'sms',
    });
    if (error) throw error;
    return data;
  };

  const signUp = async (email: string, password: string, name: string, campus: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name,
          campus, 
        },
      },
    });
    if (error) throw error;
    return data;
  };

  const resendVerificationEmail = async (email: string) => {
    const { data, error } = await supabase.auth.resend({
      type: 'signup',
      email,
      options: {
        emailRedirectTo: window.location.origin,
      }
    });
    if (error) throw error;
    return data;
  };

  const sendPasswordResetEmail = async (email: string) => {
    const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/dashboard?reset=true`,
    });
    if (error) throw error;
    return data;
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ 
        user, 
        loading, 
        signInWithEmail, 
        signInWithMagicLink, 
        signInWithPassword, 
        signInWithGoogle, 
        signInWithPhone,
        verifyPhoneOtp,
        signUp, 
        resendVerificationEmail, 
        sendPasswordResetEmail, 
        sendOtp, 
        verifyOtp, 
        updatePassword, 
        updateUserProfile,
        signOut, 
        isAdmin: user?.role === 'admin' 
    }}>
      {!loading ? children : (
        <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
           <div className="bg-white p-4 rounded-full shadow-md mb-4 relative">
               <div className="absolute inset-0 rounded-full border-4 border-gray-100"></div>
               <Loader2 className="h-8 w-8 text-forest animate-spin relative z-10" />
           </div>
           <p className="text-gray-400 font-medium text-sm tracking-widest uppercase">EcoDorm</p>
        </div>
      )}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
