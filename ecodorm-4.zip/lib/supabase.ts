import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://oaxvpzcyxbcqmlbauydv.supabase.co';
const supabaseKey = 'sb_publishable_kP3oGyhEF5efBnUup6HA6g_JeImPylp';

export const supabase = createClient(supabaseUrl, supabaseKey);
