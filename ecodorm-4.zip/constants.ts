import { Item, User, Category, Conversation } from './types';

export const CATEGORIES: Category[] = [
  'Textbooks', 
  'Stationery', 
  'Electronics', 
  'Furniture', 
  'Clothing', 
  'Kitchen', 
  'Other',
  'B.Tech Notes',
  'B.Tech PYQ',
  'BCA Notes',
  'BCA PYQ',
  'Gadgets',
  'Audio',
  'Accessories',
  'Decor',
  'Setup',
  'Merch',
  'Limited',
  'Roommates'
];

export const BTECH_1ST_YEAR_SUBJECTS = [
  "Engineering Mathematics I",
  "Engineering Mathematics II",
  "Engineering Physics",
  "Engineering Chemistry",
  "Programming for Problem Solving",
  "Fundamentals of Electrical Engineering",
  "Fundamentals of Electronics Engineering",
  "Fundamentals of Mechanical Engineering",
  "Environment and Ecology",
  "Soft Skills",
  "Technical Communication",
  "Engineering Graphics & Design"
];

export const PYQ_YEARS = [
  "2025-2026",
  "2024-2025",
  "2023-2024",
  "2022-2023",
  "2021-2022",
  "2020-2021",
  "2019-2020"
];

export const CAMPUS_OPTIONS = [
  "Galgotias University",
  "Galgotias College of Engineering & Technology (GCET)",
  "Sharda University",
  "G.L. Bajaj Institute of Technology and Management",
  "Noida Institute of Engineering and Technology (NIET)",
  "Amity University (Greater Noida Campus)",
  "Bennett University",
  "Gautam Buddha University",
  "JSS Academy of Technical Education",
  "Army Institute of Management and Technology",
  "Mangalmay Institute of Management and Technology",
  "Accurate Institute of Management and Technology",
  "IILM College of Engineering and Technology",
  "Dronacharya Group of Institutions",
  "United College of Engineering & Research",
  "Skyline Institute of Engineering and Technology",
  "Lloyd Law College / Lloyd Business School",
  "Greater Noida Institute of Technology (GNIOT)",
  "IEC College of Engineering and Technology",
  "Other"
];

// Logic for "Nearby" (50km radius simulation)
export const KNOWLEDGE_PARK_COLLEGES = [
  "Galgotias University",
  "Galgotias College of Engineering & Technology (GCET)",
  "Sharda University",
  "G.L. Bajaj Institute of Technology and Management",
  "Noida Institute of Engineering and Technology (NIET)",
  "IILM College of Engineering and Technology",
  "Greater Noida Institute of Technology (GNIOT)",
  "IEC College of Engineering and Technology",
  "Skyline Institute of Engineering and Technology",
  "Lloyd Law College / Lloyd Business School",
  "Mangalmay Institute of Management and Technology",
  "Accurate Institute of Management and Technology",
  "Dronacharya Group of Institutions",
  "United College of Engineering & Research"
];

export const GREATER_NOIDA_COLLEGES = [
  ...KNOWLEDGE_PARK_COLLEGES,
  "Amity University (Greater Noida Campus)",
  "Bennett University",
  "Gautam Buddha University",
  "JSS Academy of Technical Education",
  "Army Institute of Management and Technology",
];

export const CURRENT_USER: User = {
  id: 'u1',
  name: 'Alex Chen',
  campus: 'Galgotias University',
  verified: true,
  avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
  sustainabilityScore: 850,
};

export const MOCK_ITEMS: Item[] = [
  {
    id: '1',
    title: 'Calculus: Early Transcendentals (8th Ed)',
    description: 'Used for Math 124/125/126. Minimal highlighting. Binding is tight. Comes with the solution manual if you want it for free.',
    price: 450,
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80',
    category: 'Textbooks',
    condition: 'Good',
    type: 'sell',
    seller: { id: 'u2', name: 'Sarah J.', campus: 'Galgotias University', verified: true, avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80', sustainabilityScore: 400 },
    postedAt: '2023-10-25T10:00:00Z',
  },
  {
    id: '2',
    title: 'Mini Fridge - Black',
    description: 'Moving out sale! Works perfectly, fits under dorm bed. 3.2 cu ft. Has a small freezer compartment that actually freezes.',
    price: 3000,
    originalPrice: 8000,
    image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80',
    category: 'Furniture',
    condition: 'Fair',
    type: 'flash',
    flashSaleEndsAt: new Date(Date.now() + 86400000).toISOString(), // 24 hours from now
    seller: { id: 'u3', name: 'Mike T.', campus: 'Sharda University', verified: true, avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80', sustainabilityScore: 200 },
    postedAt: '2023-10-26T09:00:00Z',
  },
  {
    id: '3',
    title: 'Graphing Calculator TI-84 Plus',
    description: 'Need it for the semester? Rent it cheaper than buying! Batteries included. Screen has no scratches.',
    price: 0,
    rentalRate: { daily: 50, weekly: 300 },
    image: 'https://images.unsplash.com/photo-1585338107529-13afc5f02586?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80',
    category: 'Electronics',
    condition: 'Like New',
    type: 'rent',
    seller: { id: 'u4', name: 'Emily R.', campus: 'NIET', verified: true, avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80', sustainabilityScore: 600 },
    postedAt: '2023-10-24T14:00:00Z',
  },
  {
    id: '4',
    title: 'Winter Parka (Size M)',
    description: 'Too warm for me now. Free to a good home/student in need. North Face brand, very warm for winter.',
    price: 0,
    image: 'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80',
    category: 'Clothing',
    condition: 'Good',
    type: 'donate',
    seller: { id: 'u5', name: 'David L.', campus: 'G.L. Bajaj Institute of Technology and Management', verified: true, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80', sustainabilityScore: 900 },
    postedAt: '2023-10-26T11:30:00Z',
  },
  {
    id: '5',
    title: 'Electric Kettle',
    description: 'Boils water fast. Essential for late night noodles. Auto shut-off feature.',
    price: 450,
    originalPrice: 900,
    image: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80',
    category: 'Kitchen',
    condition: 'Like New',
    type: 'flash',
    flashSaleEndsAt: new Date(Date.now() + 12000000).toISOString(),
    seller: { id: 'u3', name: 'Mike T.', campus: 'Sharda University', verified: true, avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80', sustainabilityScore: 200 },
    postedAt: '2023-10-26T09:05:00Z',
  },
  {
    id: '6',
    title: 'IKEA Desk Lamp',
    description: 'Simple LED lamp. Bulb included. Adjustable arm.',
    price: 250,
    image: 'https://images.unsplash.com/photo-1534073828943-f801091a3d4d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80',
    category: 'Furniture',
    condition: 'Good',
    type: 'sell',
    seller: { id: 'u6', name: 'Jenny K.', campus: 'Galgotias University', verified: true, avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80', sustainabilityScore: 350 },
    postedAt: '2023-10-22T16:00:00Z',
  },
];

export const MOCK_CONVERSATIONS: Conversation[] = [
  {
    id: 'c1',
    otherUser: MOCK_ITEMS[0].seller, // Sarah J.
    unreadCount: 1,
    lastMessage: {
      id: 'm2',
      senderId: 'u2',
      text: 'Yes, I can meet at the library tomorrow at 2pm.',
      timestamp: '2023-10-26T14:30:00Z',
      isRead: false,
    },
    messages: [
      {
        id: 'm1',
        senderId: 'u1',
        text: 'Hi Sarah, is the Calculus book still available?',
        timestamp: '2023-10-26T14:00:00Z',
        isRead: true,
      },
      {
        id: 'm2',
        senderId: 'u2',
        text: 'Yes, I can meet at the library tomorrow at 2pm.',
        timestamp: '2023-10-26T14:30:00Z',
        isRead: false,
      },
    ],
  },
  {
    id: 'c2',
    otherUser: MOCK_ITEMS[2].seller, // Emily R.
    unreadCount: 0,
    lastMessage: {
      id: 'm4',
      senderId: 'u1',
      text: 'Great, see you then!',
      timestamp: '2023-10-25T10:15:00Z',
      isRead: true,
    },
    messages: [
      {
        id: 'm3',
        senderId: 'u4',
        text: 'The calculator has fresh batteries.',
        timestamp: '2023-10-25T10:00:00Z',
        isRead: true,
      },
      {
        id: 'm4',
        senderId: 'u1',
        text: 'Great, see you then!',
        timestamp: '2023-10-25T10:15:00Z',
        isRead: true,
      },
    ],
  },
];