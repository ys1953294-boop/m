
/*
  ECODORM DATABASE FIX SCRIPT
  Run this in Supabase SQL Editor.
*/

-- 1. Enable UUID extension
create extension if not exists "uuid-ossp";

-- 2. Ensure Tables Exist
create table if not exists public.users (
  id uuid references auth.users not null primary key,
  name text,
  email text,
  campus text,
  role text default 'user',
  verified boolean default false,
  avatar text,
  sustainability_score int default 0,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create table if not exists public.items (
  id uuid default uuid_generate_v4() primary key,
  title text not null,
  description text,
  price numeric default 0,
  original_price numeric,
  category text,
  condition text,
  type text,
  seller_id uuid references public.users(id) on delete cascade not null,
  images text[],
  is_flash_sale boolean default false,
  flash_sale_ends_at timestamp with time zone,
  is_active boolean default true,
  is_premium boolean default false, /* Added Premium Column */
  year text,
  subject text,
  external_link text,
  rental_period text,
  delivery_duration text,
  gender text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create table if not exists public.messages (
  id uuid default uuid_generate_v4() primary key,
  sender_id uuid references public.users(id) not null,
  receiver_id uuid references public.users(id) not null,
  item_id uuid references public.items(id) on delete cascade,
  message text not null,
  is_read boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create table if not exists public.banners (
  id uuid default uuid_generate_v4() primary key,
  image_url text not null,
  active boolean default true,
  link text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 3. ENSURE COLUMNS EXIST (Run this block even if tables exist)
ALTER TABLE public.banners ADD COLUMN IF NOT EXISTS active boolean DEFAULT true;
ALTER TABLE public.banners ADD COLUMN IF NOT EXISTS link text;
ALTER TABLE public.banners ADD COLUMN IF NOT EXISTS image_url text;
ALTER TABLE public.items ADD COLUMN IF NOT EXISTS delivery_duration text;
ALTER TABLE public.items ADD COLUMN IF NOT EXISTS gender text;
ALTER TABLE public.items ADD COLUMN IF NOT EXISTS is_premium boolean DEFAULT false;

-- 4. FORCE ADMIN ROLE FOR YOUR EMAIL
-- This is critical for the RLS policies below to work for you
UPDATE public.users 
SET role = 'admin' 
WHERE email = 'ys1953293@gmail.com';

-- 5. ROW LEVEL SECURITY (RLS) POLICIES

-- Enable RLS
alter table public.users enable row level security;
alter table public.items enable row level security;
alter table public.messages enable row level security;
alter table public.banners enable row level security;

-- USERS POLICIES
drop policy if exists "Public profiles" on public.users;
create policy "Public profiles" on public.users for select using (true);

drop policy if exists "Self update" on public.users;
create policy "Self update" on public.users for update using (auth.uid() = id);

drop policy if exists "Self insert" on public.users;
create policy "Self insert" on public.users for insert with check (auth.uid() = id);

-- ITEMS POLICIES (UPDATED FOR ADMIN ACCESS)
drop policy if exists "Public items" on public.items;
create policy "Public items" on public.items for select using (true);

drop policy if exists "Auth create items" on public.items;
create policy "Auth create items" on public.items for insert with check (auth.role() = 'authenticated');

-- Allow update if user is seller OR user is admin
drop policy if exists "Update items" on public.items;
create policy "Update items" on public.items for update using (
  auth.uid() = seller_id 
  OR 
  (SELECT role FROM public.users WHERE id = auth.uid()) = 'admin'
);

-- Allow delete if user is seller OR user is admin
drop policy if exists "Delete items" on public.items;
create policy "Delete items" on public.items for delete using (
  auth.uid() = seller_id 
  OR 
  (SELECT role FROM public.users WHERE id = auth.uid()) = 'admin'
);

-- MESSAGES POLICIES
drop policy if exists "Own messages" on public.messages;
create policy "Own messages" on public.messages for select using (auth.uid() = sender_id or auth.uid() = receiver_id);

drop policy if exists "Send messages" on public.messages;
create policy "Send messages" on public.messages for insert with check (auth.uid() = sender_id);

-- BANNERS POLICIES
drop policy if exists "Public banners" on public.banners;
create policy "Public banners" on public.banners for select using (true);

drop policy if exists "Manage banners" on public.banners;
create policy "Manage banners" on public.banners for all using (
  (SELECT role FROM public.users WHERE id = auth.uid()) = 'admin'
);

-- 6. STORAGE PERMISSIONS
insert into storage.buckets (id, name, public)
values ('item-images', 'item-images', true)
on conflict (id) do update set public = true;

drop policy if exists "Public Access" on storage.objects;
create policy "Public Access" on storage.objects for select using ( bucket_id = 'item-images' );

drop policy if exists "Authenticated users can upload" on storage.objects;
create policy "Authenticated users can upload" on storage.objects for insert 
with check ( bucket_id = 'item-images' and auth.role() = 'authenticated' );

drop policy if exists "Users can delete own images" on storage.objects;
create policy "Users can delete own images" on storage.objects for delete
using ( bucket_id = 'item-images' and auth.uid()::text = (storage.foldername(name))[1] );

-- 7. TRIGGER FOR NEW USERS
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.users (id, email, name, avatar, campus)
  values (
    new.id, 
    new.email, 
    new.raw_user_meta_data->>'name', 
    new.raw_user_meta_data->>'avatar_url',
    new.raw_user_meta_data->>'campus'
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
